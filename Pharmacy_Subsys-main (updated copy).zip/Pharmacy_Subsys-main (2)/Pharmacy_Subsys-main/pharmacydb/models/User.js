// models/User.js
import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const userSchema = new mongoose.Schema(
  {
    userId: {
        type: String,
        unique: true,
        required: true,
    },
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
    },
    password: {
      type: String,
      required: true,
    },
    role: {
      type: String,
      required: true,
      enum: ['admin', 'pharmacist'],
      default: 'pharmacist',
    },
    status: {
      type: String,
      enum: ['active', 'inactive'],
      default: 'active',
    },
    lastLogin: {
      type: Date,
      default: null,
    },
    // --- NEW SECURITY FIELDS (3-Strike Rule) ---
    failedLoginAttempts: {
      type: Number,
      required: true,
      default: 0,
    },
    isLocked: {
      type: Boolean,
      default: false,
    },
    mustChangePassword: { 
      type: Boolean, 
      default: false 
    },
    tempPassword: {
      type: String,
      default: null, // Stores the HASHED temporary password
    },
    // -------------------------------------------
  },
  { timestamps: true }
);

// Encrypt password before saving
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) {
    next();
  }
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

// Method 1: Compare normal password
userSchema.methods.matchPassword = async function (enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

// Method 2: Compare temporary password (New)
userSchema.methods.matchTempPassword = async function (enteredTempPassword) {
  // If no temp password exists, return false immediately
  if (!this.tempPassword) return false; 
  return await bcrypt.compare(enteredTempPassword, this.tempPassword);
};

const User = mongoose.model('User', userSchema);
export default User;