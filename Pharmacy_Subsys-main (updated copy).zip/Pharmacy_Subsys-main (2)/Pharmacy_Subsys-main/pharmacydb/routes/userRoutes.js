import express from 'express';
import User from '../models/User.js';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { protect, admin } from '../middleware/authMiddleware.js';
import { getNextSequenceValue, formatUserId } from '../utils/counters.js';

const router = express.Router();

// @route   POST /api/users
// @desc    Register a new user (by a re-authenticated Admin)
// @access  Private/Admin
router.post('/', protect, admin, async (req, res) => {
  try {
    const { adminPassword, newUserData } = req.body;
    const { name, email, password, role } = newUserData;

    // --- ADDED ID GENERATION ---
    const nextId = await getNextSequenceValue('userId'); // Use 'userId' sequence
    const newUserId = formatUserId(nextId);            // Format as U001
    
    if (!adminPassword || !newUserData) {
      return res.status(400).json({ message: 'Missing admin password or new user data' });
    }

    const adminUser = await User.findById(req.user._id);

    if (!adminUser || !(await adminUser.matchPassword(adminPassword))) {
      return res.status(401).json({ message: 'Invalid admin password. Action canceled.' });
    }

    // Check if email exists
    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ message: 'User already exists with that email' });
    }

    const user = await User.create({ 
      userId: newUserId,
      name, 
      email, 
      password, 
      role 
    });
    
    res.status(201).json({
      _id: user._id,
      userId: user.userId,
      name: user.name,
      email: user.email,
      role: user.role,
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// =========================================================================
//  UPDATED LOGIN ROUTE (WITH 3-STRIKE & TEMP PASSWORD LOGIC)
// =========================================================================

// @route   POST /api/users/login
// @desc    Authenticate user & get token (Handles Lockout)
// @access  Public
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    // 1. CHECK IF ACCOUNT IS LOCKED
    if (user.isLocked) {
      // If locked, we ONLY check the Temporary Password
      const isTempMatch = await user.matchTempPassword(password);

      if (isTempMatch) {
        // SUCCESS: Unlock the account and reset counters
        user.isLocked = false;
        user.failedLoginAttempts = 0;
        user.tempPassword = null; // Clear the used temp password
        user.lastLogin = Date.now();
        await user.save();

        // Respond with Token (Login Successful)
        return res.json({
          _id: user._id,
          userId: user.userId,
          name: user.name,
          email: user.email,
          role: user.role,
          status: user.status,
          mustChangePassword: user.mustChangePassword,
          token: jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, {
            expiresIn: '1d',
          }),
          message: 'Account unlocked via temporary password.'
        });
      } else {
        // FAIL: Temp password didn't match
        return res.status(403).json({ 
          message: 'Account is locked. You must use the Temporary Password provided by Admin.' 
        });
      }
    }

    // 2. CHECK IF INACTIVE
    if (user.status === 'inactive') {
      return res.status(403).json({ message: 'Account is deactivated. Please contact an admin.' });
    }

    // 3. CHECK NORMAL PASSWORD
    if (await user.matchPassword(password)) {
      // SUCCESS: Reset failures and log in
      user.failedLoginAttempts = 0;
      user.lastLogin = Date.now();
      await user.save();

      res.json({
        _id: user._id,
        userId: user.userId,
        name: user.name,
        email: user.email,
        role: user.role,
        status: user.status,
        lastLogin: user.lastLogin,
        token: jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, {
          expiresIn: '1d',
        }),
      });
    } else {
      // FAIL: Increment failure counter
      user.failedLoginAttempts = (user.failedLoginAttempts || 0) + 1;

      // Check if they reached the limit (3 tries)
      if (user.failedLoginAttempts >= 3) {
        user.isLocked = true;
        await user.save();
        return res.status(403).json({ 
          message: 'Maximum login attempts exceeded. Account is now LOCKED. Contact Admin.' 
        });
      }

      await user.save();
      const attemptsLeft = 3 - user.failedLoginAttempts;
      res.status(401).json({ 
        message: `Invalid email or password. You have ${attemptsLeft} attempt(s) left.` 
      });
    }
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// =========================================================================
//  NEW ADMIN ROUTE (ISSUE TEMP PASSWORD)
// =========================================================================

// @route   POST /api/users/:id/unlock
// @desc    Admin sets a temporary password for a locked user
// @access  Private/Admin
router.post('/:id/unlock', protect, admin, async (req, res) => {
  try {
    const { tempPassword } = req.body;
    
    if (!tempPassword) {
      return res.status(400).json({ message: 'Temporary password is required' });
    }

    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    // Manually hash the temp password 
    const salt = await bcrypt.genSalt(10);
    user.tempPassword = await bcrypt.hash(tempPassword, salt);
    
    // Ensure isLocked is true, so they are forced to use the temp password
    user.isLocked = true; 
    
    user.mustChangePassword = true;
    
    await user.save();

    res.json({ message: `Temporary password set for ${user.name}.` });

  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// =========================================================================
//  EXISTING ROUTES (KEPT THE SAME)
// =========================================================================

// @route   GET /api/users
// @desc    Get all users (Admin only)
// @access  Private/Admin
router.get('/', protect, admin, async (req, res) => {
  try {
    const users = await User.find({}).select('-password');
    res.json(users);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// @route   PUT /api/users/:id
// @desc    Update a user (by Admin with "sudo")
// @access  Private/Admin
router.put('/:id', protect, admin, async (req, res) => {
  try {
    const { adminPassword, updatedUserData } = req.body;
    const { name, email, role, password } = updatedUserData;
    
    if (!adminPassword || !updatedUserData) {
      return res.status(400).json({ message: 'Missing admin password or update data' });
    }

    const adminUser = await User.findById(req.user._id);
    if (!adminUser || !(await adminUser.matchPassword(adminPassword))) {
      return res.status(401).json({ message: 'Invalid admin password. Action canceled.' });
    }

    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    user.name = name || user.name;
    user.email = email || user.email;
    user.role = role || user.role;
    
    // Only update password if a new one is provided
    if (password) {
      user.password = password;
    }
    
    const updatedUser = await user.save();
    res.json({
      _id: updatedUser._id,
      name: updatedUser.name,
      email: updatedUser.email,
      role: updatedUser.role,
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// @route   DELETE /api/users/:id
// @desc    Delete a user (by Admin with "sudo")
// @access  Private/Admin
router.delete('/:id', protect, admin, async (req, res) => {
  try {
    const { adminPassword } = req.body;
    
    if (!adminPassword) {
      return res.status(400).json({ message: 'Admin password is required' });
    }
    
    const adminUser = await User.findById(req.user._id);
    if (!adminUser || !(await adminUser.matchPassword(adminPassword))) {
      return res.status(401).json({ message: 'Invalid admin password. Action canceled.' });
    }
    
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Prevent an admin from deleting themselves
    if (user._id.equals(req.user._id)) {
      return res.status(400).json({ message: 'You cannot delete your own admin account.' });
    }

    await User.deleteOne({ _id: req.params.id });
    res.json({ message: 'User removed successfully' });
  
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// @route   PATCH /api/users/:id/status
// @desc    Toggle user status (by Admin with "sudo")
// @access  Private/Admin
router.patch('/:id/status', protect, admin, async (req, res) => {
  try {
    const { adminPassword } = req.body;
    
    if (!adminPassword) {
      return res.status(400).json({ message: 'Admin password is required' });
    }

    const adminUser = await User.findById(req.user._id);
    if (!adminUser || !(await adminUser.matchPassword(adminPassword))) {
      return res.status(401).json({ message: 'Invalid admin password. Action canceled.' });
    }
    
    const user = await User.findById(req.params.id);
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Prevent an admin from deactivating themselves
    if (user._id.equals(req.user._id)) {
      return res.status(400).json({ message: 'You cannot deactivate your own account.' });
    }

    user.status = user.status === 'active' ? 'inactive' : 'active';
    await user.save();
    
    res.json(user);
  
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: err.message || 'Server Error' });
  }
});

// @route   PUT /api/users/profile
// @desc    User updates their own profile (Change Password)
// @access  Private
router.put('/profile', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user._id);

    if (user) {
      // Update Name/Email if provided, otherwise keep existing
      user.name = req.body.name || user.name;
      user.email = req.body.email || user.email;

      // If password is sent, hash it and update
      if (req.body.password) {
        user.password = req.body.password;
        // IMPORTANT: Reset the forced change flag
        user.mustChangePassword = false; 
      }

      const updatedUser = await user.save();

      res.json({
        _id: updatedUser._id,
        name: updatedUser.name,
        email: updatedUser.email,
        role: updatedUser.role,
        mustChangePassword: updatedUser.mustChangePassword,
        token: jwt.sign({ id: updatedUser._id, role: updatedUser.role }, process.env.JWT_SECRET, {
            expiresIn: '1d',
          }),
      });
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server Error' });
  }
});
export default router;