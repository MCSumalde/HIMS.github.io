// Authentication check
(function() {
  const loggedIn = sessionStorage.getItem('loggedIn');
  const role = sessionStorage.getItem('role');
  if (loggedIn !== 'true' || role !== 'Admin') {
    window.location.href = 'emrLogin.html';
  }
})();

// Real data - will be populated from API calls
let mockAppointmentBackups = [];
let mockAccountBackups = [];
let mockUserActivity = [];

// Load real backup logs from server on page load
async function loadBackupLogsFromServer() {
  try {
    console.log('📥 Loading backup logs from database...');
    const res = await fetch('http://localhost:5000/api/backup/logs/accounts');
    const logs = await res.json();
    
    // Update the arrays
    mockAccountBackups = logs;
    tabStates.accounts.filteredData = [...logs];
    
    console.log(`✅ Loaded ${logs.length} backup logs from database`);
    
    // If we're currently viewing accounts tab, refresh it
    if (currentTab === 'accounts') {
      await loadAccountStats();
      renderAccounts();
    }
  } catch (err) {
    console.error('Error loading backup logs:', err);
  }
}

// Load activity backup logs from server
async function loadActivityBackupLogs() {
  try {
    console.log('📥 Loading activity backup logs from database...');
    const res = await fetch('http://localhost:5000/api/backup/logs/activity');
    const logs = await res.json();
    
    mockUserActivity = logs;
    tabStates.activity.filteredData = [...logs];
    
    console.log(`✅ Loaded ${logs.length} activity backup logs from database`);
    
    if (currentTab === 'activity') {
      await loadActivityStats();
      renderActivity();
    }
  } catch (err) {
    console.error('Error loading activity backup logs:', err);
  }
}

// Call on page load
document.addEventListener('DOMContentLoaded', () => {
  loadBackupLogsFromServer();
});

// State Management
let currentTab = 'appointments';
const tabStates = {
  appointments: { currentPage: 1, filteredData: [...mockAppointmentBackups] },
  accounts: { currentPage: 1, filteredData: [...mockAccountBackups] },
  activity: { currentPage: 1, filteredData: [...mockUserActivity] }
};
const logsPerPage = 10;

// Tab Switching
function switchTab(tab) {
  currentTab = tab;
  
  // Update tab buttons
  document.querySelectorAll('.tab-button').forEach(btn => btn.classList.remove('active'));
  document.getElementById(`tab-${tab}`).classList.add('active');
  
  // Update content
  document.querySelectorAll('.tab-content').forEach(content => content.classList.add('hidden'));
  document.getElementById(`content-${tab}`).classList.remove('hidden');
  
  // Load data
  if (tab === 'appointments') {
    loadAppointmentStats();
    renderAppointments();
  } else if (tab === 'accounts') {
    loadAccountStats();
    renderAccounts();
  } else if (tab === 'activity') {
    loadActivityStats();
    renderActivity();
  }
}

// === APPOINTMENTS TAB ===
async function loadAppointmentStats() {
  try {
    const res = await fetch('http://localhost:5000/api/backup/appointments/stats');
    const stats = await res.json();
    
    document.getElementById('totalAppointmentBackups').textContent = mockAppointmentBackups.length;
    document.getElementById('successfulAppointmentBackups').textContent = 
      mockAppointmentBackups.filter(d => d.status === 'success').length;
    
    // New stats
    document.getElementById('activeAppointmentsCount').textContent = stats.totalActive;
    document.getElementById('archivedAppointmentsCount').textContent = stats.totalArchived;
    
    if (stats.lastBackup) {
      document.getElementById('lastAppointmentBackup').textContent = 
        new Date(stats.lastBackup).toLocaleString();
    }
  } catch (err) {
    console.error("Error loading appointment stats:", err);
    loadAppointmentStatsFromMock();
  }
}

function loadAppointmentStatsFromMock() {
  const data = mockAppointmentBackups;
  
  document.getElementById('totalAppointmentBackups').textContent = data.length;
  document.getElementById('successfulAppointmentBackups').textContent = 
    data.filter(d => d.status === 'success').length;
  
  // ✅ Use the actual latest backup timestamp from the array
  if (data.length > 0) {
    document.getElementById('lastAppointmentBackup').textContent = 
      new Date(data[0].date).toLocaleString();
  } else {
    document.getElementById('lastAppointmentBackup').textContent = 'Never';
  }
}

function renderAppointments() {
  const tbody = document.getElementById('appointmentTableBody');
  const state = tabStates.appointments;
  const start = (state.currentPage - 1) * logsPerPage;
  const end = start + logsPerPage;
  const paginatedData = state.filteredData.slice(start, end);

  tbody.innerHTML = '';

  if (paginatedData.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="9" class="px-6 py-8 text-center text-text-secondary-light">
          <span class="material-icons-outlined text-4xl mb-2">inbox</span>
          <p>No backup logs found</p>
        </td>
      </tr>`;
    return;
  }

  paginatedData.forEach(log => {
    const statusBadge = log.status === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700';
    const statusIcon = log.status === 'success' ? 'check_circle' : 'error';
    const typeBadge = log.type === 'Manual' ? 'bg-purple-100 text-purple-700' : 'bg-gray-100 text-gray-700';
    
    // Determine scope badge
    let scopeBadge = 'scope-full';
    if (log.scope === 'Active Only') scopeBadge = 'scope-active';
    else if (log.scope === 'Archived Only') scopeBadge = 'scope-archived';
    
    // ✅ FIX: Get the correct MongoDB _id
    const backupId = log.id || log._id;
    
    const row = document.createElement('tr');
    row.className = 'hover:bg-gray-50';
    
    row.innerHTML = `
      <td class="px-6 py-4">
        <span class="flex items-center px-3 py-1 text-xs font-semibold rounded-full ${statusBadge} w-fit">
          <span class="material-icons-outlined text-sm mr-1">${statusIcon}</span>
          ${log.status.charAt(0).toUpperCase() + log.status.slice(1)}
        </span>
      </td>
      <td class="px-6 py-4 text-sm">${new Date(log.date).toLocaleString()}</td>
      <td class="px-6 py-4">
        <span class="px-3 py-1 text-xs font-semibold rounded-full ${typeBadge}">${log.type}</span>
      </td>
      <td class="px-6 py-4">
        <span class="scope-badge ${scopeBadge}">${log.scope || 'Full'}</span>
      </td>
      <td class="px-6 py-4 text-sm">
        <span class="text-blue-600 font-semibold">${log.activeCount || 0}</span>
      </td>
      <td class="px-6 py-4 text-sm">
        <span class="text-purple-600 font-semibold">${log.archivedCount || 0}</span>
      </td>
      <td class="px-6 py-4 text-sm font-semibold">${log.records}</td>
      <td class="px-6 py-4 text-sm">${log.size}</td>
      <td class="px-6 py-4">
        <button class="view-btn text-primary hover:text-green-700 font-semibold text-sm flex items-center">
          <span class="material-icons-outlined text-sm mr-1">visibility</span>
          View
        </button>
      </td>
    `;
    
    // ✅ Add event listener with correct ID (just like accounts table)
    const viewBtn = row.querySelector('.view-btn');
    viewBtn.addEventListener('click', () => {
      console.log('Viewing appointment backup with ID:', backupId);
      viewAppointmentDetails(backupId);
    });
    
    tbody.appendChild(row);
  });

  updatePagination('appointments');
}

// === ACCOUNTS TAB ===
async function loadAccountStats() {
  try {
    const res = await fetch('http://localhost:5000/api/backup/accounts/stats');
    const stats = await res.json();
    
    document.getElementById('totalAccountBackups').textContent = mockAccountBackups.length;
    document.getElementById('successfulAccountBackups').textContent = mockAccountBackups.filter(d => d.status === 'success').length;
    document.getElementById('failedAccountBackups').textContent = mockAccountBackups.filter(d => d.status === 'failed').length;
    
    // ✅ Display actual last backup time or "Never"
    if (stats.lastBackup) {
      document.getElementById('lastAccountBackup').textContent = new Date(stats.lastBackup).toLocaleString();
    } else {
      document.getElementById('lastAccountBackup').textContent = 'Never';
    }
  } catch (err) {
    console.error("Error loading account stats:", err);
    loadAccountStatsFromMock();
  }
}

function loadAccountStatsFromMock() {
  const data = mockAccountBackups;
  
  document.getElementById('totalAccountBackups').textContent = data.length;
  document.getElementById('successfulAccountBackups').textContent = data.filter(d => d.status === 'success').length;
  document.getElementById('failedAccountBackups').textContent = data.filter(d => d.status === 'failed').length;
  
  // ✅ Use the actual latest backup timestamp from the array
  if (data.length > 0) {
    document.getElementById('lastAccountBackup').textContent = new Date(data[0].date).toLocaleString();
  } else {
    document.getElementById('lastAccountBackup').textContent = 'Never';
  }
}


// Add error toast function (add near showSuccessToast around line 580)
function showErrorToast(message) {
  const toastContainer = document.createElement('div');
  toastContainer.className = 'position-fixed bottom-0 end-0 p-3';
  toastContainer.style.zIndex = '11';
  
  toastContainer.innerHTML = `
    <div class="toast show" role="alert">
      <div class="toast-header text-white bg-danger">
        <span class="material-icons-outlined me-2 text-sm">error</span>
        <strong class="me-auto">Error</strong>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
      </div>
      <div class="toast-body">
        ${message}
      </div>
    </div>`;
  
  document.body.appendChild(toastContainer);
  
  setTimeout(() => {
    toastContainer.remove();
  }, 4000);
}

function showSuccessToast(message) {
  const toastContainer = document.createElement('div');
  toastContainer.className = 'position-fixed bottom-0 end-0 p-3';
  toastContainer.style.zIndex = '11';
  
  toastContainer.innerHTML = `
    <div class="toast show" role="alert">
      <div class="toast-header text-white" style="background-color: #358F85;">
        <span class="material-icons-outlined me-2 text-sm">check_circle</span>
        <strong class="me-auto">Success</strong>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
      </div>
      <div class="toast-body">
        ${message}
      </div>
    </div>`;
  
  document.body.appendChild(toastContainer);
  
  setTimeout(() => {
    toastContainer.remove();
  }, 3000);
}

function renderAccounts() {
  const tbody = document.getElementById('accountTableBody');
  const state = tabStates.accounts;
  const start = (state.currentPage - 1) * logsPerPage;
  const end = start + logsPerPage;
  const paginatedData = state.filteredData.slice(start, end);

  tbody.innerHTML = '';

  if (paginatedData.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" class="px-6 py-8 text-center text-text-secondary-light">
          <span class="material-icons-outlined text-4xl mb-2">inbox</span>
          <p>No backup logs found</p>
        </td>
      </tr>`;
    return;
  }

  paginatedData.forEach(log => {
    const statusBadge = log.status === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700';
    const statusIcon = log.status === 'success' ? 'check_circle' : 'error';
    const typeBadge = log.type === 'Manual' ? 'bg-purple-100 text-purple-700' : 'bg-gray-100 text-gray-700';

    // ✅ FIX: Use log.id (MongoDB _id) instead of log.id
    const backupId = log.id || log._id;
    
    // Create a row element
    const row = document.createElement('tr');
    row.className = 'hover:bg-gray-50';
    
    row.innerHTML = `
      <td class="px-6 py-4">
        <span class="flex items-center px-3 py-1 text-xs font-semibold rounded-full ${statusBadge} w-fit">
          <span class="material-icons-outlined text-sm mr-1">${statusIcon}</span>
          ${log.status.charAt(0).toUpperCase() + log.status.slice(1)}
        </span>
      </td>
      <td class="px-6 py-4 text-sm">${new Date(log.date).toLocaleString()}</td>
      <td class="px-6 py-4">
        <span class="px-3 py-1 text-xs font-semibold rounded-full ${typeBadge}">${log.type}</span>
      </td>
      <td class="px-6 py-4 text-sm">${log.category}</td>
      <td class="px-6 py-4 text-sm">${log.records}</td>
      <td class="px-6 py-4 text-sm">${log.size}</td>
      <td class="px-6 py-4">
        <button class="view-btn text-primary hover:text-green-700 font-semibold text-sm flex items-center">
          <span class="material-icons-outlined text-sm mr-1">visibility</span>
          View
        </button>
      </td>
    `;
    
    // Add event listener to the button with the correct ID
    const viewBtn = row.querySelector('.view-btn');
    viewBtn.addEventListener('click', () => {
      console.log('Viewing backup with ID:', backupId); // Debug log
      viewDetails('account', backupId);
    });
    
    tbody.appendChild(row);
  });

  updatePagination('accounts');
}
// === ACTIVITY TAB ===
async function loadActivityStats() {
  try {
    // ✅ Fetch real activity logs from server
    const res = await fetch('http://localhost:5000/api/backup/activity/stats');
    const stats = await res.json();
    
    // Update stats display with actual backup data
    const backupLogs = await fetch('http://localhost:5000/api/backup/logs/activity');
    const logs = await backupLogs.json();
    
    document.getElementById('todaySessions').textContent = logs.length;
    document.getElementById('activeNow').textContent = logs.filter(l => l.status === 'success').length;
    document.getElementById('totalActivityRecords').textContent = stats.totalLogs;
    
    // Display last backup time
    if (logs.length > 0) {
      document.getElementById('avgSessionTime').textContent = 
        new Date(logs[0].date).toLocaleString();
    } else {
      document.getElementById('avgSessionTime').textContent = 'Never';
    }
  } catch (err) {
    console.error("Error loading activity stats:", err);
    loadActivityStatsFromMock();
  }
}

// ✅ Fallback function
function loadActivityStatsFromMock() {
  document.getElementById('todaySessions').textContent = '0';
  document.getElementById('activeNow').textContent = '0';
  document.getElementById('totalActivityRecords').textContent = '0';
  document.getElementById('avgSessionTime').textContent = 'Never';
}

function renderActivity() {
  const tbody = document.getElementById('activityTableBody');
  const state = tabStates.activity;
  const start = (state.currentPage - 1) * logsPerPage;
  const end = start + logsPerPage;
  const paginatedData = state.filteredData.slice(start, end);

  tbody.innerHTML = '';

  if (paginatedData.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="6" class="px-6 py-8 text-center text-text-secondary-light">
          <span class="material-icons-outlined text-4xl mb-2">inbox</span>
          <p>No activity backup logs found</p>
        </td>
      </tr>`;
    return;
  }

  paginatedData.forEach(log => {
    const statusBadge = log.status === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700';
    const statusIcon = log.status === 'success' ? 'check_circle' : 'error';
    const typeBadge = log.type === 'Manual' ? 'bg-purple-100 text-purple-700' : 'bg-gray-100 text-gray-700';
    
    const backupId = log.id || log._id;
    
    const row = document.createElement('tr');
    row.className = 'hover:bg-gray-50';
    
    row.innerHTML = `
      <td class="px-6 py-4">
        <span class="flex items-center px-3 py-1 text-xs font-semibold rounded-full ${statusBadge} w-fit">
          <span class="material-icons-outlined text-sm mr-1">${statusIcon}</span>
          ${log.status.charAt(0).toUpperCase() + log.status.slice(1)}
        </span>
      </td>
      <td class="px-6 py-4 text-sm">${new Date(log.date).toLocaleString()}</td>
      <td class="px-6 py-4">
        <span class="px-3 py-1 text-xs font-semibold rounded-full ${typeBadge}">${log.type}</span>
      </td>
      <td class="px-6 py-4 text-sm font-semibold">${log.records}</td>
      <td class="px-6 py-4 text-sm">${log.size}</td>
      <td class="px-6 py-4">
        <button class="view-btn text-primary hover:text-green-700 font-semibold text-sm flex items-center">
          <span class="material-icons-outlined text-sm mr-1">visibility</span>
          View
        </button>
      </td>
    `;
    
    const viewBtn = row.querySelector('.view-btn');
    viewBtn.addEventListener('click', () => {
      console.log('Viewing activity backup with ID:', backupId);
      viewActivityDetails(backupId);
    });
    
    tbody.appendChild(row);
  });

  updatePagination('activity');
}

// === PAGINATION ===
function updatePagination(tab) {
  const state = tabStates[tab];
  const start = (state.currentPage - 1) * logsPerPage + 1;
  const end = Math.min(start + logsPerPage - 1, state.filteredData.length);
  
  const prefix = tab === 'appointments' ? 'appointment' : tab === 'accounts' ? 'account' : 'activity';
  
  document.getElementById(`${prefix}ShowingStart`).textContent = state.filteredData.length > 0 ? start : 0;
  document.getElementById(`${prefix}ShowingEnd`).textContent = end;
  document.getElementById(`${prefix}TotalLogs`).textContent = state.filteredData.length;

  document.getElementById(`${prefix}PrevBtn`).disabled = state.currentPage === 1;
  document.getElementById(`${prefix}NextBtn`).disabled = end >= state.filteredData.length;
}

function previousPage(tab) {
  const state = tabStates[tab];
  if (state.currentPage > 1) {
    state.currentPage--;
    if (tab === 'appointments') renderAppointments();
    else if (tab === 'accounts') renderAccounts();
    else if (tab === 'activity') renderActivity();
  }
}

function nextPage(tab) {
  const state = tabStates[tab];
  if (state.currentPage * logsPerPage < state.filteredData.length) {
    state.currentPage++;
    if (tab === 'appointments') renderAppointments();
    else if (tab === 'accounts') renderAccounts();
    else if (tab === 'activity') renderActivity();
  }
}

// === VIEW DETAILS ===
async function viewDetails(type, id) {
  if (type === 'account') {
    try {
      console.log('📥 Fetching account backup details for ID:', id);
      
      const res = await fetch(`http://localhost:5000/api/backup/logs/${id}`);
      const data = await res.json();
      
      if (!res.ok) throw new Error('Backup not found');
      
      document.getElementById('detailsModalLabel').textContent = 'Account Backup Details';
      
      const statusClass = data.status === 'success' ? 'text-green-600' : 'text-red-600';
      const statusIcon = data.status === 'success' ? 'check_circle' : 'error';
      
      let content = `
        <div class="space-y-4">
          <div class="flex items-center space-x-2 pb-4 border-b">
            <span class="material-icons-outlined ${statusClass}">${statusIcon}</span>
            <h6 class="font-semibold ${statusClass}">${data.status.toUpperCase()}</h6>
          </div>
          
          <div class="grid grid-cols-2 gap-4">
            <div>
              <p class="text-sm text-gray-500">Backup ID</p>
              <p class="font-semibold">${data.backupId}</p>
            </div>
            <div>
              <p class="text-sm text-gray-500">Type</p>
              <p class="font-semibold">${data.type}</p>
            </div>
            <div>
              <p class="text-sm text-gray-500">Date & Time</p>
              <p class="font-semibold">${new Date(data.timestamp).toLocaleString()}</p>
            </div>
            <div>
              <p class="text-sm text-gray-500">Duration</p>
              <p class="font-semibold">${data.duration}</p>
            </div>
            <div>
              <p class="text-sm text-gray-500">Category</p>
              <p class="font-semibold">${data.category}</p>
            </div>
            <div>
              <p class="text-sm text-gray-500">Records Backed Up</p>
              <p class="font-semibold">${data.records.toLocaleString()}</p>
            </div>
            <div>
              <p class="text-sm text-gray-500">File Size</p>
              <p class="font-semibold">${data.size}</p>
            </div>
            <div>
              <p class="text-sm text-gray-500">Status</p>
              <p class="font-semibold ${statusClass}">${data.status.charAt(0).toUpperCase() + data.status.slice(1)}</p>
            </div>
          </div>

          <div class="pt-4 border-t">
            <p class="text-sm text-gray-500 mb-2">Details</p>
            <p class="text-sm">${data.details}</p>
          </div>

          <!-- Data Preview -->
          <div class="pt-4 border-t">
            <h6 class="font-semibold mb-3">Backup Data Preview</h6>
            
            <div class="mb-4">
              <p class="text-sm font-medium text-gray-700 mb-2">Users (${data.preview.totalUsers} total)</p>
              <div class="bg-gray-50 p-3 rounded max-h-40 overflow-y-auto">
                <pre class="text-xs">${JSON.stringify(data.preview.users, null, 2)}</pre>
              </div>
            </div>
            
            <div>
              <p class="text-sm font-medium text-gray-700 mb-2">Patients (${data.preview.totalPatients} total)</p>
              <div class="bg-gray-50 p-3 rounded max-h-40 overflow-y-auto">
                <pre class="text-xs">${JSON.stringify(data.preview.patients, null, 2)}</pre>
              </div>
            </div>
          </div>

          <!-- Download Button -->
          <div class="pt-4 border-t flex justify-end">
            <button onclick="downloadBackup('${id}')" class="bg-primary text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center">
              <span class="material-icons-outlined text-sm mr-2">download</span>
              Download Full Backup
            </button>
          </div>
        </div>`;
      
      document.getElementById('detailsContent').innerHTML = content;
      const modal = new bootstrap.Modal(document.getElementById('detailsModal'));
      modal.show();
      
    } catch (err) {
      console.error('Error loading account backup details:', err);
      showErrorToast('Failed to load backup details');
    }
  } else if (type === 'activity') {
    // Keep activity logic if needed, or remove if not used
    alert('Activity details view - implement if needed');
  }
}

// Download full backup data
async function downloadBackup(id) {
  try {
    const res = await fetch(`http://localhost:5000/api/backup/download/${id}`);
    
    if (!res.ok) throw new Error('Download failed');
    
    const data = await res.json();
    
    // Create blob and download
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `backup_${data.backupId}_${new Date(data.timestamp).toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    showSuccessToast('✅ Backup downloaded successfully!');
  } catch (err) {
    console.error('Download error:', err);
    showErrorToast('❌ Failed to download backup');
  }
}

// Load appointment backup logs from server
async function loadAppointmentBackupLogs() {
  try {
    console.log('📥 Loading appointment backup logs from database...');
    const res = await fetch('http://localhost:5000/api/backup/logs/appointments');
    const logs = await res.json();
    
    mockAppointmentBackups = logs;
    tabStates.appointments.filteredData = [...logs];
    
    console.log(`✅ Loaded ${logs.length} appointment backup logs from database`);
    
    if (currentTab === 'appointments') {
      await loadAppointmentStats();
      renderAppointments();
    }
  } catch (err) {
    console.error('Error loading appointment backup logs:', err);
  }
}

// Load appointment statistics
async function loadAppointmentStats() {
  try {
    const res = await fetch('http://localhost:5000/api/backup/appointments/stats');
    const stats = await res.json();
    
    document.getElementById('totalAppointmentBackups').textContent = mockAppointmentBackups.length;
    document.getElementById('successfulAppointmentBackups').textContent = 
      mockAppointmentBackups.filter(d => d.status === 'success').length;
    
    // New stats
    document.getElementById('activeAppointmentsCount').textContent = stats.totalActive;
    document.getElementById('archivedAppointmentsCount').textContent = stats.totalArchived;
    
    // ✅ Display actual last backup time or "Never"
    if (stats.lastBackup) {
      document.getElementById('lastAppointmentBackup').textContent = 
        new Date(stats.lastBackup).toLocaleString();
    } else {
      document.getElementById('lastAppointmentBackup').textContent = 'Never';
    }
  } catch (err) {
    console.error("Error loading appointment stats:", err);
    loadAppointmentStatsFromMock();
  }
}



// Render appointment backups table
function renderAppointments() {
  const tbody = document.getElementById('appointmentTableBody');
  const state = tabStates.appointments;
  const start = (state.currentPage - 1) * logsPerPage;
  const end = start + logsPerPage;
  const paginatedData = state.filteredData.slice(start, end);

  tbody.innerHTML = '';

  if (paginatedData.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="9" class="px-6 py-8 text-center text-text-secondary-light">
          <span class="material-icons-outlined text-4xl mb-2">inbox</span>
          <p>No backup logs found</p>
        </td>
      </tr>`;
    return;
  }

  paginatedData.forEach(log => {
    const statusBadge = log.status === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700';
    const statusIcon = log.status === 'success' ? 'check_circle' : 'error';
    const typeBadge = log.type === 'Manual' ? 'bg-purple-100 text-purple-700' : 'bg-gray-100 text-gray-700';
    
    // Determine scope badge
    let scopeBadge = 'scope-full';
    if (log.scope === 'Active Only') scopeBadge = 'scope-active';
    else if (log.scope === 'Archived Only') scopeBadge = 'scope-archived';
    
    // ✅ FIX: Get the correct MongoDB _id
    const backupId = log.id || log._id;
    
    const row = document.createElement('tr');
    row.className = 'hover:bg-gray-50';
    
    row.innerHTML = `
      <td class="px-6 py-4">
        <span class="flex items-center px-3 py-1 text-xs font-semibold rounded-full ${statusBadge} w-fit">
          <span class="material-icons-outlined text-sm mr-1">${statusIcon}</span>
          ${log.status.charAt(0).toUpperCase() + log.status.slice(1)}
        </span>
      </td>
      <td class="px-6 py-4 text-sm">${new Date(log.date).toLocaleString()}</td>
      <td class="px-6 py-4">
        <span class="px-3 py-1 text-xs font-semibold rounded-full ${typeBadge}">${log.type}</span>
      </td>
      <td class="px-6 py-4">
        <span class="scope-badge ${scopeBadge}">${log.scope || 'Full'}</span>
      </td>
      <td class="px-6 py-4 text-sm">
        <span class="text-blue-600 font-semibold">${log.activeCount || 0}</span>
      </td>
      <td class="px-6 py-4 text-sm">
        <span class="text-purple-600 font-semibold">${log.archivedCount || 0}</span>
      </td>
      <td class="px-6 py-4 text-sm font-semibold">${log.records}</td>
      <td class="px-6 py-4 text-sm">${log.size}</td>
      <td class="px-6 py-4">
        <button class="view-btn text-primary hover:text-green-700 font-semibold text-sm flex items-center">
          <span class="material-icons-outlined text-sm mr-1">visibility</span>
          View
        </button>
      </td>
    `;
    
    // ✅ Add event listener with correct ID
    const viewBtn = row.querySelector('.view-btn');
    viewBtn.addEventListener('click', () => {
      console.log('Viewing appointment backup with ID:', backupId);
      viewAppointmentDetails(backupId);  // Use dedicated function
    });
    
    tbody.appendChild(row);
  });

  updatePagination('appointments');
}

async function viewAppointmentDetails(id) {
  try {
    console.log('📥 Fetching appointment backup details for ID:', id);
    
    const res = await fetch(`http://localhost:5000/api/backup/logs/${id}`);
    
    if (!res.ok) {
      throw new Error('Backup not found');
    }
    
    const data = await res.json();
    
    if (!res.ok) throw new Error('Backup not found');
    
    document.getElementById('detailsModalLabel').textContent = 'Appointment Backup Details';
    
    const statusClass = data.status === 'success' ? 'text-green-600' : 'text-red-600';
    const statusIcon = data.status === 'success' ? 'check_circle' : 'error';
    
    let content = `
      <div class="space-y-4">
        <div class="flex items-center space-x-2 pb-4 border-b">
          <span class="material-icons-outlined ${statusClass}">${statusIcon}</span>
          <h6 class="font-semibold ${statusClass}">${data.status.toUpperCase()}</h6>
        </div>
        
        <div class="grid grid-cols-2 gap-4">
          <div>
            <p class="text-sm text-gray-500">Backup ID</p>
            <p class="font-semibold">${data.backupId}</p>
          </div>
          <div>
            <p class="text-sm text-gray-500">Type</p>
            <p class="font-semibold">${data.type}</p>
          </div>
          <div>
            <p class="text-sm text-gray-500">Date & Time</p>
            <p class="font-semibold">${new Date(data.timestamp).toLocaleString()}</p>
          </div>
          <div>
            <p class="text-sm text-gray-500">Duration</p>
            <p class="font-semibold">${data.duration}</p>
          </div>
          <div>
            <p class="text-sm text-gray-500">Scope</p>
            <p class="font-semibold">${data.scope || 'Full'}</p>
          </div>
          <div>
            <p class="text-sm text-gray-500">Total Records</p>
            <p class="font-semibold">${data.records.toLocaleString()}</p>
          </div>
          <div>
            <p class="text-sm text-gray-500">Active Appointments</p>
            <p class="font-semibold text-blue-600">${data.activeCount || 0}</p>
          </div>
          <div>
            <p class="text-sm text-gray-500">Archived Appointments</p>
            <p class="font-semibold text-purple-600">${data.archivedCount || 0}</p>
          </div>
          <div>
            <p class="text-sm text-gray-500">File Size</p>
            <p class="font-semibold">${data.size}</p>
          </div>
          <div>
            <p class="text-sm text-gray-500">Status</p>
            <p class="font-semibold ${statusClass}">${data.status.charAt(0).toUpperCase() + data.status.slice(1)}</p>
          </div>
        </div>

        <div class="pt-4 border-t">
          <p class="text-sm text-gray-500 mb-2">Details</p>
          <p class="text-sm">${data.details}</p>
        </div>

        <div class="pt-4 border-t flex justify-end">
          <button onclick="downloadBackup('${id}')" class="bg-primary text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center">
            <span class="material-icons-outlined text-sm mr-2">download</span>
            Download Full Backup
          </button>
        </div>
      </div>`;
    
    document.getElementById('detailsContent').innerHTML = content;
    const modal = new bootstrap.Modal(document.getElementById('detailsModal'));
    modal.show();
    
  } catch (err) {
    console.error('Error loading appointment backup details:', err);
    showErrorToast('Failed to load backup details');
  }
}

// View activity backup details
async function viewActivityDetails(id) {
  try {
    console.log('📥 Fetching activity backup details for ID:', id);
    
    const res = await fetch(`http://localhost:5000/api/backup/logs/${id}`);
    
    if (!res.ok) {
      throw new Error('Backup not found');
    }
    
    const data = await res.json();
    
    document.getElementById('detailsModalLabel').textContent = 'Activity Backup Details';
    
    const statusClass = data.status === 'success' ? 'text-green-600' : 'text-red-600';
    const statusIcon = data.status === 'success' ? 'check_circle' : 'error';
    
    let content = `
      <div class="space-y-4">
        <div class="flex items-center space-x-2 pb-4 border-b">
          <span class="material-icons-outlined ${statusClass}">${statusIcon}</span>
          <h6 class="font-semibold ${statusClass}">${data.status.toUpperCase()}</h6>
        </div>
        
        <div class="grid grid-cols-2 gap-4">
          <div>
            <p class="text-sm text-gray-500">Backup ID</p>
            <p class="font-semibold">${data.backupId}</p>
          </div>
          <div>
            <p class="text-sm text-gray-500">Type</p>
            <p class="font-semibold">${data.type}</p>
          </div>
          <div>
            <p class="text-sm text-gray-500">Date & Time</p>
            <p class="font-semibold">${new Date(data.timestamp).toLocaleString()}</p>
          </div>
          <div>
            <p class="text-sm text-gray-500">Duration</p>
            <p class="font-semibold">${data.duration}</p>
          </div>
          <div>
            <p class="text-sm text-gray-500">Category</p>
            <p class="font-semibold">${data.category}</p>
          </div>
          <div>
            <p class="text-sm text-gray-500">Total Activity Logs</p>
            <p class="font-semibold">${data.records.toLocaleString()}</p>
          </div>
          <div>
            <p class="text-sm text-gray-500">File Size</p>
            <p class="font-semibold">${data.size}</p>
          </div>
          <div>
            <p class="text-sm text-gray-500">Status</p>
            <p class="font-semibold ${statusClass}">${data.status.charAt(0).toUpperCase() + data.status.slice(1)}</p>
          </div>
        </div>

        <div class="pt-4 border-t">
          <p class="text-sm text-gray-500 mb-2">Details</p>
          <p class="text-sm">${data.details}</p>
        </div>

        <div class="pt-4 border-t flex justify-end">
          <button onclick="downloadBackup('${id}')" class="bg-primary text-white px-4 py-2 rounded-lg hover:bg-green-700 flex items-center">
            <span class="material-icons-outlined text-sm mr-2">download</span>
            Download Full Backup
          </button>
        </div>
      </div>`;
    
    document.getElementById('detailsContent').innerHTML = content;
    const modal = new bootstrap.Modal(document.getElementById('detailsModal'));
    modal.show();
    
  } catch (err) {
    console.error('Error loading activity backup details:', err);
    showErrorToast('Failed to load backup details');
  }
}

// Update the triggerManualBackup function to handle appointments
async function triggerManualBackup(type) {
  if (type === 'appointments') {
    const btn = event.target.closest('button');
    const originalText = btn.innerHTML;
    
    // Show scope selection modal
    const scope = await showBackupScopeModal();
    if (!scope) return; // User canceled
    
    btn.innerHTML = '<span class="material-icons-outlined mr-2 animate-spin">sync</span>Processing...';
    btn.disabled = true;
    
    try {
      const res = await fetch('http://localhost:5000/api/backup/appointments/manual', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scope })
      });
      
      const data = await res.json();
      
      if (res.ok) {
        showSuccessToast(`✅ ${scope === 'full' ? 'Full' : scope === 'active' ? 'Active' : 'Archived'} appointment backup completed!`);
        await loadAppointmentBackupLogs();
      } else {
        throw new Error(data.message);
      }
    } catch (err) {
      console.error('Backup error:', err);
      showErrorToast('❌ Backup failed: ' + err.message);
    } finally {
      btn.innerHTML = originalText;
      btn.disabled = false;
    }
  } else if (type === 'accounts') {
    // Keep existing account backup code
    const btn = event.target.closest('button');
    const originalText = btn.innerHTML;
    btn.innerHTML = '<span class="material-icons-outlined mr-2 animate-spin">sync</span>Processing...';
    btn.disabled = true;
    
    try {
      const res = await fetch('http://localhost:5000/api/backup/accounts/manual', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      
      const data = await res.json();
      
      if (res.ok) {
        showSuccessToast('✅ Manual backup completed successfully!');
        await loadBackupLogsFromServer();
      } else {
        throw new Error(data.message);
      }
    } catch (err) {
      console.error('Backup error:', err);
      showErrorToast('❌ Backup failed: ' + err.message);
    } finally {
      btn.innerHTML = originalText;
      btn.disabled = false;
    }
  }else if (type === 'activity') {
    const btn = event.target.closest('button');
    const originalText = btn.innerHTML;
    btn.innerHTML = '<span class="material-icons-outlined mr-2 animate-spin">sync</span>Processing...';
    btn.disabled = true;
    
    try {
      const res = await fetch('http://localhost:5000/api/backup/activity/manual', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
      });
      
      const data = await res.json();
      
      if (res.ok) {
        showSuccessToast('✅ Activity log backup completed successfully!');
        await loadActivityBackupLogs();
      } else {
        throw new Error(data.message);
      }
    } catch (err) {
      console.error('Backup error:', err);
      showErrorToast('❌ Backup failed: ' + err.message);
    } finally {
      btn.innerHTML = originalText;
      btn.disabled = false;
    }
  }
}

// Show backup scope selection modal
function showBackupScopeModal() {
  return new Promise((resolve) => {
    const modal = document.createElement('div');
    modal.className = 'modal fade show';
    modal.style.display = 'block';
    modal.style.backgroundColor = 'rgba(0,0,0,0.5)';
    
    modal.innerHTML = `
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
          <div class="modal-header text-white" style="background-color: #358f85;">
            <h5 class="modal-title">Select Backup Scope</h5>
            <button type="button" class="btn-close btn-close-white" id="closeScopeModal"></button>
          </div>
          <div class="modal-body">
            <p class="mb-3">Choose what to include in this backup:</p>
            <div class="list-group">
              <button type="button" class="list-group-item list-group-item-action scope-option" data-scope="full">
                <div class="d-flex w-100 justify-content-between">
                  <h6 class="mb-1">Full Backup</h6>
                  <span class="badge bg-purple-600">Recommended</span>
                </div>
                <p class="mb-1 text-sm">Includes all active and archived appointments</p>
              </button>
              <button type="button" class="list-group-item list-group-item-action scope-option" data-scope="active">
                <h6 class="mb-1">Active Appointments Only</h6>
                <p class="mb-1 text-sm">Upcoming and Ongoing appointments</p>
              </button>
              <button type="button" class="list-group-item list-group-item-action scope-option" data-scope="archived">
                <h6 class="mb-1">Archived Appointments Only</h6>
                <p class="mb-1 text-sm">Completed and Canceled appointments</p>
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
    
    document.body.appendChild(modal);
    
    // Handle scope selection
    modal.querySelectorAll('.scope-option').forEach(btn => {
      btn.addEventListener('click', () => {
        const scope = btn.getAttribute('data-scope');
        document.body.removeChild(modal);
        resolve(scope);
      });
    });
    
    // Handle close
    modal.querySelector('#closeScopeModal').addEventListener('click', () => {
      document.body.removeChild(modal);
      resolve(null);
    });
  });
}



// === FILTERS ===
document.getElementById('searchAppointments')?.addEventListener('input', (e) => {
  const search = e.target.value.toLowerCase();
  tabStates.appointments.filteredData = mockAppointmentBackups.filter(log => 
    log.details.toLowerCase().includes(search) || log.type.toLowerCase().includes(search)
  );
  tabStates.appointments.currentPage = 1;
  renderAppointments();
});

document.getElementById('filterAppointmentStatus')?.addEventListener('change', (e) => {
  const status = e.target.value;
  tabStates.appointments.filteredData = status === 'all' ? [...mockAppointmentBackups] : mockAppointmentBackups.filter(log => log.status === status);
  tabStates.appointments.currentPage = 1;
  renderAppointments();
});

document.getElementById('searchAccounts')?.addEventListener('input', (e) => {
  const search = e.target.value.toLowerCase();
  tabStates.accounts.filteredData = mockAccountBackups.filter(log => 
    log.details.toLowerCase().includes(search) || log.category.toLowerCase().includes(search)
  );
  tabStates.accounts.currentPage = 1;
  renderAccounts();
});

document.getElementById('filterAccountStatus')?.addEventListener('change', (e) => {
  const status = e.target.value;
  tabStates.accounts.filteredData = status === 'all' ? [...mockAccountBackups] : mockAccountBackups.filter(log => log.status === status);
  tabStates.accounts.currentPage = 1;
  renderAccounts();
});

document.getElementById('searchActivity')?.addEventListener('input', (e) => {
  const search = e.target.value.toLowerCase();
  tabStates.activity.filteredData = mockUserActivity.filter(log => 
    log.user.toLowerCase().includes(search)
  );
  tabStates.activity.currentPage = 1;
  renderActivity();
});

document.getElementById('filterActivityRole')?.addEventListener('change', (e) => {
  const role = e.target.value;
  tabStates.activity.filteredData = role === 'all' ? [...mockUserActivity] : mockUserActivity.filter(log => log.role === role);
  tabStates.activity.currentPage = 1;
  renderActivity();
});



function exportActivityLog() {
  alert('Activity log export will be downloaded as CSV.');
  // Implement CSV export here
}

function showLogoutModal() {
  const modal = new bootstrap.Modal(document.getElementById('logoutModal'));
  modal.show();
}

async function confirmLogout() {
  try {
    const sessionLogId = sessionStorage.getItem('sessionLogId');
    
    if (sessionLogId) {
      // ✅ NEW: Call logout API to record logout time and duration
      await fetch('http://localhost:5000/api/logout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionLogId })
      });
    }
  } catch (err) {
    console.error('Error logging logout:', err);
  } finally {
    sessionStorage.clear();
    window.location.href = '../emrLogin.html';
  }
}


// Initialize - Load all backup logs on page load
document.addEventListener('DOMContentLoaded', async () => {
  await loadBackupLogsFromServer(); // For accounts
  await loadAppointmentBackupLogs(); // For appointments
  await loadActivityBackupLogs(); // ✅ NEW: For activity logs
  
  // Initial render based on current tab
  if (currentTab === 'appointments') {
    await loadAppointmentStats();
    renderAppointments();
  } else if (currentTab === 'accounts') {
    await loadAccountStats();
    renderAccounts();
  } else if (currentTab === 'activity') {
    await loadActivityStats();
    renderActivity();
  }
});
// Auto-refresh backup logs every 5 seconds
setInterval(async () => {
  try {
    if (currentTab === 'accounts') {
      console.log('🔄 Auto-refreshing account backup logs...');
      const res = await fetch('http://localhost:5000/api/backup/logs/accounts');
      const logs = await res.json();
      
      mockAccountBackups = logs;
      tabStates.accounts.filteredData = [...logs];
      
      await loadAccountStats();
      renderAccounts();
      
      console.log(`✅ Auto-refresh: ${logs.length} account logs loaded`);
    } else if (currentTab === 'appointments') {
      console.log('🔄 Auto-refreshing appointment backup logs...');
      const res = await fetch('http://localhost:5000/api/backup/logs/appointments');
      const logs = await res.json();
      
      mockAppointmentBackups = logs;
      tabStates.appointments.filteredData = [...logs];
      
      await loadAppointmentStats();
      renderAppointments();
      
      console.log(`✅ Auto-refresh: ${logs.length} appointment logs loaded`);
    } else if (currentTab === 'activity') {
      // ✅ NEW: Add activity refresh
      console.log('🔄 Auto-refreshing activity backup logs...');
      const res = await fetch('http://localhost:5000/api/backup/logs/activity');
      const logs = await res.json();
      
      mockUserActivity = logs;
      tabStates.activity.filteredData = [...logs];
      
      await loadActivityStats();
      renderActivity();
      
      console.log(`✅ Auto-refresh: ${logs.length} activity logs loaded`);
    }
  } catch (err) {
    console.error('❌ Auto-refresh error:', err);
  }
}, 5000);