// ========== API KEYS (Hardcoded) ==========
const API_KEYS = {
    billing: "BILLING_API_KEY_12345ABCDEF",
    pharmacy: "PHARMACY_API_KEY_67890GHIJK"
};

// ========== Session Check ==========
(function() {
    const loggedIn = sessionStorage.getItem('loggedIn');
    const role = sessionStorage.getItem('role');
    if (loggedIn !== 'true' || role !== 'Admin') {
        window.location.href = 'emrLogin.html';
    }
})();

// ========== Logout Modal ==========
function showLogoutModal() {
    const logoutModal = new bootstrap.Modal(document.getElementById('logoutModal'));
    logoutModal.show();
}

document.addEventListener('DOMContentLoaded', () => {
    const confirmLogoutBtn = document.getElementById('confirmLogoutBtn');
    confirmLogoutBtn.addEventListener('click', () => {
        sessionStorage.clear();
        window.location.href = '../emrLogin.html';
    });
});

// ========== TAB MANAGEMENT ==========
document.addEventListener('DOMContentLoaded', () => {
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');

    const activateTab = (targetId) => {
        tabContents.forEach(c => c.classList.add('hidden'));
        tabButtons.forEach(btn => {
            btn.classList.remove('bg-gray-100', 'dark:bg-gray-700', 'border-gray-300', 'dark:border-gray-600', 'text-text-light', 'dark:text-text-dark');
            btn.classList.add('bg-surface-light', 'dark:bg-surface-dark', 'hover:bg-gray-50', 'dark:hover:bg-gray-700/50', 'border-border-light', 'dark:border-border-dark', 'font-medium', 'text-subtext-light', 'dark:text-subtext-dark');
        });
        const activeBtn = document.querySelector(`[data-target="${targetId}"]`);
        document.getElementById(targetId).classList.remove('hidden');
        activeBtn.classList.add('bg-gray-100', 'dark:bg-gray-700', 'border-gray-300', 'dark:border-gray-600', 'font-medium', 'text-text-light', 'dark:text-text-dark');
        activeBtn.classList.remove('bg-surface-light', 'dark:bg-surface-dark', 'hover:bg-gray-50', 'dark:hover:bg-gray-700/50', 'border-border-light', 'dark:border-border-dark', 'text-subtext-light', 'dark:text-subtext-dark');
    };

    tabButtons.forEach(btn => btn.addEventListener('click', e => {
        e.preventDefault();
        activateTab(btn.getAttribute('data-target'));
    }));

    // Default tab
    activateTab('content-integration');
});

// ========== TOAST ==========
function showToast(message) {
    const toast = document.createElement('div');
    toast.textContent = message;
    toast.className = "fixed bottom-6 right-6 bg-green-600 text-white px-4 py-2 rounded-lg shadow-lg text-sm animate-fadeIn";
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.classList.add("animate-fadeOut");
        setTimeout(() => toast.remove(), 500);
    }, 2000);
}

// ========== INTEGRATION TOGGLES ==========
const emrToggle = document.getElementById('emr-toggle');
const billingToggle = document.getElementById('billing-toggle');
const pharmacyToggle = document.getElementById('pharmacy-toggle');
const emrStatus = document.getElementById('emr-status');
const billingStatus = document.getElementById('billing-status');
const pharmacyStatus = document.getElementById('pharmacy-status');

function updateStatus(el, connected) {
    const badge = el.querySelector('span:last-child');
    if (connected) {
        badge.className = "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-success";
        badge.innerHTML = '<span class="material-icons-outlined text-sm mr-1">check_circle</span>Connected';
    } else {
        badge.className = "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-danger";
        badge.innerHTML = '<span class="material-icons-outlined text-sm mr-1">cancel</span>Disconnected';
    }
}

// Load current toggle status from server
async function loadIntegrationStatus() {
    try {
        const res = await fetch("http://localhost:5000/api/integration/status");
        const data = await res.json();
        emrToggle.checked = data.emr || false;
        billingToggle.checked = data.billing;
        pharmacyToggle.checked = data.pharmacy;
        updateStatus(emrStatus, data.emr || false);
        updateStatus(billingStatus, data.billing);
        updateStatus(pharmacyStatus, data.pharmacy);
    } catch (err) {
        console.error("Failed to load integration status:", err);
    }
}
loadIntegrationStatus();

// Save integration immediately on toggle change
emrToggle.addEventListener('change', async () => await saveIntegrationToggle());
billingToggle.addEventListener('change', async () => await saveIntegrationToggle());
pharmacyToggle.addEventListener('change', async () => await saveIntegrationToggle());

async function saveIntegrationToggle() {
    try {
        const res = await fetch("http://localhost:5000/api/integration/status", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                emr: emrToggle.checked,
                billing: billingToggle.checked,
                pharmacy: pharmacyToggle.checked
            })
        });
        const data = await res.json();
        updateStatus(emrStatus, data.integrationStatus.emr || false);
        updateStatus(billingStatus, data.integrationStatus.billing);
        updateStatus(pharmacyStatus, data.integrationStatus.pharmacy);
        showToast("✅ Integration settings updated!");
        
        // Broadcast change to other windows/tabs using localStorage
        localStorage.setItem('integrationStatusChanged', JSON.stringify({
            emr: data.integrationStatus.emr,
            billing: data.integrationStatus.billing,
            pharmacy: data.integrationStatus.pharmacy,
            timestamp: new Date().getTime()
        }));
    } catch (err) {
        console.error("Failed to save integration:", err);
        showToast("⚠️ Failed to update integration!");
    }
}

// Test integration button
document.getElementById('test-integration').addEventListener('click', async () => {
    try {
        const res = await fetch("http://localhost:5000/api/integration/test");
        const data = await res.json();
        document.getElementById('integrationStatus').textContent = JSON.stringify(data, null, 2);
        showToast("✅ Integration test completed!");
    } catch (err) {
        console.error("Integration test failed:", err);
        showToast("⚠️ Integration test failed!");
    }
});

// ========== BACKUP SETTINGS MODAL FUNCTIONS ==========
function openBackupSettingsModal() {
    const modal = new bootstrap.Modal(document.getElementById('backupSettingsModal'));
    modal.show();
    
    // Load saved settings if any
    loadBackupSettings();
}

function loadBackupSettings() {
    // Load from localStorage or use defaults
    const settings = JSON.parse(localStorage.getItem('backupSettings') || '{}');
    
    if (settings.appointment) {
        document.getElementById('appointmentFrequency').value = settings.appointment.frequency || 1;
        document.getElementById('appointmentUnit').value = settings.appointment.unit || 'days';
    }
    
    if (settings.account) {
        document.getElementById('accountFrequency').value = settings.account.frequency || 1;
        document.getElementById('accountUnit').value = settings.account.unit || 'days';
    }
    
    if (settings.activity) {
        document.getElementById('activityFrequency').value = settings.activity.frequency || 1;
        document.getElementById('activityUnit').value = settings.activity.unit || 'days';
    }
    
    // Load options
    document.getElementById('enableNotifications').checked = settings.enableNotifications !== false;
    document.getElementById('enableFailureAlerts').checked = settings.enableFailureAlerts !== false;
    document.getElementById('enableRetention').checked = settings.enableRetention !== false;
    
    updateNextBackupTimes();
}

async function saveBackupSettingsFromSettings() {
  const settings = {
    appointment: {
      frequency: parseInt(document.getElementById('appointmentFrequency').value),
      unit: document.getElementById('appointmentUnit').value
    },
    account: {
      frequency: parseInt(document.getElementById('accountFrequency').value),
      unit: document.getElementById('accountUnit').value
    },
    activity: {
      frequency: parseInt(document.getElementById('activityFrequency').value),
      unit: document.getElementById('activityUnit').value
    },
    enableNotifications: document.getElementById('enableNotifications').checked,
    enableFailureAlerts: document.getElementById('enableFailureAlerts').checked,
    enableRetention: document.getElementById('enableRetention').checked,
    lastUpdated: new Date().toISOString()
  };
  
  try {
    // Save to backend
    const res = await fetch('http://localhost:5000/api/backup/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings)
    });
    
    const data = await res.json();
    
    if (res.ok) {
      // Also save to localStorage as backup
      localStorage.setItem('backupSettings', JSON.stringify(settings));
      
      // Close modal
      const modal = bootstrap.Modal.getInstance(document.getElementById('backupSettingsModal'));
      modal.hide();
      
      // Show success message
      showSuccessToast('✅ Backup settings saved successfully!');
      
      console.log('Backup Settings Saved:', settings);
    } else {
      throw new Error(data.message);
    }
  } catch (err) {
    console.error('Error saving backup settings:', err);
    showSuccessToast('⚠️ Settings saved locally only (server unavailable)');
    
    // Still save to localStorage
    localStorage.setItem('backupSettings', JSON.stringify(settings));
    
    const modal = bootstrap.Modal.getInstance(document.getElementById('backupSettingsModal'));
    modal.hide();
  }
}

// Update loadBackupSettings to fetch from server
async function loadBackupSettings() {
  try {
    // Try to fetch from server first
    const res = await fetch('http://localhost:5000/api/backup/settings');
    const settings = await res.json();
    
    applySettings(settings);
  } catch (err) {
    // Fallback to localStorage
    const settings = JSON.parse(localStorage.getItem('backupSettings') || '{}');
    applySettings(settings);
  }
}

function applySettings(settings) {
  if (settings.appointment) {
    document.getElementById('appointmentFrequency').value = settings.appointment.frequency || 1;
    document.getElementById('appointmentUnit').value = settings.appointment.unit || 'days';
  }
  
  if (settings.account) {
    document.getElementById('accountFrequency').value = settings.account.frequency || 1;
    document.getElementById('accountUnit').value = settings.account.unit || 'days';
  }
  
  if (settings.activity) {
    document.getElementById('activityFrequency').value = settings.activity.frequency || 1;
    document.getElementById('activityUnit').value = settings.activity.unit || 'days';
  }
  
  document.getElementById('enableNotifications').checked = settings.enableNotifications !== false;
  document.getElementById('enableFailureAlerts').checked = settings.enableFailureAlerts !== false;
  document.getElementById('enableRetention').checked = settings.enableRetention !== false;
  
  updateNextBackupTimes();
}

function updateNextBackupTimes() {
    const now = new Date();
    
    // Calculate next backup times based on frequency
    const appointmentFreq = parseInt(document.getElementById('appointmentFrequency').value);
    const appointmentUnit = document.getElementById('appointmentUnit').value;
    const appointmentNext = calculateNextBackup(now, appointmentFreq, appointmentUnit);
    document.getElementById('appointmentNextBackup').textContent = appointmentNext.toLocaleString();
    
    const accountFreq = parseInt(document.getElementById('accountFrequency').value);
    const accountUnit = document.getElementById('accountUnit').value;
    const accountNext = calculateNextBackup(now, accountFreq, accountUnit);
    document.getElementById('accountNextBackup').textContent = accountNext.toLocaleString();
    
    const activityFreq = parseInt(document.getElementById('activityFrequency').value);
    const activityUnit = document.getElementById('activityUnit').value;
    const activityNext = calculateNextBackup(now, activityFreq, activityUnit);
    document.getElementById('activityNextBackup').textContent = activityNext.toLocaleString();
}

function calculateNextBackup(baseDate, frequency, unit) {
    const next = new Date(baseDate);
    
    switch(unit) {
        case 'seconds':
            next.setSeconds(next.getSeconds() + frequency);
            break;
        case 'minutes':
            next.setMinutes(next.getMinutes() + frequency);
            break;
        case 'hours':
            next.setHours(next.getHours() + frequency);
            break;
        case 'days':
            next.setDate(next.getDate() + frequency);
            break;
        case 'months':
            next.setMonth(next.getMonth() + frequency);
            break;
        case 'years':
            next.setFullYear(next.getFullYear() + frequency);
            break;
    }
    
    return next;
}

function showSuccessToast(message) {
    const toastContainer = document.createElement('div');
    toastContainer.className = 'position-fixed bottom-0 end-0 p-3';
    toastContainer.style.zIndex = '11';
    
    toastContainer.innerHTML = `
        <div class="toast show" role="alert">
            <div class="toast-header text-white" style="background-color: #358F85;">
                <span class="material-icons-outlined me-2 text-sm">check_circle</span>
                <strong class="me-auto">Success</strong>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast"></button>
            </div>
            <div class="toast-body">
                ${message}
            </div>
        </div>`;
    
    document.body.appendChild(toastContainer);
    
    setTimeout(() => {
        toastContainer.remove();
    }, 3000);
}

// Add event listeners for backup settings inputs to update next backup times
document.addEventListener('DOMContentLoaded', () => {
    const frequencyInputs = ['appointmentFrequency', 'accountFrequency', 'activityFrequency'];
    const unitSelects = ['appointmentUnit', 'accountUnit', 'activityUnit'];
    
    frequencyInputs.forEach(id => {
        const input = document.getElementById(id);
        if (input) {
            input.addEventListener('change', updateNextBackupTimes);
        }
    });
    
    unitSelects.forEach(id => {
        const select = document.getElementById(id);
        if (select) {
            select.addEventListener('change', updateNextBackupTimes);
   
     }
    });
});