(function() {
      const loggedIn = sessionStorage.getItem('loggedIn');
      const role = sessionStorage.getItem('role');
      if (loggedIn !== 'true' || role !== 'Admin') {
        window.location.href = 'emrLogin.html';
      }
    })();

function showLogoutModal() {
  const logoutModal = new bootstrap.Modal(document.getElementById('logoutModal'));
  logoutModal.show();
}

document.addEventListener('DOMContentLoaded', () => {
  const confirmLogoutBtn = document.getElementById('confirmLogoutBtn');
  confirmLogoutBtn.addEventListener('click', () => {
    sessionStorage.clear();
    window.location.href = '../emrLogin.html';
  });
});



      let archiveData = [];
  let actionCallback = null;
  const tbody = document.getElementById("archiveTable");
  const empty = document.getElementById("emptyArchive");
  const searchInput = document.getElementById("archiveSearch");
  const confirmModal = document.getElementById("confirmModal");
  const confirmTitle = document.getElementById("confirmTitle");
  const confirmMessage = document.getElementById("confirmMessage");
  const confirmActionBtn = document.getElementById("confirmActionBtn");

  async function fetchArchive() {
    try {
      const res = await fetch("http://localhost:5000/api/archive");
      archiveData = await res.json();
      loadArchive();
    } catch (err) {
      console.error("Error fetching archive:", err);
    }
  }

  function loadArchive(filter = "") {
    tbody.innerHTML = "";
    const filtered = archiveData.filter(record =>
      record.name.toLowerCase().includes(filter) ||
      record.email.toLowerCase().includes(filter) ||
      record.role.toLowerCase().includes(filter) ||
      record.userId.toLowerCase().includes(filter)
    );

    if (filtered.length === 0) {
      empty.classList.remove("hidden");
      return;
    }
    empty.classList.add("hidden");

    filtered.forEach(record => {
      let roleColorClass = record.role === "Admin" ? "bg-purple-200 text-purple-900"
                        : record.role === "Doctor" ? "bg-blue-900 text-white"
                        : "bg-blue-200 text-blue-800";

      let idBadge = record.userId.startsWith("A") ? `<span class="px-2 py-1 text-xs font-semibold bg-purple-100 text-purple-700 rounded-full">${record.userId}</span>`
                  : record.userId.startsWith("D") ? `<span class="px-2 py-1 text-xs font-semibold bg-blue-900 text-white rounded-full">${record.userId}</span>`
                  : record.userId.startsWith("N") ? `<span class="px-2 py-1 text-xs font-semibold bg-blue-200 text-blue-800 rounded-full">${record.userId}</span>`
                  : record.userId;

      tbody.innerHTML += `
        <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
          <td class="py-3 px-4">${idBadge}</td>
          <td class="py-3 px-4">${record.name}</td>
          <td class="py-3 px-4">${record.email}</td>
          <td class="py-3 px-4">
            <span class="px-2 py-1 rounded-full text-xs font-medium ${roleColorClass}">
              ${record.role}
            </span>
          </td>
          <td class="py-3 px-4">${new Date(record.archivedOn).toLocaleString()}</td>
          <td class="py-3 px-4 flex items-center justify-center space-x-3">
            <button onclick="showConfirmModal('Restore User', 'Restore user ${record.name}?', () => restoreUser('${record._id}'))" class="relative group text-green-600 hover:text-green-800">
              <span class="material-icons-outlined">restore</span>
              <span class="absolute bottom-full mb-2 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition bg-gray-900 text-white text-xs rounded py-1 px-2 whitespace-nowrap">Restore User</span>
            </button>
            <button onclick="showConfirmModal('Delete Permanently', 'Permanently delete user ${record.name}? This cannot be undone.', () => deleteUser('${record._id}'))" class="relative group text-red-600 hover:text-red-800">
              <span class="material-icons-outlined">delete</span>
              <span class="absolute bottom-full mb-2 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition bg-gray-900 text-white text-xs rounded py-1 px-2 whitespace-nowrap">Delete Permanently</span>
            </button>
          </td>
        </tr>`;
    });
  }

  function showConfirmModal(title, message, callback) {
    confirmTitle.textContent = title;
    confirmMessage.textContent = message;
    actionCallback = callback;
    confirmModal.classList.remove("hidden");
  }

  function closeConfirmModal() {
    confirmModal.classList.add("hidden");
    actionCallback = null;
  }

  confirmActionBtn.addEventListener("click", () => {
    if (actionCallback) actionCallback();
    closeConfirmModal();
  });

  async function restoreUser(id) {
  try {
    const res = await fetch(`http://localhost:5000/api/archive/restore/${id}`, { 
      method: "POST" 
    });
    
    const data = await res.json();
    
    if (res.ok) {
      alert(`✅ ${data.message}\n\nUser ID: ${data.user.userId}\nEmail: ${data.user.email}\n\nTemporary Password: Temp@123`);
      fetchArchive();
    } else {
      alert(`❌ ${data.message}`);
    }
  } catch (err) {
    console.error("Error restoring user:", err);
    alert("❌ Network error: Unable to restore user");
  }
}
  async function deleteUser(id) {
    const res = await fetch(`http://localhost:5000/api/archive/${id}`, { method: "DELETE" });
    const data = await res.json();
    alert(data.message);
    fetchArchive();
  }

  searchInput.addEventListener("input", (e) => loadArchive(e.target.value.toLowerCase()));
  fetchArchive();