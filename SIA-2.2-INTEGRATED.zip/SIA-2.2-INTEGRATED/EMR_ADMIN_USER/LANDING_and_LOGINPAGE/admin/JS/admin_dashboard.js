(function() {
  const loggedIn = sessionStorage.getItem('loggedIn');
  const role = sessionStorage.getItem('role');
  if (loggedIn !== 'true' || role !== 'Admin') {
    window.location.href = 'emrLogin.html';
  }
})();

function showLogoutModal() {
  const logoutModal = new bootstrap.Modal(document.getElementById('logoutModal'));
  logoutModal.show();
}

document.addEventListener('DOMContentLoaded', () => {
  const confirmLogoutBtn = document.getElementById('confirmLogoutBtn');
  confirmLogoutBtn.addEventListener('click', () => {
    sessionStorage.clear();
    window.location.href = '../emrLogin.html';
  });
});

const API_URL = "http://localhost:5000/api/users";

async function loadDashboard() {
  try {
    const res = await fetch(API_URL);
    const users = await res.json();

    // Counts
    document.getElementById("totalUsers").textContent = users.length;
    document.getElementById("activeUsers").textContent = users.filter(u => u.status === "Active").length;
    document.getElementById("inactiveUsers").textContent = users.filter(u => u.status === "Inactive").length;

    // Recent Logins with Role Badges beside the name
    const recentLoginsDiv = document.getElementById("recentLogins");
    recentLoginsDiv.innerHTML = "";
    users
      .filter(u => u.lastLogin)
      .sort((a, b) => new Date(b.lastLogin) - new Date(a.lastLogin))
      .slice(0, 5)
      .forEach(user => {
        const initials = user.name.split(" ").map(n => n[0]).join("").toUpperCase();

        // Role color badge
        let roleBadge = "";
        if (user.role === "Admin") roleBadge = "bg-purple-100 text-purple-700";
        else if (user.role === "Doctor") roleBadge = "bg-blue-900 text-white";
        else if (user.role === "Nurse") roleBadge = "bg-blue-200 text-blue-800";

        recentLoginsDiv.innerHTML += `
          <div class="flex items-center justify-between">
            <div class="flex items-center">
              <div class="w-10 h-10 rounded-full bg-green-200 flex items-center justify-center mr-3">
                <span class="font-bold text-primary">${initials}</span>
              </div>
              <div class="flex flex-col">
                <p class="font-medium flex items-center space-x-2">
                  <span>${user.name}</span>
                  <span class="px-2 py-1 text-xs font-semibold rounded-full ${roleBadge}">${user.role}</span>
                </p>
              </div>
            </div>
            <p class="text-sm text-text-secondary-light">${new Date(user.lastLogin).toLocaleString()}</p>
          </div>`;
      });
  } catch (err) {
    console.error("Dashboard load error:", err);
  }
}

// System Alerts Handler
function loadSystemAlerts(alerts = []) {
  const alertsDiv = document.getElementById("alerts");
  alertsDiv.innerHTML = "";

  if (alerts.length === 0) {
    alertsDiv.innerHTML = `
      <div class="flex items-center justify-between p-4 rounded-lg border border-border-light">
        <div class="flex items-center">
          <span class="material-icons-outlined text-blue-500 mr-3">info_outline</span>
          <p>System running normally</p>
        </div>
        <p class="text-sm text-text-secondary-light">Just now</p>
      </div>`;
  } else {
    alerts.forEach(alert => {
      alertsDiv.innerHTML += `
        <div class="flex items-center justify-between p-4 rounded-lg border border-border-light">
          <div class="flex items-center">
            <span class="material-icons-outlined ${alert.iconColor} mr-3">${alert.icon}</span>
            <p>${alert.message}</p>
          </div>
          <p class="text-sm text-text-secondary-light">${alert.time}</p>
        </div>`;
    });
  }
}

// ✅ Load Integration Status from API
async function loadIntegrationStatus() {
  try {
    const res = await fetch("http://localhost:5000/api/integration/status");
    const data = await res.json();
    
    // Update EMR Status
    const emrStatus = document.getElementById("emrStatus");
    if (data.emr) {
      emrStatus.className = "flex items-center text-sm bg-green-100 text-green-700 px-2 py-1 rounded-full";
      emrStatus.innerHTML = `<span class="material-icons-outlined text-sm mr-1">check_circle</span> Connected`;
    } else {
      emrStatus.className = "flex items-center text-sm bg-red-100 text-red-700 px-2 py-1 rounded-full";
      emrStatus.innerHTML = `<span class="material-icons-outlined text-sm mr-1">cancel</span> Disconnected`;
    }
    
    // Update Pharmacy Status
    const pharmacyStatus = document.getElementById("pharmacyStatus");
    if (data.pharmacy) {
      pharmacyStatus.className = "flex items-center text-sm bg-green-100 text-green-700 px-2 py-1 rounded-full";
      pharmacyStatus.innerHTML = `<span class="material-icons-outlined text-sm mr-1">check_circle</span> Connected`;
    } else {
      pharmacyStatus.className = "flex items-center text-sm bg-red-100 text-red-700 px-2 py-1 rounded-full";
      pharmacyStatus.innerHTML = `<span class="material-icons-outlined text-sm mr-1">cancel</span> Disconnected`;
    }
    
    // Update Billing Status
    const billingStatus = document.getElementById("billingStatus");
    if (data.billing) {
      billingStatus.className = "flex items-center text-sm bg-green-100 text-green-700 px-2 py-1 rounded-full";
      billingStatus.innerHTML = `<span class="material-icons-outlined text-sm mr-1">check_circle</span> Connected`;
    } else {
      billingStatus.className = "flex items-center text-sm bg-red-100 text-red-700 px-2 py-1 rounded-full";
      billingStatus.innerHTML = `<span class="material-icons-outlined text-sm mr-1">cancel</span> Disconnected`;
    }
  } catch (err) {
    console.error("Failed to load integration status:", err);
  }
}

loadDashboard();
loadSystemAlerts();
loadIntegrationStatus();
// Refresh integration status every 5 seconds
setInterval(loadIntegrationStatus, 5000);

// Listen for integration status changes from other tabs/windows
window.addEventListener('storage', (event) => {
  if (event.key === 'integrationStatusChanged') {
    loadIntegrationStatus();
  }
});