async function loadSidebar(activePage) {
  const sidebarHTML = `
    <section class="sideBar">
      <div class="logoCon">
        <i class="logo fa-solid fa-stethoscope"></i>
        <div class="titleCon">
          <h1 class="title">MediSys</h1>
          <h2 class="subTitle">Medical Portal</h2>
        </div>
      </div>

      <div class="accountCon">
        <div class="userPic" style="text-align: center; padding-top: 5px; color: white; font-size: 20px;">DS</div>
        <div class="accountInfo">
          <h2 class="accountName">Dr. Stone</h2>
          <h3 class="role">Medical Staff</h3>
        </div>
      </div>

      <div class="navBar">
        <a href="Dashboard.html"><img src="Assets/dashboard.png" alt=""><h3 class="dashboard">Dashboard</h3></a>
        <a href="Patients.html" id="patientsNavLink" style="display: none;"><i class="fa-solid fa-clipboard-user"></i><h3 class="dashboard">Patients</h3></a>
        <a href="Appointments.html"><i class="far fa-calendar"></i><h3 class="dashboard">Appointments</h3></a>
        <a href="Archive.html"><i class="fa-solid fa-clock-rotate-left"></i><h3 class="dashboard">History</h3></a>
        <a href="Report.html" id="reportsNavLink" style="display: none;"><i class="far fa-file-alt"></i><h3 class="dashboard">Reports</h3></a>
      </div>

      <div class="logoutCon">
        <a href="#" id="logoutBtn" style="color: red;">
          <i class="fa-solid fa-arrow-right-from-bracket"></i>
          <h3 style="color: red;" class="dashboard">Logout</h3>
        </a>
      </div>

      <!-- 🔒 Logout Confirmation Modal -->
      <div id="logoutModal" class="customModal hidden">
        <div class="customModalContent">
          <h3>Confirm Logout</h3>
          <p>Are you sure you want to log out?</p>
          <div class="modalButtons">
            <button id="cancelLogoutBtn" class="cancelBtn">Cancel</button>
            <button id="confirmLogoutBtn" class="confirmBtn">Logout</button>
          </div>
        </div>
      </div>

      <!-- ✅ Success Modal -->
      <div id="successModal" class="customModal hidden">
        <div class="customModalContent">
          <h3>Logout Successful</h3>
          <p>You have been logged out successfully.</p>
        </div>
      </div>
    </section>
  `;

  document.body.insertAdjacentHTML("afterbegin", sidebarHTML);

  // Highlight active link
  const links = document.querySelectorAll(".navBar a");
  links.forEach(link => {
    if (link.href.includes(activePage)) {
      link.style.backgroundColor = "rgb(235, 255, 224)";
      link.style.color = "#358F85";
      const icon = link.querySelector("i, img");
      const text = link.querySelector("h3");
      if (icon) icon.style.color = "#358F85";
      if (text) text.style.color = "#358F85";
    }
  });

  // Load user info
  const name = sessionStorage.getItem("name");
  const role = sessionStorage.getItem("role");

  if (!name || !role) {
    alert("Session expired. Please log in again.");
    window.location.href = "../emrLogin.html";
    return;
  }

  document.querySelector(".accountName").textContent = name;
  document.querySelector(".role").textContent = role;

  const initials = name.split(" ").map(n => n[0].toUpperCase()).join("");
  document.querySelector(".userPic").textContent = initials;

  // ✅ Role-based access control: Show/hide navigation items
  const patientsNavLink = document.getElementById("patientsNavLink");
  const reportsNavLink = document.getElementById("reportsNavLink");
  
  if (role === "Doctor") {
    // Doctors can't access Patients tab or Reports tab
    if (patientsNavLink) patientsNavLink.style.display = "none";
    if (reportsNavLink) reportsNavLink.style.display = "none";
  } else if (role === "Nurse") {
    // Nurses can access both
    if (patientsNavLink) patientsNavLink.style.display = "flex";
    if (reportsNavLink) reportsNavLink.style.display = "flex";
  } else {
    // Admin or other roles - show all
    if (patientsNavLink) patientsNavLink.style.display = "flex";
    if (reportsNavLink) reportsNavLink.style.display = "flex";
  }

  // Logout modal elements
  const logoutBtn = document.getElementById("logoutBtn");
  const logoutModal = document.getElementById("logoutModal");
  const confirmLogoutBtn = document.getElementById("confirmLogoutBtn");
  const cancelLogoutBtn = document.getElementById("cancelLogoutBtn");
  const successModal = document.getElementById("successModal");

  logoutBtn.addEventListener("click", e => {
    e.preventDefault();
    logoutModal.classList.remove("hidden");
  });

  cancelLogoutBtn.addEventListener("click", () => {
    logoutModal.classList.add("hidden");
  });

  confirmLogoutBtn.addEventListener("click", async () => {
  try {
    const sessionLogId = sessionStorage.getItem('sessionLogId');
    
    // ✅ Call logout API to record logout time and duration
    if (sessionLogId) {
      await fetch('http://localhost:5000/api/logout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionLogId })
      });
    }
    
    sessionStorage.clear();
    logoutModal.classList.add("hidden");
    successModal.classList.remove("hidden");

    setTimeout(() => {
      successModal.classList.add("hidden");
      window.location.href = "../emrLogin.html";
    }, 1200);
  } catch (error) {
    console.error("Logout failed:", error);
    alert("⚠️ There was a problem logging out. Please try again.");
  }
});
}
