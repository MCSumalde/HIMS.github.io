// Load Active Patients into Dropdown
async function loadPatientsDropdown() {
    const select = document.getElementById("selectPatient");

    try {
        const res = await fetch("http://localhost:5000/api/patients");
        if (!res.ok) throw new Error("Failed to fetch patients");
        const patients = await res.json();

        console.log('📊 Total patients fetched:', patients.length);
        
        // ✅ Filter Active patients (case-insensitive + handle missing status)
        const activePatients = patients.filter(p => {
            // If status is missing, undefined, null, or empty, treat as Active
            if (!p.status || p.status === '') {
                console.log(`⚠️ Patient ${p.patientId} has no status, treating as Active`);
                return true;
            }
            // Check for "Active" (case-insensitive)
            const isActive = p.status.toLowerCase() === "active";
            console.log(`Patient ${p.patientId} - Status: "${p.status}" - Active: ${isActive}`);
            return isActive;
        });

        console.log('✅ Active patients found:', activePatients.length);
        console.log('Active patients:', activePatients.map(p => ({
            id: p.patientId,
            name: `${p.firstname} ${p.lastname}`,
            status: p.status
        })));

        if (activePatients.length === 0) {
            select.innerHTML = `<option value="">No Active patients found</option>`;
            
            // ✅ Show warning in console
            console.warn('⚠️ No active patients found! All patients:');
            patients.forEach(p => {
                console.log(`  - ${p.patientId}: ${p.firstname} ${p.lastname} (Status: "${p.status}")`);
            });
            
            return;
        }

        select.innerHTML = `
            <option value="">Select Patient</option>
            ${activePatients.map(p => `
                <option value="${p.patientId}">
                    ${p.firstname} ${p.lastname} (${p.patientId})
                </option>
            `).join("")}
        `;
        
        console.log('✅ Patient dropdown populated successfully');
    } catch (err) {
        console.error("❌ Error loading patients:", err);
        select.innerHTML = `<option value="">Error loading patients</option>`;
    }
}

// Load Active Doctors into Dropdown
async function loadDoctorsDropdown() {
    const select = document.getElementById("selectDoctor");

    try {
        const res = await fetch("http://localhost:5000/api/users");
        if (!res.ok) throw new Error("Failed to fetch doctors");
        const users = await res.json();

        // Filter only active doctors
        const doctors = users.filter(u => u.role === "Doctor" && u.status === "Active");

        if (doctors.length === 0) {
            select.innerHTML = `<option value="">No doctors found</option>`;
            return;
        }

        select.innerHTML = `
            <option value="">Select Doctor</option>
            ${doctors.map(d => `
                <option value="${d.userId || d._id}">
                    Dr. ${d.name} (${d.userId || d._id})
                </option>
            `).join("")}
        `;
    } catch (err) {
        console.error("Error loading doctors:", err);
        select.innerHTML = `<option value="">Error loading doctors</option>`;
    }
}

// Load Services from Billing System
async function loadServicesDropdown() {
    const select = document.getElementById("appType");

    try {
        const res = await fetch("http://localhost:5000/api/integrations/billing/services");
        if (!res.ok) {
            throw new Error("Failed to fetch services");
        }
        
        const result = await res.json();
        
        if (!result.success || !result.data) {
            throw new Error("Invalid response from services API");
        }

        const services = result.data;

        if (services.length === 0) {
            select.innerHTML = `<option value="">No services found</option>`;
            console.warn("⚠️ No services found in billing system");
            return;
        }

        // Clear existing options except the placeholder
        select.innerHTML = '<option value="">Search and select a service...</option>';
        
        // Add services to dropdown
        services.forEach(service => {
            const option = document.createElement("option");
            option.value = service.service; // Use service name as value
            option.textContent = `${service.service}${service.category ? ` (${service.category})` : ''}${service.price ? ` - ₱${service.price.toFixed(2)}` : ''}`;
            option.setAttribute("data-price", service.price || 0);
            option.setAttribute("data-category", service.category || "");
            option.setAttribute("data-code", service.code || "");
            select.appendChild(option);
        });

        console.log(`✅ Loaded ${services.length} services from billing system`);
    } catch (err) {
        console.error("❌ Error loading services:", err);
        select.innerHTML = `<option value="">Error loading services. Please try again.</option>`;
    }
}

// Initialize page on load
window.onload = async () => {
    await loadPatientsDropdown();
    await loadDoctorsDropdown();
    await loadServicesDropdown();

    // Make Select Patient searchable
    $(document).ready(function () {
        $("#selectPatient").select2({
            placeholder: "Search for a patient",
            allowClear: true,
            width: "100%"
        });

        // Make Select Doctor searchable
        $("#selectDoctor").select2({
            placeholder: "Search for a doctor",
            allowClear: true,
            width: "100%"
        });

        // Make Service Type searchable
        $("#appType").select2({
            placeholder: "Search and select a service...",
            allowClear: true,
            width: "100%",
            minimumInputLength: 0 // Allow searching from the start
        });
    });

    // ✅ Restrict appointment date to today and onwards
    const dateInput = document.getElementById("appDate");
    const timeInput = document.getElementById("appTime");
    const today = new Date().toISOString().split("T")[0];
    dateInput.setAttribute("min", today);
    
    // ✅ Validate date and time on change
    dateInput.addEventListener("change", validateDateTime);
    timeInput.addEventListener("change", validateDateTime);
    
    // ✅ Initial validation
    validateDateTime();
};

// ✅ Validate date and time (prevent past dates/times)
function validateDateTime() {
    const dateInput = document.getElementById("appDate");
    const timeInput = document.getElementById("appTime");
    
    if (!dateInput || !timeInput) return;
    
    const selectedDate = dateInput.value;
    const selectedTime = timeInput.value;
    const today = new Date();
    const todayStr = today.toISOString().split("T")[0];
    
    // If date is today, validate time
    if (selectedDate === todayStr && selectedTime) {
        const now = new Date();
        const currentHours = now.getHours();
        const currentMinutes = now.getMinutes();
        const [selectedHours, selectedMinutes] = selectedTime.split(":").map(Number);
        
        // Check if selected time is in the past
        if (selectedHours < currentHours || (selectedHours === currentHours && selectedMinutes <= currentMinutes)) {
            alert("⚠️ Cannot schedule appointment in the past. Please select a future time.");
            // Set time to current time + 30 minutes
            const futureTime = new Date(now.getTime() + 30 * 60000);
            const futureHours = String(futureTime.getHours()).padStart(2, "0");
            const futureMinutes = String(futureTime.getMinutes()).padStart(2, "0");
            timeInput.value = `${futureHours}:${futureMinutes}`;
        }
    }
    
    // Validate date is not in the past
    if (selectedDate && selectedDate < todayStr) {
        alert("⚠️ Cannot schedule appointment in the past. Please select today or a future date.");
        dateInput.value = todayStr;
    }
}

// Handle form submission
document.getElementById("addPatient").addEventListener("submit", async (e) => {
    e.preventDefault();

    const patientSelect = document.getElementById("selectPatient");
    const doctorSelect = document.getElementById("selectDoctor");

    // ✅ Extract ONLY the name, not the full option text
    const patientOptionText = patientSelect.options[patientSelect.selectedIndex].text;
    const doctorOptionText = doctorSelect.options[doctorSelect.selectedIndex].text;

    // Remove the ID part in parentheses: "Emzcee Sumalde (P003)" → "Emzcee Sumalde"
    const patientName = patientOptionText.replace(/\s*\([^)]*\)\s*$/, '').trim();
    const doctorName = doctorOptionText.replace(/\s*\([^)]*\)\s*$/, '').trim();

    // ✅ Final validation before submission
    const selectedDate = document.getElementById("appDate").value;
    const selectedTime = document.getElementById("appTime").value;
    const today = new Date();
    const todayStr = today.toISOString().split("T")[0];
    
    if (selectedDate < todayStr) {
        alert("❌ Cannot schedule appointment in the past. Please select today or a future date.");
        return;
    }
    
    if (selectedDate === todayStr && selectedTime) {
        const [selectedHours, selectedMinutes] = selectedTime.split(":").map(Number);
        const currentHours = today.getHours();
        const currentMinutes = today.getMinutes();
        
        if (selectedHours < currentHours || (selectedHours === currentHours && selectedMinutes <= currentMinutes)) {
            alert("❌ Cannot schedule appointment in the past. Please select a future time.");
            return;
        }
    }

    const data = {
        patientId: patientSelect.value,
        patientName: patientName, // ✅ Clean name without ID
        doctorId: doctorSelect.value,
        doctorName: doctorName, // ✅ Clean name without ID
        date: selectedDate,
        time: selectedTime,
        duration: parseInt(document.getElementById("duration").value) || 30,
        type: document.getElementById("appType").value,
        reason: document.getElementById("reason").value,
        notes: document.getElementById("notes").value
    };

    console.log("Appointment data being sent:", data); // ✅ Debug log

    try {
        const res = await fetch("http://localhost:5000/api/appointments", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(data)
        });

        const result = await res.json();
        
        if (res.ok) {
            alert("✅ Appointment scheduled successfully!");
            window.location.href = "Appointments.html";
        } else {
            // Show specific error message from server
            alert("❌ " + (result.message || "Error scheduling appointment"));
        }
    } catch (err) {
        console.error("Error scheduling appointment:", err);
        alert("❌ Failed to connect to server");
    }
});