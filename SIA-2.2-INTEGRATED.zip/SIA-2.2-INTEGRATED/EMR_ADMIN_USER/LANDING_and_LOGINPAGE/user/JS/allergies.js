document.addEventListener("DOMContentLoaded", () => {
      // 🧠 Load patient name and display in header
const patientId = new URLSearchParams(window.location.search).get("patientId");
if (!patientId) return alert("No patient selected!");

async function loadPatientHeader() {
  try {
    const res = await fetch(`http://localhost:5000/api/patients/${patientId}`);
    if (!res.ok) throw new Error("Patient not found");

    const p = await res.json();
    document.querySelector("header h1").textContent = `Patient Information - ${p.firstname} ${p.lastname}`;
  } catch (err) {
    console.error("Error loading patient header:", err);
  }
}

loadPatientHeader();

// ✅ Keep patientId across navbar links
document.querySelectorAll("nav-bar a").forEach(link => {
  const href = link.getAttribute("href");
  if (href && !href.includes("?patientId=")) {
    link.setAttribute("href", `${href}?patientId=${patientId}`);
  }
});

      const addBtn = document.getElementById("addAllergyBtn");
      const saveBtn = document.querySelector(".savebtn");
      const cancelBtn = document.querySelector(".cancelbtn");
      const buttonCon = document.getElementById("buttonCon");
      const allergiesContainer = document.getElementById("allergiesContainer");

      let allergyCount = 0;
      let addMode = false;
      buttonCon.style.display = "none";

      // ✅ Create Allergy Form Block
      function createAllergyForm(index) {
        const wrapper = document.createElement("div");
        wrapper.classList.add("medecineCon");

        wrapper.innerHTML = `
          <div class="medecineHeader">
            <h3>Allergy ${index}</h3>
            <i class="fa-solid fa-trash deleteAllergy"></i>
          </div>

          <form class="patientForm">
            <div class="leftform">
              <div class="form-group">
                <label>Allergen</label>
                <input type="text" name="allergen" required disabled />
              </div>
              <div class="form-group">
                <label>Severity</label>
                <select name="severity" required disabled>
                  <option value="Mild">Mild</option>
                  <option value="Moderate">Moderate</option>
                  <option value="Severe">Severe</option>
                </select>
              </div>
            </div>

            <div class="leftform">
              <div class="form-group">
                <label>Reaction</label>
                <input type="text" name="reaction" required disabled />
              </div>
              <div class="form-group">
                <label>Diagnosed Date</label>
                <input type="date" name="diadate" required disabled />
              </div>
            </div>
          </form>
        `;
        return wrapper;
      }

      // ✅ Add Allergy
      addBtn.addEventListener("click", (e) => {
        e.preventDefault();

        if (!addMode) {
          const existing = allergiesContainer.querySelectorAll(".medecineCon");
          if (existing.length === 0) allergyCount = 0;

          allergyCount++;
          const newForm = createAllergyForm(allergyCount);
          allergiesContainer.appendChild(newForm);

          newForm.querySelectorAll("input, select").forEach(el => (el.disabled = false));

          // delete button
          newForm.querySelector(".deleteAllergy").addEventListener("click", () => {
            newForm.remove();

            const allForms = allergiesContainer.querySelectorAll(".medecineCon");
            allForms.forEach((form, idx) => {
              const title = form.querySelector("h3");
              if (title) title.textContent = `Allergy ${idx + 1}`;
            });

            allergyCount = allForms.length;
            if (allergyCount === 0) {
              buttonCon.style.display = "none";
              addBtn.textContent = "Add Allergy";
              addMode = false;
            }
          });

          buttonCon.style.display = "flex";
          addBtn.textContent = "Cancel Add";
          addMode = true;
        } else {
          const lastForm = allergiesContainer.lastElementChild;
          if (lastForm && lastForm.querySelector("input:not([disabled])")) lastForm.remove();
          allergyCount = allergiesContainer.querySelectorAll(".medecineCon").length;

          buttonCon.style.display = "none";
          addBtn.textContent = "Add Allergy";
          addMode = false;
        }
      });

      // ✅ Cancel button
      cancelBtn.addEventListener("click", (e) => {
        e.preventDefault();
        const lastForm = allergiesContainer.lastElementChild;
        if (lastForm && lastForm.querySelector("input:not([disabled])")) lastForm.remove();
        buttonCon.style.display = "none";
        addBtn.textContent = "Add Allergy";
        addMode = false;
      });

      // ✅ Save button
      // ✅ Save button (with required validation)
saveBtn.addEventListener("click", async (e) => {
  e.preventDefault();

  const patientId = new URLSearchParams(window.location.search).get("patientId");
  if (!patientId) return alert("No patient selected!");

  const lastForm = allergiesContainer.querySelector(".patientForm:last-child");
  if (!lastForm) return alert("No allergy to save!");

  // ✅ Check that all required fields are filled before saving
  if (!lastForm.checkValidity()) {
    lastForm.reportValidity(); // show default browser popups
    return; // stop here if invalid
  }

  // ✅ Collect form data
  const formData = Object.fromEntries(new FormData(lastForm).entries());

  try {
    const res = await fetch(`http://localhost:5000/api/patients/${patientId}/allergies`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData),
    });

    if (!res.ok) throw new Error("Error saving allergy");

    alert("✅ Allergy saved successfully!");
    lastForm.querySelectorAll("input, select").forEach((el) => (el.disabled = true));

    buttonCon.style.display = "none";
    addBtn.textContent = "Add Allergy";
    addMode = false;
  } catch (err) {
    console.error(err);
    alert("❌ Failed to save allergy");
  }
});

    });

    

    // ✅ Load Existing Allergies on Page Load
async function loadAllergies() {
  const patientId = new URLSearchParams(window.location.search).get("patientId");
  if (!patientId) return;

  try {
    const res = await fetch(`http://localhost:5000/api/patients/${patientId}/allergies`);
    const allergies = await res.json();

    const allergiesContainer = document.getElementById("allergiesContainer");
    allergiesContainer.innerHTML = ""; // clear existing

    allergies.forEach((a, i) => {
      const wrapper = document.createElement("div");
      wrapper.classList.add("medecineCon");
      wrapper.innerHTML = `
        <div class="medecineHeader">
          <h3>Allergy ${i + 1}</h3>
          <i class="fa-solid fa-trash deleteAllergy" data-id="${a.allergyId}"></i>
        </div>

        <form class="patientForm">
          <div class="leftform">
            <div class="form-group">
              <label>Allergen</label>
              <input type="text" name="allergen" value="${a.allergen || ""}" disabled />
            </div>
            <div class="form-group">
              <label>Severity</label>
              <select name="severity" disabled>
                <option value="Mild" ${a.severity === "Mild" ? "selected" : ""}>Mild</option>
                <option value="Moderate" ${a.severity === "Moderate" ? "selected" : ""}>Moderate</option>
                <option value="Severe" ${a.severity === "Severe" ? "selected" : ""}>Severe</option>
              </select>
            </div>
          </div>

          <div class="leftform">
            <div class="form-group">
              <label>Reaction</label>
              <input type="text" name="reaction" value="${a.reaction || ""}" disabled />
            </div>
            <div class="form-group">
              <label>Diagnosed Date</label>
              <input type="date" name="diadate" value="${a.diadate ? a.diadate.split("T")[0] : ""}" disabled />
            </div>
          </div>
        </form>
      `;

      // 🗑️ Delete function
      wrapper.querySelector(".deleteAllergy").addEventListener("click", async (e) => {
        const allergyId = e.target.dataset.id;
        if (confirm("Delete this allergy?")) {
          await fetch(`http://localhost:5000/api/allergies/${allergyId}`, { method: "DELETE" });
          loadAllergies(); // refresh
        }
      });

      allergiesContainer.appendChild(wrapper);
    });
  } catch (err) {
    console.error("❌ Error loading allergies:", err);
  }
}

// ✅ Run it on page load
document.addEventListener("DOMContentLoaded", loadAllergies);


    // ✅ Preserve ?patientId= across navbar links
    document.addEventListener("DOMContentLoaded", () => {
      const patientId = new URLSearchParams(window.location.search).get("patientId");
      if (!patientId) return;
      document.querySelectorAll("nav-bar a").forEach(link => {
        const href = link.getAttribute("href");
        if (href && !href.includes("?patientId=")) {
          link.setAttribute("href", `${href}?patientId=${patientId}`);
        }
      });
    });