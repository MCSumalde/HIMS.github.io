// ====== AUTO REFRESH SYSTEM FOR REAL-TIME UPDATES ======

// ✅ Auto refresh configuration
const AUTO_REFRESH_CONFIG = {
  enabled: true,
  interval: 1000, 
  pages: {
    "Appointments.html": {
      refreshFunction: "loadAppointments",
      enabled: true
    },
    "Dashboard.html": {
      refreshFunction: "loadTodaysAppointments",
      enabled: true,
      additionalFunctions: ["updateQuickStats", "loadRecentPatients"]
    },
    "Patients.html": {
      refreshFunction: "loadPatients",
      enabled: true
    },
    "Archive.html": {
      refreshFunction: "loadAppointments",
      enabled: true
    },
    "Report.html": {
      refreshFunction: "loadReportStats",
      enabled: true
    },
     "emrAdmin.html": {
      refreshFunction: "loadReportStats",
      enabled: true
    },
     "adminBackup.html": {
      refreshFunction: "loadReportStats",
      enabled: true
    }
  }
};

// ✅ Start auto refresh
function startAutoRefresh() {
  if (!AUTO_REFRESH_CONFIG.enabled) return;

  const currentPage = window.location.pathname.split("/").pop();
  const pageConfig = AUTO_REFRESH_CONFIG.pages[currentPage];

  if (!pageConfig || !pageConfig.enabled) {
    return;
  }

  // Don't refresh if user is actively interacting (typing, clicking, etc.)
  let isUserActive = false;
  let activityTimeout;

  const resetActivityTimeout = () => {
    isUserActive = true;
    clearTimeout(activityTimeout);
    activityTimeout = setTimeout(() => {
      isUserActive = false;
    }, 1000); // 1 second of inactivity before allowing refresh
  };

  // Track user activity
  document.addEventListener("mousedown", resetActivityTimeout);
  document.addEventListener("keydown", resetActivityTimeout);
  document.addEventListener("scroll", resetActivityTimeout);

  // Auto refresh interval
  setInterval(() => {
    // Don't refresh if:
    // 1. User is active
    // 2. A modal is open
    // 3. User is on a form page
    if (isUserActive) return;
    
    const hasOpenModal = document.querySelector(".modal[style*='flex'], .modal[style*='block']");
    if (hasOpenModal) return;

    const isFormPage = currentPage.includes("Add") || currentPage.includes("Edit");
    if (isFormPage) return;

    // Check if page is visible
    if (document.hidden) return;

    // Execute refresh function if it exists
    if (typeof window[pageConfig.refreshFunction] === "function") {
      try {
        window[pageConfig.refreshFunction]();
      } catch (err) {
        console.error("Auto refresh error:", err);
      }
    }
    
    // Execute additional refresh functions if configured
    if (pageConfig.additionalFunctions && Array.isArray(pageConfig.additionalFunctions)) {
      pageConfig.additionalFunctions.forEach(funcName => {
        if (typeof window[funcName] === "function") {
          try {
            window[funcName]();
          } catch (err) {
            console.error(`Auto refresh error for ${funcName}:`, err);
          }
        }
      });
    }
  }, AUTO_REFRESH_CONFIG.interval);

  console.log(`✅ Auto refresh enabled for ${currentPage} (every ${AUTO_REFRESH_CONFIG.interval / 1000}s)`);
}

// ✅ Initialize auto refresh
document.addEventListener("DOMContentLoaded", () => {
  // Small delay to ensure page is fully loaded
  setTimeout(startAutoRefresh, 1000);
});

// ✅ Also start if DOM is already loaded
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    setTimeout(startAutoRefresh, 1000);
  });
} else {
  setTimeout(startAutoRefresh, 1000);
}