// ✅ Load user info and apply everywhere (sidebar + top greeting)
function loadUserInfo() {
  const name = sessionStorage.getItem("name");
  const role = sessionStorage.getItem("role");

  // 🚫 Redirect if not logged in
  if (!name || !role) {
    window.location.href = "../emrLogin.html";
    return;
  }

  // ✅ Greet the user
  document.querySelector(".greet").textContent = `Welcome back, ${name}`;

  // ✅ Sidebar updates (only if sidebar is loaded)
  const sidebarName = document.querySelector(".accountName");
  const sidebarRole = document.querySelector(".role");
  const userPic = document.querySelector(".userPic");

  if (sidebarName) sidebarName.textContent = name;
  if (sidebarRole) sidebarRole.textContent = role;

  if (userPic) {
    const initials = name
      .split(" ")
      .map(n => n[0].toUpperCase())
      .join("");
    userPic.textContent = initials;
  }
}

// ✅ Load today's appointments (FIXED VERSION)
async function loadTodaysAppointments() {
  const container = document.querySelector(".statsCon .viewCon").previousElementSibling;
  
  try {
    const res = await fetch("http://localhost:5000/api/appointments");
    if (!res.ok) throw new Error("Failed to fetch appointments");
    const allAppointments = await res.json();

    // ✅ Get logged-in user info
    const loggedInRole = sessionStorage.getItem('role');
    const loggedInUserId = sessionStorage.getItem('userId');
    const loggedInName = sessionStorage.getItem('name');

    // ✅ Filter appointments by doctor if user is a Doctor
    let filteredAppointments = allAppointments;
    if (loggedInRole === "Doctor" && loggedInUserId) {
      filteredAppointments = allAppointments.filter(app => {
        const matchesDoctorId = app.doctorId === loggedInUserId;
        const matchesDoctorName = app.doctorName === `Dr. ${loggedInName}` || 
                                   app.doctorName === loggedInName;
        return matchesDoctorId || matchesDoctorName;
      });
    }

    const today = new Date().toISOString().split("T")[0];

    // ✅ Filter for today's appointments only
    const todays = filteredAppointments.filter(app => {
      const appDate = new Date(app.date).toISOString().split("T")[0];
      return appDate === today;
    });

    // ✅ Remove duplicates by appointmentId (safety check)
    const uniqueTodays = todays.filter((app, index, self) =>
      index === self.findIndex(a => a.appointmentId === app.appointmentId)
    );

    console.log(`📅 Today's appointments: ${uniqueTodays.length}`, uniqueTodays);

    // ✅ Clear container FIRST
    container.innerHTML = "";

    if (uniqueTodays.length === 0) {
      container.innerHTML = `<p style="text-align:center; color:gray;">No appointments for today</p>`;
      return;
    }

    // ✅ Sort by time
    uniqueTodays.sort((a, b) => {
      const timeA = a.time.split(':').map(Number);
      const timeB = b.time.split(':').map(Number);
      return (timeA[0] * 60 + timeA[1]) - (timeB[0] * 60 + timeB[1]);
    });

    // ✅ Display each appointment
    uniqueTodays.forEach(app => {
      const div = document.createElement("div");
      div.className = "appointmentSched";
      div.setAttribute("data-appointment-id", app.appointmentId); // Unique identifier
      div.innerHTML = `
        <h3 class="schedTime">${app.time}</h3>
        <h3 class="schedName">${app.patientName}</h3>
        <h3 class="schedDoc">${app.doctorName}</h3>
      `;
      container.appendChild(div);
    });
  } catch (err) {
    console.error("Error loading today's appointments:", err);
    container.innerHTML = `<p style="color:red; text-align:center;">Error loading data</p>`;
  }
}

// ✅ Load recent patients
function loadRecentPatients() {
  const recentCon = document.querySelector(".recentPatients");
  const recent = getRecentPatients();

  recentCon.innerHTML = "";

  if (recent.length === 0) {
    recentCon.innerHTML = `<p style="text-align:center; color:gray;">No recent patients</p>`;
    return;
  }

  recent.forEach(p => {
    const cleanName = p.patientName.replace(/\s*\(.*?\)\s*/g, "").trim();
    const initials = cleanName.split(" ").map(n => n[0].toUpperCase()).join("");

    const div = document.createElement("div");
    div.className = "patientList";
    div.innerHTML = `
      <div class="patientPic">${initials}</div>
      <div>
        <h3 class="patientName">${cleanName}</h3>
        <h4 class="patientId">${p.patientId}</h4>
      </div>
    `;
    recentCon.appendChild(div);
  });
}

// ✅ Update quick stats
async function updateQuickStats() {
  try {
    // ✅ Fetch data
    const [patientRes, appointmentRes] = await Promise.all([
      fetch("http://localhost:5000/api/patients"),
      fetch("http://localhost:5000/api/appointments")
    ]);

    const patients = await patientRes.json();
    const appointments = await appointmentRes.json();

   // ✅ Total active patients (filter out inactive)
const activePatients = patients.filter(p => p.status?.toLowerCase() === 'active');
document.getElementById("activePatients").textContent = activePatients.length;

    // ✅ Get start and end of the week (Monday → Sunday)
    const now = new Date();
    const day = now.getDay(); // 0 = Sunday, 1 = Monday, ...
    const diffToMonday = (day === 0 ? -6 : 1 - day); // Adjust so Monday is start
    const startOfWeek = new Date(now);
    startOfWeek.setHours(0, 0, 0, 0);
    startOfWeek.setDate(now.getDate() + diffToMonday);

    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);
    endOfWeek.setHours(23, 59, 59, 999);

    // ✅ Filter appointments by doctor if user is a Doctor
    let filteredAppointments = appointments;
    const loggedInRole = sessionStorage.getItem('role');
    const loggedInUserId = sessionStorage.getItem('userId');
    const loggedInName = sessionStorage.getItem('name');
    
    if (loggedInRole === "Doctor" && loggedInUserId) {
      filteredAppointments = appointments.filter(app => {
        const matchesDoctorId = app.doctorId === loggedInUserId;
        const matchesDoctorName = app.doctorName === `Dr. ${loggedInName}` || 
                                   app.doctorName === loggedInName;
        return matchesDoctorId || matchesDoctorName;
      });
    }

    // ✅ Filter appointments within this week (local time safe)
    const appointmentsThisWeek = filteredAppointments.filter(app => {
      const appDate = new Date(app.date);
      return appDate >= startOfWeek && appDate <= endOfWeek;
    });

    document.getElementById("appointmentsThisWeek").textContent =
      appointmentsThisWeek.length;

    // ✅ Hide pending reports for doctors
    const role = sessionStorage.getItem("role");
    const pendingReportsElement = document.getElementById("pendingReports");
    const pendingReportsContainer = pendingReportsElement?.closest(".status");
    
    if (role === "Doctor" && pendingReportsContainer) {
      pendingReportsContainer.style.display = "none";
    } else {
      // ✅ Placeholder for reports (only show for non-doctors)
      if (pendingReportsElement) {
        pendingReportsElement.textContent = 0;
      }
    }

  } catch (err) {
    console.error("Error updating Quick Stats:", err);
  }
}

// ✅ Run on load (ONLY ONCE)
window.onload = () => {
  loadUserInfo();
  loadTodaysAppointments();
  updateQuickStats();
  loadRecentPatients();
};