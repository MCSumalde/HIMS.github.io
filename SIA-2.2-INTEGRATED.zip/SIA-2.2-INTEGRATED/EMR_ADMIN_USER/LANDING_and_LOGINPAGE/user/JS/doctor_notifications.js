// ====== DOCTOR NOTIFICATION SYSTEM FOR NURSE RESPONSES ======

// ✅ Check for nurse response notifications (for header display only - no auto popups)
function checkNurseResponseNotifications() {
  // This function is now only used by header.js for displaying notifications
  // Auto-popups are disabled - notifications appear in header bell
  return;
}

// ✅ Show notification to doctor (only when clicked from header)
function showNurseResponseNotification(notification, fromHeader = false) {
  // Check if modal already exists
  const existingModal = document.getElementById("nurseResponseNotificationModal");
  if (existingModal && !fromHeader) {
    return; // Don't show duplicate modals (unless explicitly from header)
  }

  const statusText = notification.status === "ongoing" 
    ? "Patient is present. Appointment status changed to Ongoing." 
    : "Patient is not present. Appointment has been canceled and moved to archive.";
  
  const statusColor = notification.status === "ongoing" ? "#2da624" : "#ca3030";
  const statusIcon = notification.status === "ongoing" ? "✅" : "❌";

  const modal = document.createElement("div");
  modal.id = "nurseResponseNotificationModal";
  modal.className = "nurse-response-notification-modal";
  modal.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.6);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 10000;
  `;

  modal.innerHTML = `
    <div style="
      background: white;
      border-radius: 12px;
      padding: 30px;
      max-width: 500px;
      width: 90%;
      box-shadow: 0 5px 25px rgba(0,0,0,0.3);
      animation: fadeIn 0.3s;
    ">
      <div style="text-align: center; margin-bottom: 20px;">
        <div style="font-size: 48px; margin-bottom: 10px;">${statusIcon}</div>
        <h2 style="margin: 0; color: ${statusColor};">Nurse Response</h2>
      </div>
      
      <div style="margin-bottom: 20px; padding: 15px; background: #f5f5f5; border-radius: 8px;">
        <p style="margin: 5px 0;"><strong>Patient:</strong> ${notification.patientName || 'Unknown'}</p>
        <p style="margin: 5px 0;"><strong>Appointment ID:</strong> ${notification.appointmentId || 'N/A'}</p>
        <p style="margin: 10px 0; padding: 10px; background: white; border-radius: 5px; color: ${statusColor}; font-weight: 600;">
          ${statusText}
        </p>
      </div>
      
      <div style="display: flex; justify-content: center;">
        <button id="acknowledgeNotificationBtn" style="
          background: ${statusColor};
          color: white;
          border: none;
          padding: 12px 30px;
          border-radius: 5px;
          cursor: pointer;
          font-weight: 600;
          font-size: 16px;
        ">OK</button>
      </div>
    </div>
  `;

  document.body.appendChild(modal);
  // ✅ NO SOUND when clicking notification - sound only plays on receipt (handled in header.js)

  // Handle OK button
  document.getElementById("acknowledgeNotificationBtn").addEventListener("click", () => {
    markNotificationAsHandled(notification);
    modal.remove();
    
    // Reload appointments if on appointments page
    if (window.location.href.includes("Appointments.html") && typeof loadAppointments === "function") {
      loadAppointments();
    }
  });
}

// ✅ Mark notification as handled
function markNotificationAsHandled(notification) {
  try {
    let notifications = JSON.parse(localStorage.getItem("nurseResponseNotifications") || "[]");
    const index = notifications.findIndex(n => 
      n.appointmentId === notification.appointmentId && 
      n.timestamp === notification.timestamp
    );
    
    if (index !== -1) {
      notifications[index].handled = true;
      localStorage.setItem("nurseResponseNotifications", JSON.stringify(notifications));
    }
  } catch (err) {
    console.error("Error marking notification as handled:", err);
  }
}

// ✅ Play notification sound
function playNotificationSound() {
  try {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.value = 800;
    oscillator.type = 'sine';
    gainNode.gain.value = 0.3;
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.2);
  } catch (err) {
    console.log("Audio not available");
  }
}

// ✅ Check for notifications on page load (but don't auto-show modals)
document.addEventListener("DOMContentLoaded", () => {
  // Don't auto-show modals - notifications will appear in header
  // checkNurseResponseNotifications();
  
  // Check periodically for header notifications
  setInterval(() => {
    // Notifications are handled by header.js
    if (typeof checkForNotifications === "function") {
      checkForNotifications();
    }
  }, 3000);
  
  // Listen for storage events (cross-tab communication)
  window.addEventListener('storage', (e) => {
    if (e.key && e.key.startsWith('nurseResponseNotification_')) {
      // Update header notifications
      if (typeof checkForNotifications === "function") {
        checkForNotifications();
      }
    }
  });
});

// ✅ Also check when page becomes visible
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    if (typeof checkForNotifications === "function") {
      checkForNotifications();
    }
  }
});
