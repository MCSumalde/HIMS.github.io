// ====== HEADER COMPONENT WITH CLOCK AND NOTIFICATIONS ======

// ✅ Create and load header
function loadHeader() {
  // Check if header already exists
  if (document.getElementById("topHeader")) {
    return;
  }

  // Load a clean, modern font for the clock (once)
  if (!document.getElementById("poppinsFont")) {
    const fontLink = document.createElement("link");
    fontLink.id = "poppinsFont";
    fontLink.rel = "stylesheet";
    fontLink.href =
      "https://fonts.googleapis.com/css2?family=Poppins:wght@600;700&display=swap";
    document.head.appendChild(fontLink);
  }

  const headerHTML = `
    <header id="topHeader" style="
      position: fixed;
      top: 0;
      
      right: 0;
      height: 60px;
      background: white;
      margin: 0px;
      display: flex;
      width: 100%;
      padding: 0 30px;
      z-index: 100;
      
    ">
      <div style="display: flex; align-items: center; gap: 20px;">
        <div id="clockDisplay" style="
          font-size: 19px;
          font-weight: 700;
          color: #358F85;
          position: absolute;
          right: 70px;
          font-family: 'Poppins', 'Segoe UI', sans-serif;
          letter-spacing: 0.5px;
        ">12:00:00 PM</div>
      </div>
      
      <div style="display: flex; align-items: center; gap: 15px; position: absolute; right: 30px; top: 10px">
        <div style="position: relative;">
          <i id="notificationBell" class="fa-solid fa-bell" style="
            font-size: 22px;
            color: #666;
            
            cursor: pointer;
            padding: 8px;
            border-radius: 50%;
            transition: all 0.3s;
          " title="Notifications"></i>
          <span id="notificationBadge" style="
            position: absolute;
            top: 2px;
            right: 2px;
            background: #ca3030;
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 11px;
            display: none;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            border: 2px solid white;
          ">0</span>
        </div>
      </div>
    </header>
    
    <div id="notificationDropdown" style="
      position: fixed;
      top: 60px;
      right: 30px;
      width: 400px;
      max-width: calc(90vw - 250px);
      max-height: 500px;
      background: white;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      border-radius: 8px;
      display: none;
      flex-direction: column;
      z-index: 1001;
      overflow: hidden;
    ">
      <div style="
        padding: 15px 20px;
        border-bottom: 2px solid #f0f0f0;
        display: flex;
        justify-content: space-between;
        align-items: center;
      ">
        <h3 style="margin: 0; color: #358F85; font-size: 18px;">Notifications</h3>
        <button id="clearAllNotifications" style="
          background: none;
          border: none;
          color: #666;
          cursor: pointer;
          font-size: 12px;
          padding: 5px 10px;
        ">Clear All</button>
      </div>
      <div id="notificationList" style="
        max-height: 440px;
        overflow-y: auto;
        padding: 10px;
      ">
        <p style="text-align: center; color: #999; padding: 20px;">No notifications</p>
      </div>
    </div>
  `;

  document.body.insertAdjacentHTML("afterbegin", headerHTML);

  // Add margin-top to main content to account for fixed header
  const mainContent = document.querySelector(".mainContent");
  if (mainContent) {
    const currentMarginTop = mainContent.style.marginTop || "0px";
    const headerHeight = 60;
    // Only add margin if not already set
    if (currentMarginTop === "0px" || !currentMarginTop.includes("60")) {
      const existingMargin = parseInt(currentMarginTop) || 0;
      mainContent.style.marginTop = `${existingMargin + headerHeight}px`;
    }
  }

  // Initialize clock
  updateClock();
  setInterval(updateClock, 1000);

  // Setup notification bell click
  const notificationBell = document.getElementById("notificationBell");
  const notificationDropdown = document.getElementById("notificationDropdown");

  if (notificationBell) {
    notificationBell.addEventListener("click", () => {
      const isVisible = notificationDropdown.style.display === "flex";
      notificationDropdown.style.display = isVisible ? "none" : "flex";
      loadNotifications();
    });
  }

  // Close dropdown when clicking outside
  document.addEventListener("click", (e) => {
    if (notificationBell && notificationDropdown) {
      if (
        !notificationBell.contains(e.target) &&
        !notificationDropdown.contains(e.target)
      ) {
        notificationDropdown.style.display = "none";
      }
    }
  });

  // Clear all notifications
  const clearAllBtn = document.getElementById("clearAllNotifications");
  if (clearAllBtn) {
    clearAllBtn.addEventListener("click", () => {
      clearAllNotifications();
    });
  }

  // Start checking for notifications (with initial delay to prevent false positives)
  setTimeout(() => {
    checkForNotifications();
    // Initialize previous count after first check
    setTimeout(() => {
      if (window.previousNotificationCount === undefined) {
        window.previousNotificationCount = (
          window.currentNotifications || []
        ).length;
      }
    }, 100);
  }, 500);

  setInterval(checkForNotifications, 3000);
}

// ✅ Update clock display
function updateClock() {
  const clockDisplay = document.getElementById("clockDisplay");
  if (!clockDisplay) return;

  const now = new Date();
  let hours = now.getHours();
  const minutes = String(now.getMinutes()).padStart(2, "0");
  const seconds = String(now.getSeconds()).padStart(2, "0");
  const ampm = hours >= 12 ? "PM" : "AM";
  hours = hours % 12;
  hours = hours === 0 ? 12 : hours;
  const hoursStr = String(hours).padStart(2, "0");

  clockDisplay.textContent = `${hoursStr}:${minutes}:${seconds} ${ampm}`;
}

// ✅ Play notification sound
function playNotificationSound() {
  try {
    const audioContext = new (window.AudioContext ||
      window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();

    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);

    oscillator.frequency.value = 1000;
    oscillator.type = "sine";
    gainNode.gain.value = 0.3;

    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.3);
  } catch (err) {
    console.log("Audio not available");
  }
}

// ✅ Check for notifications
function checkForNotifications() {
  const role = sessionStorage.getItem("role");
  if (!role) return;

  // Track previously seen notification IDs to detect new ones
  if (!window.seenNotificationIds) {
    window.seenNotificationIds = new Set();
  }

  let notifications = [];
  let hasNewNotification = false;

  // Check for doctor enter notifications (for nurses)
  if (role === "Nurse") {
    try {
      const doctorEnterNotifications = JSON.parse(
        localStorage.getItem("doctorEnterNotifications") || "[]"
      );
      const unhandled = doctorEnterNotifications.filter(
        (n) => n.type === "doctor_enter" && !n.handled
      );
      notifications.push(
        ...unhandled.map((n) => {
          const notificationId = `doctor_enter_${n.appointmentId}_${n.timestamp}`;
          // Check if this is a new notification (only if not already seen)
          const isNew = !window.seenNotificationIds.has(notificationId);
          if (isNew) {
            hasNewNotification = true;
            window.seenNotificationIds.add(notificationId);
          }
          return {
            id: notificationId,
            type: "doctor_enter",
            title: "Doctor Consultation Request",
            message: `Dr. ${n.doctorName} is ready to consult with ${n.patientName}`,
            appointmentId: n.appointmentId,
            timestamp: n.timestamp,
            doctorId: n.doctorId, // ✅ Include doctorId for filtering
            data: n,
          };
        })
      );

      // ✅ Check for appointment time arrived notifications (for nurses)
      const timeArrivedNotifications = JSON.parse(
        localStorage.getItem("appointmentTimeArrivedNotifications") || "[]"
      );
      const unhandledTimeArrived = timeArrivedNotifications.filter(
        (n) => n.type === "appointment_time_arrived" && !n.handled
      );
      notifications.push(
        ...unhandledTimeArrived.map((n) => {
          const notificationId = `appointment_time_arrived_${n.appointmentId}_${n.timestamp}`;
          // Check if this is a new notification (only if not already seen)
          const isNew = !window.seenNotificationIds.has(notificationId);
          if (isNew) {
            hasNewNotification = true;
            window.seenNotificationIds.add(notificationId);
          }
          return {
            id: notificationId,
            type: "appointment_time_arrived",
            title: "Appointment Time Arrived",
            message: `Appointment for ${n.patientName} with ${n.doctorName} is due now`,
            appointmentId: n.appointmentId,
            timestamp: n.timestamp,
            doctorId: n.doctorId,
            data: n,
          };
        })
      );
    } catch (err) {
      console.error("Error checking doctor enter notifications:", err);
    }
  }

  // Check for nurse response notifications (for doctors)
  if (role === "Doctor") {
    try {
      const loggedInUserId = sessionStorage.getItem("userId");
      const nurseResponseNotifications = JSON.parse(
        localStorage.getItem("nurseResponseNotifications") || "[]"
      );
      // ✅ Filter by doctorId - only show notifications meant for this doctor
      const unhandled = nurseResponseNotifications.filter(
        (n) =>
          n.type === "nurse_response" &&
          !n.handled &&
          (n.doctorId === loggedInUserId || !n.doctorId) // Show if matches doctorId or if no doctorId (backward compatibility)
      );
      notifications.push(
        ...unhandled.map((n) => {
          const notificationId = `nurse_response_${n.appointmentId}_${n.timestamp}`;
          // Check if this is a new notification
          const isNew = !window.seenNotificationIds.has(notificationId);
          if (isNew) {
            hasNewNotification = true;
            window.seenNotificationIds.add(notificationId);
          }
          return {
            id: notificationId,
            type: "nurse_response",
            title:
              n.status === "ongoing"
                ? "Patient Present"
                : "Appointment Canceled",
            message:
              n.status === "ongoing"
                ? `Patient ${n.patientName} is present. Appointment is now Ongoing.`
                : `Patient ${n.patientName} is not present. Appointment has been canceled.`,
            appointmentId: n.appointmentId,
            timestamp: n.timestamp,
            status: n.status,
            data: n,
          };
        })
      );

      // ✅ Check for appointment started notifications (when nurse permits patient)
      const appointmentStartedNotifications = JSON.parse(
        localStorage.getItem("appointmentStartedNotifications") || "[]"
      );
      const unhandledStarted = appointmentStartedNotifications.filter(
        (n) =>
          n.type === "appointment_started" &&
          !n.handled &&
          n.doctorId === loggedInUserId
      );
      notifications.push(
        ...unhandledStarted.map((n) => {
          const notificationId = `appointment_started_${n.appointmentId}_${n.timestamp}`;
          const isNew = !window.seenNotificationIds.has(notificationId);
          if (isNew) {
            hasNewNotification = true;
            window.seenNotificationIds.add(notificationId);
          }
          return {
            id: notificationId,
            type: "appointment_started",
            title: "Patient Permitted to Enter",
            message: `Patient ${n.patientName} has been permitted to enter. Appointment is now Ongoing.`,
            appointmentId: n.appointmentId,
            timestamp: n.timestamp,
            status: n.status,
            data: n,
          };
        })
      );

      // ✅ Check for appointment canceled notifications (when nurse cancels)
      const appointmentCanceledNotifications = JSON.parse(
        localStorage.getItem("appointmentCanceledNotifications") || "[]"
      );
      const unhandledCanceled = appointmentCanceledNotifications.filter(
        (n) =>
          n.type === "appointment_canceled" &&
          !n.handled &&
          n.doctorId === loggedInUserId
      );
      notifications.push(
        ...unhandledCanceled.map((n) => {
          const notificationId = `appointment_canceled_${n.appointmentId}_${n.timestamp}`;
          const isNew = !window.seenNotificationIds.has(notificationId);
          if (isNew) {
            hasNewNotification = true;
            window.seenNotificationIds.add(notificationId);
          }
          return {
            id: notificationId,
            type: "appointment_canceled",
            title: "Appointment Canceled",
            message: `Appointment for ${n.patientName} has been canceled and moved to archive.`,
            appointmentId: n.appointmentId,
            timestamp: n.timestamp,
            status: n.status,
            data: n,
          };
        })
      );
    } catch (err) {
      console.error("Error checking nurse response notifications:", err);
    }
  }

  // ✅ Play sound ONLY if new notification arrived (not on every check)
  // Store previous notification count to detect truly new notifications
  const previousCount = window.previousNotificationCount || 0;
  const currentCount = notifications.length;

  // Only play sound if:
  // 1. There are new notifications (count increased OR hasNewNotification flag is true)
  // 2. AND we've already done an initial check (prevents sound on first load)
  // 3. AND enough time has passed since last sound (prevents rapid-fire)
  if (hasNewNotification && window.previousNotificationCount !== undefined) {
    const timeSinceLastSound = window.lastNotificationSoundTime
      ? Date.now() - window.lastNotificationSoundTime
      : Infinity;
    if (timeSinceLastSound > 2000) {
      // At least 2 seconds between sounds
      playNotificationSound();
      window.lastNotificationSoundTime = Date.now();
    }
  }

  // Update previous count for next check
  window.previousNotificationCount = currentCount;

  // Clean up seen IDs for notifications that are no longer present (handled/removed)
  const currentNotificationIds = new Set(notifications.map((n) => n.id));
  window.seenNotificationIds.forEach((id) => {
    if (!currentNotificationIds.has(id)) {
      window.seenNotificationIds.delete(id);
    }
  });

  // Update badge
  updateNotificationBadge(notifications.length);

  // Store notifications for display
  window.currentNotifications = notifications;
}

// ✅ Update notification badge
function updateNotificationBadge(count) {
  const badge = document.getElementById("notificationBadge");
  const bell = document.getElementById("notificationBell");

  if (badge) {
    if (count > 0) {
      badge.textContent = count > 99 ? "99+" : count;
      badge.style.display = "flex";
      if (bell) {
        bell.style.color = "#ca3030";
        bell.style.animation = "pulse 2s infinite";
      }
    } else {
      badge.style.display = "none";
      if (bell) {
        bell.style.color = "#666";
        bell.style.animation = "none";
      }
    }
  }
}

// ✅ Load notifications in dropdown
function loadNotifications() {
  const notificationList = document.getElementById("notificationList");
  if (!notificationList) return;

  const notifications = window.currentNotifications || [];

  if (notifications.length === 0) {
    notificationList.innerHTML =
      '<p style="text-align: center; color: #999; padding: 20px;">No notifications</p>';
    return;
  }

  // Sort by timestamp (newest first)
  notifications.sort((a, b) => b.timestamp - a.timestamp);

  notificationList.innerHTML = notifications
    .map((notif) => {
      const timeAgo = getTimeAgo(notif.timestamp);
      let icon = "🔔";
      if (notif.type === "appointment_time_arrived") {
        icon = "⏰";
      } else if (notif.type === "appointment_started") {
        icon = "✅";
      } else if (notif.type === "appointment_canceled") {
        icon = "❌";
      } else if (notif.type === "doctor_enter") {
        icon = "🔔";
      } else if (notif.status === "ongoing") {
        icon = "✅";
      } else {
        icon = "❌";
      }

      return `
      <div class="notification-item" style="
        padding: 12px;
        border-bottom: 1px solid #f0f0f0;
        cursor: pointer;
        transition: background 0.2s;
      " data-id="${notif.id}" data-type="${notif.type}" data-appointmentid="${notif.appointmentId}">
        <div style="display: flex; gap: 10px;">
          <div style="font-size: 20px;">${icon}</div>
          <div style="flex: 1;">
            <div style="font-weight: 600; color: #333; margin-bottom: 4px;">${notif.title}</div>
            <div style="font-size: 13px; color: #666; margin-bottom: 4px;">${notif.message}</div>
            <div style="font-size: 11px; color: #999;">${timeAgo}</div>
          </div>
          <button class="mark-read-btn" style="
            background: none;
            border: none;
            color: #999;
            cursor: pointer;
            padding: 5px;
            font-size: 12px;
          " title="Mark as read">×</button>
        </div>
      </div>
    `;
    })
    .join("");

  // Add click handlers
  notificationList.querySelectorAll(".notification-item").forEach((item) => {
    item.addEventListener("click", (e) => {
      if (e.target.classList.contains("mark-read-btn")) {
        e.stopPropagation();
        markNotificationAsRead(
          item.dataset.id,
          item.dataset.type,
          item.dataset.appointmentid
        );
        item.remove();
        checkForNotifications();
        return;
      }

      // Handle notification click (pass notification ID)
      handleNotificationClick(
        item.dataset.type,
        item.dataset.appointmentid,
        item.dataset.id
      );
    });

    item.addEventListener("mouseenter", function () {
      this.style.background = "#f5f5f5";
    });

    item.addEventListener("mouseleave", function () {
      this.style.background = "white";
    });
  });
}

// ✅ Handle notification click (NO SOUND - sound only plays on receipt)
function handleNotificationClick(type, appointmentId, notificationId) {
  // Close dropdown first
  const dropdown = document.getElementById("notificationDropdown");
  if (dropdown) dropdown.style.display = "none";

  // ✅ NO SOUND when clicking - sound only plays when receiving notification

  if (type === "doctor_enter") {
    // For nurses - find the notification from currentNotifications (includes doctorId)
    const notifications = window.currentNotifications || [];
    const notification = notifications.find(
      (n) => n.id === notificationId || n.appointmentId === appointmentId
    );

    if (notification && notification.data) {
      // Load nurse_notifications.js function if available
      if (typeof showDoctorEnterNotification === "function") {
        // Pass the original notification data which includes doctorId
        showDoctorEnterNotification(notification.data, true); // Pass true to indicate from header
      } else {
        // Fallback: navigate to appointments page
        window.location.href = `Appointments.html`;
      }
    } else {
      // Fallback: try localStorage
      const storedNotifications = JSON.parse(
        localStorage.getItem("doctorEnterNotifications") || "[]"
      );
      const storedNotification = storedNotifications.find(
        (n) => n.appointmentId === appointmentId && !n.handled
      );
      if (
        storedNotification &&
        typeof showDoctorEnterNotification === "function"
      ) {
        showDoctorEnterNotification(storedNotification, true);
      }
    }
  } else if (type === "appointment_time_arrived") {
    // For nurses - show appointment time arrived modal
    const notifications = window.currentNotifications || [];
    const notification = notifications.find(
      (n) => n.id === notificationId || n.appointmentId === appointmentId
    );

    if (notification && notification.data) {
      // Load appointment time arrived handler
      if (typeof showAppointmentTimeArrivedModal === "function") {
        showAppointmentTimeArrivedModal(notification.data, true);
      } else {
        // Fallback: try localStorage
        const storedNotifications = JSON.parse(
          localStorage.getItem("appointmentTimeArrivedNotifications") || "[]"
        );
        const storedNotification = storedNotifications.find(
          (n) => n.appointmentId === appointmentId && !n.handled
        );
        if (
          storedNotification &&
          typeof showAppointmentTimeArrivedModal === "function"
        ) {
          showAppointmentTimeArrivedModal(storedNotification, true);
        }
      }
    }
  } else if (
    type === "appointment_started" ||
    type === "appointment_canceled"
  ) {
    // For doctors - these are informational notifications, just mark as read
    const loggedInUserId = sessionStorage.getItem("userId");
    const notifications = window.currentNotifications || [];
    const notification = notifications.find(
      (n) =>
        (n.id === notificationId || n.appointmentId === appointmentId) &&
        (n.data?.doctorId === loggedInUserId || n.doctorId === loggedInUserId)
    );

    if (notification) {
      // Mark as handled
      markNotificationAsRead(notificationId, type, appointmentId);
      // Show alert or navigate to appointments
      if (type === "appointment_started") {
        alert(
          `✅ Patient ${
            notification.data?.patientName || notification.patientName
          } has been permitted to enter. Appointment is now Ongoing.`
        );
      } else {
        alert(
          `❌ Appointment for ${
            notification.data?.patientName || notification.patientName
          } has been canceled.`
        );
      }
      // Reload appointments if on appointments page
      if (
        window.location.href.includes("Appointments.html") &&
        typeof loadAppointments === "function"
      ) {
        loadAppointments();
      }
    }
  } else if (type === "nurse_response") {
    // For doctors - find the notification from currentNotifications
    const loggedInUserId = sessionStorage.getItem("userId");
    const notifications = window.currentNotifications || [];
    // ✅ Filter by doctorId - only show notifications meant for this doctor
    const notification = notifications.find(
      (n) =>
        (n.id === notificationId || n.appointmentId === appointmentId) &&
        (n.data?.doctorId === loggedInUserId || !n.data?.doctorId) // Match doctorId or backward compatibility
    );

    if (notification) {
      // Load doctor_notifications.js function if available
      if (typeof showNurseResponseNotification === "function") {
        // Pass the notification data
        const notifData = notification.data || notification;
        showNurseResponseNotification(notifData, true); // Pass true to indicate from header
      } else {
        // Fallback: navigate to appointments page
        window.location.href = `Appointments.html`;
      }
    }
  }
}

// ✅ Mark notification as read
function markNotificationAsRead(notificationId, type, appointmentId) {
  if (type === "doctor_enter") {
    let notifications = JSON.parse(
      localStorage.getItem("doctorEnterNotifications") || "[]"
    );
    notifications = notifications.map((n) => {
      if (n.appointmentId === appointmentId && !n.handled) {
        n.handled = true;
      }
      return n;
    });
    localStorage.setItem(
      "doctorEnterNotifications",
      JSON.stringify(notifications)
    );
  } else if (type === "nurse_response") {
    let notifications = JSON.parse(
      localStorage.getItem("nurseResponseNotifications") || "[]"
    );
    notifications = notifications.map((n) => {
      if (n.appointmentId === appointmentId && !n.handled) {
        n.handled = true;
      }
      return n;
    });
    localStorage.setItem(
      "nurseResponseNotifications",
      JSON.stringify(notifications)
    );
  } else if (type === "appointment_time_arrived") {
    let notifications = JSON.parse(
      localStorage.getItem("appointmentTimeArrivedNotifications") || "[]"
    );
    notifications = notifications.map((n) => {
      if (n.appointmentId === appointmentId && !n.handled) {
        n.handled = true;
      }
      return n;
    });
    localStorage.setItem(
      "appointmentTimeArrivedNotifications",
      JSON.stringify(notifications)
    );
  } else if (type === "appointment_started") {
    let notifications = JSON.parse(
      localStorage.getItem("appointmentStartedNotifications") || "[]"
    );
    notifications = notifications.map((n) => {
      if (n.appointmentId === appointmentId && !n.handled) {
        n.handled = true;
      }
      return n;
    });
    localStorage.setItem(
      "appointmentStartedNotifications",
      JSON.stringify(notifications)
    );
  } else if (type === "appointment_canceled") {
    let notifications = JSON.parse(
      localStorage.getItem("appointmentCanceledNotifications") || "[]"
    );
    notifications = notifications.map((n) => {
      if (n.appointmentId === appointmentId && !n.handled) {
        n.handled = true;
      }
      return n;
    });
    localStorage.setItem(
      "appointmentCanceledNotifications",
      JSON.stringify(notifications)
    );
  }

  checkForNotifications();
}

// ✅ Clear all notifications
function clearAllNotifications() {
  const role = sessionStorage.getItem("role");

  if (role === "Nurse") {
    let notifications = JSON.parse(
      localStorage.getItem("doctorEnterNotifications") || "[]"
    );
    notifications = notifications.map((n) => ({ ...n, handled: true }));
    localStorage.setItem(
      "doctorEnterNotifications",
      JSON.stringify(notifications)
    );

    // Also clear appointment time arrived notifications
    let timeArrivedNotifications = JSON.parse(
      localStorage.getItem("appointmentTimeArrivedNotifications") || "[]"
    );
    timeArrivedNotifications = timeArrivedNotifications.map((n) => ({
      ...n,
      handled: true,
    }));
    localStorage.setItem(
      "appointmentTimeArrivedNotifications",
      JSON.stringify(timeArrivedNotifications)
    );
  } else if (role === "Doctor") {
    const loggedInUserId = sessionStorage.getItem("userId");
    let notifications = JSON.parse(
      localStorage.getItem("nurseResponseNotifications") || "[]"
    );
    notifications = notifications.map((n) => {
      if (n.doctorId === loggedInUserId || !n.doctorId) {
        return { ...n, handled: true };
      }
      return n;
    });
    localStorage.setItem(
      "nurseResponseNotifications",
      JSON.stringify(notifications)
    );

    // Also clear appointment started notifications
    let startedNotifications = JSON.parse(
      localStorage.getItem("appointmentStartedNotifications") || "[]"
    );
    startedNotifications = startedNotifications.map((n) => {
      if (n.doctorId === loggedInUserId) {
        return { ...n, handled: true };
      }
      return n;
    });
    localStorage.setItem(
      "appointmentStartedNotifications",
      JSON.stringify(startedNotifications)
    );

    // Also clear appointment canceled notifications
    let canceledNotifications = JSON.parse(
      localStorage.getItem("appointmentCanceledNotifications") || "[]"
    );
    canceledNotifications = canceledNotifications.map((n) => {
      if (n.doctorId === loggedInUserId) {
        return { ...n, handled: true };
      }
      return n;
    });
    localStorage.setItem(
      "appointmentCanceledNotifications",
      JSON.stringify(canceledNotifications)
    );
  }

  checkForNotifications();
  loadNotifications();
}

// ✅ Get time ago string
function getTimeAgo(timestamp) {
  const now = Date.now();
  const diff = now - timestamp;
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);

  if (seconds < 60) return "Just now";
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return new Date(timestamp).toLocaleDateString();
}

// ✅ Add pulse animation CSS
const style = document.createElement("style");
style.textContent = `
  @keyframes pulse {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.5; }
  }
`;
document.head.appendChild(style);

// ✅ Initialize on page load
document.addEventListener("DOMContentLoaded", () => {
  loadHeader();
});

// ✅ Expose checkForNotifications globally for other scripts
window.checkForNotifications = checkForNotifications;

// ✅ Also initialize if DOM is already loaded
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", loadHeader);
} else {
  loadHeader();
}
