const togglePassword = document.getElementById("togglePassword");
const passwordInput = document.getElementById("password");

togglePassword.addEventListener("click", () => {
  const type = passwordInput.type === "password" ? "text" : "password";
  passwordInput.type = type;
  togglePassword.textContent = type === "password" ? "visibility_off" : "visibility";
});

function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 3000);
}

// ✅ Toggle visibility for new password fields
document.getElementById("toggleNewPassword").addEventListener("click", () => {
  const input = document.getElementById("newPassword");
  const icon = document.getElementById("toggleNewPassword");
  const type = input.type === "password" ? "text" : "password";
  input.type = type;
  icon.textContent = type === "password" ? "visibility_off" : "visibility";
});

document.getElementById("toggleConfirmPassword").addEventListener("click", () => {
  const input = document.getElementById("confirmPassword");
  const icon = document.getElementById("toggleConfirmPassword");
  const type = input.type === "password" ? "text" : "password";
  input.type = type;
  icon.textContent = type === "password" ? "visibility_off" : "visibility";
});

// ✅ Handle Password Reset
document.getElementById("passwordResetForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const newPassword = document.getElementById("newPassword").value.trim();
  const confirmPassword = document.getElementById("confirmPassword").value.trim();
  const email = sessionStorage.getItem("tempEmail");

  if (newPassword.length < 6) {
    alert("⚠️ Password must be at least 6 characters long.");
    return;
  }

  if (newPassword !== confirmPassword) {
    alert("⚠️ Passwords do not match!");
    return;
  }

  const resetBtn = document.getElementById("resetPasswordBtn");
  resetBtn.innerHTML = `<span class="loading-spinner"></span>Resetting...`;
  resetBtn.disabled = true;

  try {
    const response = await fetch("http://localhost:5000/api/reset-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, newPassword })
    });

    const data = await response.json();

    if (response.ok) {
      showToast("✅ Password reset successful!");
      
      // Clear temp data
      sessionStorage.removeItem("tempEmail");
      sessionStorage.removeItem("requiresReset");

      // Close modal and redirect
      document.getElementById("passwordResetModal").classList.add("hidden");
      
      const overlay = document.getElementById("loadingOverlay");
      overlay.style.display = "flex";

      setTimeout(() => {
        const role = sessionStorage.getItem("role");
        if (role === "Admin") {
          window.location.href = "admin/emrAdmin.html";
        } else {
          window.location.href = "user/Dashboard.html";
        }
      }, 1500);
    } else {
      alert("❌ " + data.message);
      resetBtn.innerHTML = "Reset Password";
      resetBtn.disabled = false;
    }
  } catch (err) {
    console.error("Reset Error:", err);
    alert("🚨 Error connecting to server.");
    resetBtn.innerHTML = "Reset Password";
    resetBtn.disabled = false;
  }
});

// ✅ Handle Login
document.getElementById('loginForm').addEventListener('submit', async function(e) {
  e.preventDefault();

  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value.trim();
  const loginBtn = document.getElementById('loginBtn');
  const overlay = document.getElementById('loadingOverlay');

  if (!email || !password) {
    alert("⚠️ Please fill in all fields.");
    return;
  }

  loginBtn.innerHTML = `<span class="loading-spinner"></span>Signing In...`;
  loginBtn.disabled = true;

  try {
    const response = await fetch("http://localhost:5000/api/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });

    const data = await response.json();

    loginBtn.innerHTML = "Sign In";
    loginBtn.disabled = false;

    if (response.ok) {
      sessionStorage.setItem("loggedIn", "true");
      sessionStorage.setItem("role", data.role);
      sessionStorage.setItem("name", data.name);
      sessionStorage.setItem("email", data.email);
      sessionStorage.setItem("userId", data._id || data.userId);
sessionStorage.setItem("sessionLogId", data.sessionLogId);

      // ✅ Check if password reset is required
      if (data.requiresReset) {
        sessionStorage.setItem("tempEmail", email);
        sessionStorage.setItem("requiresReset", "true");
        document.getElementById("passwordResetModal").classList.remove("hidden");
        showToast("⚠️ Please reset your temporary password");
      } else {
        showToast(`✅ Login successful as ${data.role}`);
        overlay.style.display = "flex";

        setTimeout(() => {
          if (data.role === "Admin") {
            window.location.href = "admin/emrAdmin.html";
          } else {
            window.location.href = "user/Dashboard.html";
          }
        }, 1800);
      }
    } else {
      alert("❌ " + data.message);
    }
  } catch (err) {
    console.error("Login Error:", err);
    alert("🚨 Error connecting to server.");
    loginBtn.innerHTML = "Sign In";
    loginBtn.disabled = false;
  }
});