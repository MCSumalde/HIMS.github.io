// ====== NURSE NOTIFICATION SYSTEM FOR DOCTOR ENTER BUTTON ======

// ✅ Check for doctor Enter notifications (for header display only - no auto popups)
function checkDoctorEnterNotifications() {
  // This function is now only used by header.js for displaying notifications
  // Auto-popups are disabled - notifications appear in header bell
  return;
}

// ✅ Show notification modal to nurse (only when clicked from header)
function showDoctorEnterNotification(notification, fromHeader = false) {
  // Check if modal already exists - if it does, don't show another one
  const existingModal = document.getElementById("doctorEnterNotificationModal");
  if (existingModal && !fromHeader) {
    return; // Don't show duplicate modals (unless explicitly from header)
  }
  
  // Mark as shown immediately to prevent duplicates
  const shownKey = `notificationShown_${notification.appointmentId}_${notification.timestamp}`;
  if (sessionStorage.getItem(shownKey) && !fromHeader) {
    return; // Already shown (unless from header click)
  }
  sessionStorage.setItem(shownKey, "true");

  const modal = document.createElement("div");
  modal.id = "doctorEnterNotificationModal";
  modal.className = "doctor-enter-notification-modal";
  modal.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.6);
    display: flex;
    justify-content: center;
    align-items: center;
    z-index: 10000;
  `;

  modal.innerHTML = `
    <div style="
      background: white;
      border-radius: 12px;
      padding: 30px;
      max-width: 500px;
      width: 90%;
      box-shadow: 0 5px 25px rgba(0,0,0,0.3);
      animation: fadeIn 0.3s;
    ">
      <div style="text-align: center; margin-bottom: 20px;">
        <div style="font-size: 48px; margin-bottom: 10px;">🔔</div>
        <h2 style="margin: 0; color: #358F85;">Doctor Consultation Request</h2>
      </div>
      
      <div style="margin-bottom: 20px; padding: 15px; background: #f5f5f5; border-radius: 8px;">
        <p style="margin: 5px 0;"><strong>Doctor:</strong> ${notification.doctorName || 'Unknown'}</p>
        <p style="margin: 5px 0;"><strong>Patient:</strong> ${notification.patientName || 'Unknown'}</p>
        <p style="margin: 5px 0;"><strong>Appointment ID:</strong> ${notification.appointmentId || 'N/A'}</p>
        <p style="margin: 5px 0; color: #666; font-size: 14px;">
          The doctor is ready to consult with this patient. Is the patient present?
        </p>
      </div>
      
      <div style="display: flex; gap: 10px; justify-content: center;">
        <button id="confirmPatientPresentBtn" style="
          background: #358F85;
          color: white;
          border: none;
          padding: 12px 30px;
          border-radius: 5px;
          cursor: pointer;
          font-weight: 600;
          font-size: 16px;
        ">OK</button>
        <button id="cancelPatientNotPresentBtn" style="
          background: #ca3030;
          color: white;
          border: none;
          padding: 12px 30px;
          border-radius: 5px;
          cursor: pointer;
          font-weight: 600;
          font-size: 16px;
        ">Cancel</button>
      </div>
    </div>
  `;

  document.body.appendChild(modal);
  // ✅ NO SOUND when clicking notification - sound only plays on receipt (handled in header.js)

  // Handle OK button (Patient Present)
  document.getElementById("confirmPatientPresentBtn").addEventListener("click", async () => {
    modal.remove();
    await handlePatientResponse(notification, true);
  });

  // Handle Cancel button (Patient Not Present)
  document.getElementById("cancelPatientNotPresentBtn").addEventListener("click", async () => {
    modal.remove();
    await handlePatientResponse(notification, false);
  });
}

// ✅ Handle nurse's response (OK or Cancel)
async function handlePatientResponse(notification, patientPresent) {
  try {
    const appointmentId = notification.appointmentId;
    
    if (patientPresent) {
      // Patient is present - start the appointment (this sets status to Ongoing)
      try {
        // Start the appointment - this endpoint sets status to Ongoing automatically
        const startResponse = await fetch(`http://localhost:5000/api/appointments/${appointmentId}/start`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" }
        });

        if (!startResponse.ok) {
          const errorText = await startResponse.text();
          let errorMessage = "Failed to start appointment";
          try {
            const errorData = JSON.parse(errorText);
            errorMessage = errorData.message || errorMessage;
          } catch (e) {
            errorMessage = errorText || errorMessage;
          }
          console.error("Failed to start appointment:", errorMessage);
          throw new Error(errorMessage);
        }

        // Notify doctor (only the doctor who sent the Enter notification)
        const doctorId = notification.doctorId || notification.data?.doctorId;
        notifyDoctor(appointmentId, notification.patientName, "ongoing", doctorId);
        
        alert(`✅ Patient is present. Appointment status changed to Ongoing. Doctor has been notified.`);
      } catch (err) {
        console.error("Error updating appointment:", err);
        alert(`❌ Failed to update appointment status: ${err.message}`);
        return; // Don't mark as handled if it failed
      }
    } else {
      // Patient not present - change status to Canceled and move to archive
      const updateResponse = await fetch(`http://localhost:5000/api/appointments/${appointmentId}/status`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "Canceled" })
      });

      if (updateResponse.ok) {
        // Archive the appointment
        await fetch(`http://localhost:5000/api/appointments/${appointmentId}/archive`, {
          method: "POST",
          headers: { "Content-Type": "application/json" }
        });

        // Notify doctor (only the doctor who sent the Enter notification)
        const doctorId = notification.doctorId || notification.data?.doctorId;
        notifyDoctor(appointmentId, notification.patientName, "canceled", doctorId);
        
        alert(`❌ Patient is not present. Appointment canceled and moved to archive. Doctor has been notified.`);
      } else {
        alert("❌ Failed to cancel appointment.");
      }
    }

    // Mark notification as handled only if successful
    if (patientPresent) {
      markNotificationAsHandled(notification);
    } else {
      // For canceled, mark as handled after successful archive
      markNotificationAsHandled(notification);
    }

    // Reload appointments if on appointments page
    if (window.location.href.includes("Appointments.html") && typeof loadAppointments === "function") {
      await loadAppointments();
    } else if (window.location.href.includes("Appointments.html")) {
      location.reload();
    }

  } catch (err) {
    console.error("Error handling patient response:", err);
    alert("❌ There was an error processing your response. Please try again.");
    // Don't mark as handled if there was an error, so it can be retried
  }
}

// ✅ Notify doctor about the response (only the specific doctor who sent the Enter notification)
function notifyDoctor(appointmentId, patientName, status, doctorId) {
  // ✅ Only notify the specific doctor who sent the Enter notification
  const loggedInUserId = sessionStorage.getItem("userId");
  
  // Check if the current user is the doctor who should receive this notification
  if (doctorId && loggedInUserId !== doctorId) {
    // This notification is not for the current user, but we still need to store it
    // for when that doctor's tab checks for notifications
    const notification = {
      type: "nurse_response",
      appointmentId: appointmentId,
      patientName: patientName,
      status: status, // "ongoing" or "canceled"
      doctorId: doctorId, // ✅ Store which doctor this notification is for
      timestamp: Date.now()
    };

    // Store with doctor-specific key
    localStorage.setItem(`nurseResponseNotification_${appointmentId}_${doctorId}`, JSON.stringify(notification));
    
    // Also add to list (filtered by doctorId when checking)
    let notifications = JSON.parse(localStorage.getItem("nurseResponseNotifications") || "[]");
    notifications.push(notification);
    localStorage.setItem("nurseResponseNotifications", JSON.stringify(notifications));

    // Trigger storage event
    window.dispatchEvent(new StorageEvent('storage', {
      key: `nurseResponseNotification_${appointmentId}_${doctorId}`,
      newValue: JSON.stringify(notification)
    }));
  } else {
    // For the target doctor or if doctorId not specified (backward compatibility)
    const notification = {
      type: "nurse_response",
      appointmentId: appointmentId,
      patientName: patientName,
      status: status, // "ongoing" or "canceled"
      doctorId: doctorId, // ✅ Store which doctor this notification is for
      timestamp: Date.now()
    };

    localStorage.setItem(`nurseResponseNotification_${appointmentId}`, JSON.stringify(notification));
    
    // Also add to list
    let notifications = JSON.parse(localStorage.getItem("nurseResponseNotifications") || "[]");
    notifications.push(notification);
    localStorage.setItem("nurseResponseNotifications", JSON.stringify(notifications));

    // Trigger storage event
    window.dispatchEvent(new StorageEvent('storage', {
      key: `nurseResponseNotification_${appointmentId}`,
      newValue: JSON.stringify(notification)
    }));
  }
}

// ✅ Mark notification as handled
function markNotificationAsHandled(notification) {
  try {
    let notifications = JSON.parse(localStorage.getItem("doctorEnterNotifications") || "[]");
    const index = notifications.findIndex(n => 
      n.appointmentId === notification.appointmentId && 
      n.timestamp === notification.timestamp
    );
    
    if (index !== -1) {
      notifications[index].handled = true;
      localStorage.setItem("doctorEnterNotifications", JSON.stringify(notifications));
    }
  } catch (err) {
    console.error("Error marking notification as handled:", err);
  }
}

// ✅ Play notification sound
function playNotificationSound() {
  try {
    const audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.value = 1000;
    oscillator.type = 'sine';
    gainNode.gain.value = 0.3;
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.3);
  } catch (err) {
    console.log("Audio not available");
  }
}

// ✅ Check for doctor notifications on page load (but don't auto-show modals)
document.addEventListener("DOMContentLoaded", () => {
  // Don't auto-show modals - notifications will appear in header
  // checkDoctorEnterNotifications();
  
  // Check periodically for header notifications
  setInterval(() => {
    // Notifications are handled by header.js
    if (typeof checkForNotifications === "function") {
      checkForNotifications();
    }
  }, 3000);
  
  // Listen for storage events (cross-tab communication)
  window.addEventListener('storage', (e) => {
    if (e.key && (e.key.startsWith('doctorEnterNotification_') || e.key.startsWith('appointmentTimeArrived_'))) {
      // Update header notifications (but don't trigger sound - it will be handled by checkForNotifications)
      if (typeof checkForNotifications === "function") {
        // Small delay to ensure localStorage is updated
        setTimeout(() => {
          checkForNotifications();
        }, 100);
      }
    }
  });
});

// ✅ Also check when page becomes visible
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    if (typeof checkForNotifications === "function") {
      checkForNotifications();
    }
  }
});
