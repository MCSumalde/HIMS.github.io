async function loadPatientInfo() {
  const params = new URLSearchParams(window.location.search);
  const patientId = params.get("patientId");

  if (!patientId) {
    alert("No patient selected!");
    return;
  }

  try {
    const res = await fetch(`http://localhost:5000/api/patients/${patientId}`);
    if (!res.ok) throw new Error("Patient not found");

    const p = await res.json();

    // Fill form fields
    document.getElementById("firstname").value = p.firstname || "";
    document.getElementById("lastname").value = p.lastname || "";
    document.getElementById("dob").value = p.dob ? p.dob.substring(0,10) : "";
    document.getElementById("gender").value = p.gender || "";
    document.getElementById("status").value = p.status?.toLowerCase() || "";
    document.getElementById("phone").value = p.phone || "";
    document.getElementById("email").value = p.email || "";
    document.getElementById("address").value = p.address || "";
    document.getElementById("barangay").value = p.barangay || "";
    document.getElementById("city").value = p.city || "";
    document.getElementById("zipcode").value = p.zipcode || "";
    document.getElementById("em_fullname").value = p.em_fullname || "";
    document.getElementById("em_phone").value = p.em_phone || "";
    document.getElementById("relationship").value = p.relationship || "";
    document.getElementById("em_email").value = p.em_email || "";

    document.querySelector("header h1").textContent = `Patient Information - ${p.firstname} ${p.lastname}`;
    // ✅ Follow-up Date redirect to Appointment Scheduler
const followUpInput = document.getElementById("singleFollowUp");
if (followUpInput) {
  followUpInput.addEventListener("change", () => {
    const followUpDate = followUpInput.value;
    if (!followUpDate) return;

    const patientFullName = `${p.firstname} ${p.lastname}`;
    
    // Save recent patient access
    addRecentPatient(p.patientId, patientFullName);

    // Redirect to Appointment Schedule page with date and patient
    window.location.href = `AppointmentScheduler.html?patientId=${p.patientId}&date=${followUpDate}`;
  });
}
  } catch (err) {
    console.error("Error loading patient info:", err);
    alert("Unable to load patient information.");
  }
}

window.addEventListener("DOMContentLoaded", loadPatientInfo);


// ✅ EDIT + SAVE FUNCTIONALITY
document.addEventListener("DOMContentLoaded", () => {
  const editBtn = document.querySelector(".editbtn");
  const buttonCon = document.getElementById("buttonCon");
  const formInputs = document.querySelectorAll("#patientForm input, #patientForm select");
  const saveBtn = document.querySelector(".savebtn");
  const cancelBtn = document.querySelector(".cancelbtn");

  buttonCon.style.display = "none";

  editBtn.addEventListener("click", (e) => {
    e.preventDefault();
    const isEditing = editBtn.classList.toggle("editing");

    if (isEditing) {
      formInputs.forEach(input => input.disabled = false);
      buttonCon.style.display = "flex";
      editBtn.innerHTML = `<i class="fa-solid fa-xmark"></i> Exit Edit Mode`;
    } else {
      formInputs.forEach(input => input.disabled = true);
      buttonCon.style.display = "none";
      editBtn.innerHTML = `<i class="fa-solid fa-pen-to-square"></i> Edit`;
    }
  });

  cancelBtn.addEventListener("click", (e) => {
    e.preventDefault();
    loadPatientInfo(); // reload previous values
    formInputs.forEach(input => input.disabled = true);
    buttonCon.style.display = "none";
    editBtn.classList.remove("editing");
    editBtn.innerHTML = `<i class="fa-solid fa-pen-to-square"></i> Edit`;
  });

  // ✅ SAVE CHANGES TO BACKEND
  saveBtn.addEventListener("click", async (e) => {
    e.preventDefault();
    const params = new URLSearchParams(window.location.search);
    const patientId = params.get("patientId");

    const updatedData = {
      firstname: document.getElementById("firstname").value,
      lastname: document.getElementById("lastname").value,
      dob: document.getElementById("dob").value,
      gender: document.getElementById("gender").value,
      status: document.getElementById("status").value,
      phone: document.getElementById("phone").value,
      email: document.getElementById("email").value,
      address: document.getElementById("address").value,
      barangay: document.getElementById("barangay").value,
      city: document.getElementById("city").value,
      zipcode: document.getElementById("zipcode").value,
      em_fullname: document.getElementById("em_fullname").value,
      em_phone: document.getElementById("em_phone").value,
      relationship: document.getElementById("relationship").value,
      em_email: document.getElementById("em_email").value
    };

    try {
      const res = await fetch(`http://localhost:5000/api/patients/${patientId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedData)
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message || "Error saving data");

      alert("✅ Patient information saved successfully!");

      formInputs.forEach(input => input.disabled = true);
      buttonCon.style.display = "none";
      editBtn.classList.remove("editing");
      editBtn.innerHTML = `<i class="fa-solid fa-pen-to-square"></i> Edit`;
    } catch (err) {
      console.error("Save error:", err);
      alert("❌ Failed to save changes.");
    }
  });
});

document.addEventListener("DOMContentLoaded", () => {
  const patientId = new URLSearchParams(window.location.search).get("patientId");
  if (!patientId) return; // no ID, skip

  // Update all nav-bar links so they keep the same patient ID
  document.querySelectorAll("nav-bar a").forEach(link => {
    const href = link.getAttribute("href");
    if (href && !href.includes("?patientId=")) {
      link.setAttribute("href", `${href}?patientId=${patientId}`);
    }
  });
});