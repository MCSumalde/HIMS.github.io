async function loadPatients() {
  try {
    const res = await fetch("http://localhost:5000/api/patients");
    const patients = await res.json();

    const table = document.querySelector("table");
    const searchBar = document.querySelector(".searchBar");
    const sortSelect = document.getElementById("filterSelect");

    // Render table with filtered and sorted patients
    function renderTable(displayPatients) {
      let rows = `
        <tr>
          <th>Patient ID</th>
          <th>Name</th>
          <th>Date of Birth</th>
          <th>Gender</th>
          <th>Action</th>
        </tr>
      `;

      if (displayPatients.length === 0) {
        rows += `
          <tr>
            <td colspan="5" style="text-align: center; padding: 20px; color: #888;">
              No patients found matching your criteria.
            </td>
          </tr>
        `;
      } else {
        displayPatients.forEach(p => {
          rows += `
            <tr>
              <td>${p.patientId || 'N/A'}</td>
              <td>${p.firstname || ''} ${p.lastname || ''}</td>
              <td>${p.dob ? p.dob.substring(0, 10) : 'N/A'}</td>
              <td>
                ${
                  p.gender?.toLowerCase() === "male" 
                    ? `<i class="fa-solid fa-mars" title="Male"></i>` 
                    : p.gender?.toLowerCase() === "female" 
                    ? `<i class="fa-solid fa-venus" title="Female"></i>` 
                    : p.gender || 'N/A'
                }
              </td>
              <td>
                <a href="#" class="viewBtn" data-id="${p.patientId}" data-name="${p.firstname} ${p.lastname}">
                  <i style="margin-right: 5px;" class="fa-regular fa-eye"></i>View
                </a>
              </td>
            </tr>
          `;
        });
      }

      table.innerHTML = rows;

      // Attach click event to View buttons
      document.querySelectorAll(".viewBtn").forEach(btn => {
        btn.addEventListener("click", e => {
          e.preventDefault();
          const patientId = btn.dataset.id;
          const patientName = btn.dataset.name;
          addRecentPatient(patientId, patientName);
          window.location.href = `PatientInfo.html?patientId=${patientId}`;
        });
      });

      document.querySelector(".bottomSec h3").innerText =
        `Showing ${displayPatients.length} of ${patients.length} patient(s)`;
    }

    // Sort patients based on selected option
    function sortPatients(patientList, sortOption) {
      const sorted = [...patientList];
      
      switch(sortOption) {
        case "a-z":
          sorted.sort((a, b) => {
            const nameA = `${a.firstname || ''} ${a.lastname || ''}`.toLowerCase();
            const nameB = `${b.firstname || ''} ${b.lastname || ''}`.toLowerCase();
            return nameA.localeCompare(nameB);
          });
          break;
        case "z-a":
          sorted.sort((a, b) => {
            const nameA = `${a.firstname || ''} ${a.lastname || ''}`.toLowerCase();
            const nameB = `${b.firstname || ''} ${b.lastname || ''}`.toLowerCase();
            return nameB.localeCompare(nameA);
          });
          break;
        case "latest":
          // Latest = highest patient ID (e.g., P010 comes before P001)
          sorted.sort((a, b) => {
            const idA = a.patientId || '';
            const idB = b.patientId || '';
            return idB.localeCompare(idA, undefined, { numeric: true, sensitivity: 'base' });
          });
          break;
        case "oldest":
          // Oldest = lowest patient ID (e.g., P001 comes before P010)
          sorted.sort((a, b) => {
            const idA = a.patientId || '';
            const idB = b.patientId || '';
            return idA.localeCompare(idB, undefined, { numeric: true, sensitivity: 'base' });
          });
          break;
        default:
          // No sorting for "all"
          break;
      }
      
      return sorted;
    }

    // Filter and sort patients
    function filterAndSortPatients() {
      const searchTerm = searchBar.value.toLowerCase().trim();
      const sortOption = sortSelect.value.toLowerCase();

      // Filter by search term
      const filtered = patients.filter(p => {
        return (
          searchTerm === "" ||
          (p.firstname && p.firstname.toLowerCase().includes(searchTerm)) ||
          (p.lastname && p.lastname.toLowerCase().includes(searchTerm)) ||
          (p.patientId && p.patientId.toLowerCase().includes(searchTerm))
        );
      });

      // Sort filtered results
      const sorted = sortPatients(filtered, sortOption);
      renderTable(sorted);
    }

    // Event listeners
    searchBar.addEventListener("input", filterAndSortPatients);
    sortSelect.addEventListener("change", () => {
      // Save the selected sort option to sessionStorage
      sessionStorage.setItem('patientSortOption', sortSelect.value);
      filterAndSortPatients();
    });

    // Restore previous sort option from sessionStorage
    const savedSortOption = sessionStorage.getItem('patientSortOption');
    if (savedSortOption) {
      sortSelect.value = savedSortOption;
    }

    // Initial render with saved sort option applied
    filterAndSortPatients();

  } catch (err) {
    console.error("Error loading patients:", err);
    document.querySelector(".bottomSec h3").innerText = 
      "Error loading patients. Please try again.";
  }
}

window.onload = loadPatients;