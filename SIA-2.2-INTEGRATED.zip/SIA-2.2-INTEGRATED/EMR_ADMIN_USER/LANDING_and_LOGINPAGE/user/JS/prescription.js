// prescription.js - Complete prescription management with integrated medication functionality

// ============================================
// UTILITY FUNCTIONS
// ============================================

function escapeHtml(s) {
  return String(s || "").replace(/[&<>"']/g, (m) =>
    ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;",
    }[m])
  );
}

function normalizeFormData(raw) {
  const out = {};
  for (const k of Object.keys(raw)) {
    let v = raw[k]?.trim();
    out[k] = k === "quantity" ? Number(v) || 0 : v;
  }
  return out;
}

// ============================================
// LOAD DOCTORS DROPDOWN
// ============================================
async function loadDoctorsDropdown(selectElementId, autoFillLoggedInDoctor = false) {
  const select = document.getElementById(selectElementId);
  if (!select) return;

  try {
    const res = await fetch("http://localhost:5000/api/users");
    if (!res.ok) throw new Error(`Failed to fetch doctors (${res.status})`);
    const users = await res.json();
    const doctors = users.filter((u) => u.role === "Doctor");

    if (doctors.length === 0) {
      select.innerHTML = `<option value="">No doctors found</option>`;
      return;
    }

    // ✅ FIX: Get logged-in doctor info for auto-fill
    const loggedInName = sessionStorage.getItem("name");
    const loggedInRole = sessionStorage.getItem("role");
    let selectedDoctorValue = "";
    
    if (autoFillLoggedInDoctor && loggedInRole === "Doctor" && loggedInName) {
      selectedDoctorValue = `Dr. ${loggedInName}`;
    }

    select.innerHTML = `
      <option value="">Select Doctor</option>
      ${doctors
        .map((d) => {
          const doctorValue = `Dr. ${d.name}`;
          const isSelected = autoFillLoggedInDoctor && doctorValue === selectedDoctorValue ? 'selected' : '';
          return `<option value="${doctorValue}" ${isSelected}>${doctorValue}</option>`;
        })
        .join("")}
    `;

    // ✅ FIX: Auto-fill and disable if logged in as doctor
    if (autoFillLoggedInDoctor && loggedInRole === "Doctor" && selectedDoctorValue) {
      select.value = selectedDoctorValue;
      select.disabled = true;
      select.style.backgroundColor = "#f3f1f1";
      select.style.cursor = "not-allowed";
    }

    try {
      if (window.jQuery && $(`#${selectElementId}`).select2) {
        const select2Options = {
          placeholder: "Search for a doctor",
          allowClear: !(autoFillLoggedInDoctor && loggedInRole === "Doctor"), // Don't allow clear if auto-filled
          width: "100%",
        };
        
        // ✅ FIX: Disable Select2 if auto-filled
        if (autoFillLoggedInDoctor && loggedInRole === "Doctor" && selectedDoctorValue) {
          select2Options.disabled = true;
        }
        
        $(`#${selectElementId}`).select2(select2Options);
        
        // ✅ FIX: Ensure Select2 is disabled after initialization
        if (autoFillLoggedInDoctor && loggedInRole === "Doctor" && selectedDoctorValue) {
          $(`#${selectElementId}`).prop('disabled', true);
          $(`#${selectElementId}`).next('.select2-container').css('pointer-events', 'none');
          $(`#${selectElementId}`).next('.select2-container').css('opacity', '0.6');
        }
      }
    } catch (err2) {
      console.warn("Select2 init failed:", err2);
    }
  } catch (err) {
    console.error("Error loading doctors:", err);
    select.innerHTML = `<option value="">Error loading doctors</option>`;
  }
}

// ============================================
// LOAD SERVICES DROPDOWN
// ============================================
async function loadServicesDropdown() {
  const select = document.getElementById("singleService");
  if (!select) return;

  try {
    const res = await fetch(
      "http://localhost:5000/api/integrations/billing/services"
    );
    if (!res.ok) {
      throw new Error("Failed to fetch services");
    }

    const result = await res.json();

    if (!result.success || !result.data) {
      throw new Error("Invalid response from services API");
    }

    const services = result.data;

    if (services.length === 0) {
      select.innerHTML = `<option value="">No services found</option>`;
      console.warn("⚠️ No services found in billing system");
      return;
    }

    select.innerHTML =
      '<option value="">Search and select a service...</option>';

    services.forEach((service) => {
      const option = document.createElement("option");
      option.value = service.service;
      option.textContent = `${service.service}${
        service.category && service.category !== "Consultation Services"
          ? ` (${service.category})`
          : ""
      }${service.price ? ` - ₱${service.price.toFixed(2)}` : ""}`;
      option.setAttribute("data-price", service.price || 0);
      option.setAttribute("data-category", service.category || "");
      option.setAttribute("data-code", service.code || "");
      select.appendChild(option);
    });

    if (window.jQuery && $("#singleService").select2) {
      $("#singleService").select2({
        placeholder: "Search and select a service...",
        allowClear: true,
        width: "100%",
        minimumInputLength: 0,
      });
    }

    console.log(`✅ Loaded ${services.length} services from billing system`);
  } catch (err) {
    console.error("❌ Error loading services:", err);
    select.innerHTML = `<option value="">Error loading services. Please try again.</option>`;
  }
}

// ============================================
// CREATE MEDICATION FORM
// ============================================
function createMedicationForm(index, existingMed = null, isReadOnly = false) {
  const wrapper = document.createElement("div");
  wrapper.classList.add("medecineCon");
  wrapper.innerHTML = `
    <div class="medecineHeader">
      <h3>Medication ${index}</h3>
      <i class="fa-solid fa-trash deleteMed" data-id="${
        existingMed?.medId || ""
      }"></i>
    </div>
    <form class="patientForm">
      <div class="leftform">
        <div class="form-group">
          <label>Medication Name</label>
          <select id="medicineSelect${index}" class="medicineSelect" name="medicname" required></select>
        </div>
        <div class="form-group">
          <label>Frequency</label>
          <select id="freqSelect${index}" class="freqSelect" name="frequency" required></select>
        </div>
        <div class="form-group">
          <label>Quantity</label>
          <input type="number" name="quantity" value="${
            existingMed?.quantity || ""
          }" required />
        </div>
      </div>
      <div class="leftform">
        <div class="form-group">
          <label>Dosage</label>
          <select id="dosageSelect${index}" class="dosageSelect" name="dosage" required></select>
        </div>
        <div class="form-group">
          <label>Prescribe By *</label>
          <select id="selectPrescriber${index}" name="presby" required></select>
        </div>
        <div class="form-group">
          <label>Prescription Notes</label>
          <input type="text" name="presNotes" value="${
            existingMed?.presNotes || ""
          }" required />
        </div>
      </div>
    </form>
  `;

  return wrapper;
}

// ============================================
// ACTIVATE MEDICINE SEARCH
// ============================================
function activateMedicineSearch(medSelector, freqSelector, dosageSelector) {
  const selectElement = $(medSelector);

  const defaultFrequencies = [
    { id: "Once a day", text: "Once a day" },
    { id: "Twice a day", text: "Twice a day" },
    { id: "Every 8 hours", text: "Every 8 hours" },
    { id: "Every 12 hours", text: "Every 12 hours" },
    { id: "As needed", text: "As needed" },
  ];

  const defaultDosages = [
    { id: "250 mg", text: "250 mg" },
    { id: "500 mg", text: "500 mg" },
    { id: "1 tablet", text: "1 tablet" },
    { id: "2 tablets", text: "2 tablets" },
  ];

  $(freqSelector).select2({
    placeholder: "Select frequency",
    data: defaultFrequencies,
  });

  $(dosageSelector).select2({
    placeholder: "Select dosage",
    data: defaultDosages,
  });

  selectElement.select2({
    placeholder: "Search medicine...",
    minimumInputLength: 1,
    ajax: {
      transport: async function (params, success, failure) {
        const searchTerm = params.data.q || "";

        const formatMedicineData = (data) => {
          return {
            results: data.map((m) => {
              let extractedDosage =
                m.dosage ||
                m.strength ||
                m.name.match(/\d+\s?(mg|ML|ml|MG)/i)?.[0] ||
                "";
              return {
                id: m.name,
                text: m.name,
                dosage: extractedDosage || "500 mg",
                frequency: "Once a day",
              };
            }),
          };
        };

        try {
          const pharmacyDbRes = await fetch(
            `http://localhost:5000/api/pharmacydb/pharmacy-medicines?search=${encodeURIComponent(
              searchTerm
            )}`
          );

          if (pharmacyDbRes.ok) {
            const pharmacyData = await pharmacyDbRes.json();
            success(formatMedicineData(pharmacyData));
            return;
          } else if (pharmacyDbRes.status === 503) {
            throw new Error("Pharmacy DB connection unavailable, trying API...");
          } else {
            throw new Error(`Pharmacy DB search returned ${pharmacyDbRes.status}`);
          }
        } catch (pharmacyDbErr) {
          try {
            const pharmacyController = new AbortController();
            const pharmacyTimeout = setTimeout(
              () => pharmacyController.abort(),
              2000
            );

            const pharmacyRes = await fetch(
              `http://localhost:5001/api/medicines/search?search=${encodeURIComponent(
                searchTerm
              )}`,
              {
                headers: {
                  Authorization: `Bearer PharmacyDBKey12345`,
                },
                signal: pharmacyController.signal,
              }
            );

            clearTimeout(pharmacyTimeout);

            if (pharmacyRes.ok) {
              const pharmacyData = await pharmacyRes.json();
              success(formatMedicineData(pharmacyData));
              return;
            } else {
              throw new Error(`Pharmacy API returned ${pharmacyRes.status}`);
            }
          } catch (pharmacyApiErr) {
            try {
              const emrRes = await fetch(
                `http://localhost:5000/api/pharmacydb/medicines?search=${encodeURIComponent(
                  searchTerm
                )}`
              );

              if (emrRes.ok) {
                const emrData = await emrRes.json();
                success(formatMedicineData(emrData));
              } else {
                throw new Error(`EMR local search returned ${emrRes.status}`);
              }
            } catch (emrErr) {
              console.error("❌ All medicine search methods failed:", emrErr);
              success({ results: [] });
            }
          }
        }
      },
    },
  });

  selectElement.on("select2:select", (e) => {
    const med = e.params.data;
    $(freqSelector).val(med.frequency).trigger("change");
    $(dosageSelector).val(med.dosage).trigger("change");
  });
}

// ============================================
// INITIALIZE READ-ONLY MEDICATION FORM (for Medications.html page)
// ============================================
async function initializeReadOnlyMedication(index, existingMed) {
  // Step 1: Load doctors dropdown first
  await loadDoctorsDropdown(`selectPrescriber${index}`);

  // Step 2: Initialize Select2 for medicine, frequency, dosage
  const medicineSelect = $(`#medicineSelect${index}`);
  const freqSelect = $(`#freqSelect${index}`);
  const dosageSelect = $(`#dosageSelect${index}`);
  const prescriberSelect = $(`#selectPrescriber${index}`);

  // Default options for frequency and dosage
  const defaultFrequencies = [
    { id: "Once a day", text: "Once a day" },
    { id: "Twice a day", text: "Twice a day" },
    { id: "Every 8 hours", text: "Every 8 hours" },
    { id: "Every 12 hours", text: "Every 12 hours" },
    { id: "As needed", text: "As needed" },
  ];

  const defaultDosages = [
    { id: "250 mg", text: "250 mg" },
    { id: "500 mg", text: "500 mg" },
    { id: "1 tablet", text: "1 tablet" },
    { id: "2 tablets", text: "2 tablets" },
  ];

  // Initialize frequency select with default options
  freqSelect.select2({
    placeholder: "Select frequency",
    data: defaultFrequencies,
  });

  // Initialize dosage select with default options
  dosageSelect.select2({
    placeholder: "Select dosage",
    data: defaultDosages,
  });

  // Initialize medicine select (no AJAX for read-only)
  medicineSelect.select2({
    placeholder: "Medicine name",
    minimumInputLength: 0,
  });

  // Step 3: Set values from existing medication
  if (existingMed.medicname) {
    const medicineOption = new Option(
      existingMed.medicname,
      existingMed.medicname,
      true,
      true
    );
    medicineSelect.append(medicineOption).trigger("change");
  }

  if (existingMed.frequency) {
    freqSelect.val(existingMed.frequency).trigger("change");
  }

  if (existingMed.dosage) {
    dosageSelect.val(existingMed.dosage).trigger("change");
  }

  if (existingMed.presby) {
    prescriberSelect.val(existingMed.presby).trigger("change");
  }

  // Step 4: Disable all inputs
  setTimeout(() => {
    const form = $(`#medicineSelect${index}`).closest(".patientForm")[0];
    const inputs = form.querySelectorAll(
      'input:not([type="hidden"]), select'
    );

    inputs.forEach((input) => {
      input.disabled = true;
      if ($(input).hasClass("select2-hidden-accessible")) {
        $(input).prop("disabled", true).trigger("change");
      }
    });

    form.style.opacity = "0.7";
    form.style.pointerEvents = "none";
  }, 100);
}

// ============================================
// LOAD MEDICATIONS (for Medications.html page)
// ============================================
async function loadMedications(patientId) {
  const medicationsContainer = document.getElementById("medicationsContainer");
  if (!medicationsContainer) return;

  try {
    // Only load medications that are NOT in history (isHistory: false or undefined)
    const res = await fetch(
      `http://localhost:5000/api/patients/${patientId}/medications?isHistory=false`
    );
    if (!res.ok) throw new Error(`Failed to load meds (${res.status})`);
    const meds = await res.json();

    medicationsContainer.innerHTML = "";
    let medCount = meds.length;

    if (meds.length === 0) {
      medicationsContainer.innerHTML = `<p style="color:gray;text-align:center;">No medications yet</p>`;
      return;
    }

    // ✅ Load medications sequentially to avoid race conditions
    for (let idx = 0; idx < meds.length; idx++) {
      const m = meds[idx];
      const formWrapper = createMedicationForm(idx + 1, m, true);
      medicationsContainer.appendChild(formWrapper);

      // Initialize and populate this medication form
      await initializeReadOnlyMedication(idx + 1, m);
    }

    // ✅ Delete Medications (with timeout to ensure DOM is ready)
    setTimeout(() => {
      document.querySelectorAll(".deleteMed").forEach((icon) => {
        icon.addEventListener("click", async () => {
          const medId = icon.dataset.id;
          if (!medId || !confirm("Delete this medication?")) return;

          try {
            const res = await fetch(
              `http://localhost:5000/api/medications/${medId}`,
              { method: "DELETE" }
            );
            if (res.ok) {
              alert("Medication deleted!");
              await loadMedications(patientId);
            } else alert("Failed to delete medication.");
          } catch (err) {
            console.error(err);
            alert("Error deleting medication.");
          }
        });
      });
    }, 200);
  } catch (err) {
    console.error("Error loading medications:", err);
    if (medicationsContainer) {
      medicationsContainer.innerHTML = `<p style="color:red;">Failed to load medications.</p>`;
    }
  }
}

// ============================================
// LOAD PRESCRIPTION MEDICATIONS (for Prescription.html page)
// ============================================
async function loadPrescriptionMedications(patientId, appointmentId) {
  try {
    const res = await fetch(`http://localhost:5000/api/patients/${patientId}/medications`);
    if (!res.ok) {
      console.warn("Failed to fetch medications:", res.status);
      return;
    }
    
    const medications = await res.json();
    // Only show medications that are currently being added (not in history) AND match appointmentId
    const appointmentMeds = medications.filter(m => 
      m.appointmentId === appointmentId && !m.isHistory
    );
    
    const contentContainer = document.getElementById("prescriptionMedicationsContent");
    if (!contentContainer) return;
    
    if (appointmentMeds.length > 0) {
      contentContainer.innerHTML = `
        <table style="width: 100%; border-collapse: collapse; font-size: 14px; margin-top: 10px;">
          <thead>
            <tr style="background: #f5f5f5;">
              <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Medicine</th>
              <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Dosage</th>
              <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Frequency</th>
              <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Quantity</th>
              <th style="padding: 10px; border: 1px solid #ddd; text-align: left;">Notes</th>
            </tr>
          </thead>
          <tbody>
            ${appointmentMeds.map(m => `
              <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">${m.medicname || 'N/A'}</td>
                <td style="padding: 10px; border: 1px solid #ddd;">${m.dosage || 'N/A'}</td>
                <td style="padding: 10px; border: 1px solid #ddd;">${m.frequency || 'N/A'}</td>
                <td style="padding: 10px; border: 1px solid #ddd;">${m.quantity || 0}</td>
                <td style="padding: 10px; border: 1px solid #ddd;">${m.presNotes || 'N/A'}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      `;
    } else {
      contentContainer.innerHTML = '<p style="color: gray; text-align: center;">No medications added yet. Click "Add Prescription" to add medications.</p>';
    }
    
    console.log(`✅ Loaded ${appointmentMeds.length} medications for appointment ${appointmentId}`);
  } catch (err) {
    console.error("Error loading prescription medications:", err);
  }
}

// ============================================
// MAIN DOCUMENT READY - Handles both Prescription.html and Medications.html
// ============================================
document.addEventListener("DOMContentLoaded", () => {
  // ✅ Detect which page we're on
  const isPrescriptionPage = window.location.href.includes("Prescription.html");
  const isMedicationsPage = window.location.href.includes("Medications.html");
  
  const urlParams = new URLSearchParams(window.location.search);
  let appointmentId = urlParams.get("appointmentId");
  let patientId = urlParams.get("patientId");

  // ============================================
  // HANDLE PRESCRIPTION.HTML PAGE
  // ============================================
  if (isPrescriptionPage) {
    if (!appointmentId || !patientId) {
      alert("Missing appointment or patient information. Redirecting to appointments...");
      window.location.href = "Appointments.html";
      return;
    }

    // Store appointment info globally
    window.currentPrescriptionAppointment = { appointmentId, patientId };

    // Load medications list
    loadPrescriptionMedications(patientId, appointmentId);

    // Load services dropdown
    loadServicesDropdown();

    // Setup print functionality
    setupPrintFunctionality(patientId, appointmentId);
  }
  
  // ============================================
  // HANDLE MEDICATIONS.HTML PAGE
  // ============================================
  else if (isMedicationsPage) {
    // Get patientId from URL or from prescription context
    if (!patientId) {
      patientId = new URLSearchParams(window.location.search).get("patientId");
    }

    // If on prescription page, get patientId from currentPrescriptionAppointment
    if (window.currentPrescriptionAppointment) {
      patientId = window.currentPrescriptionAppointment.patientId;
    }

    if (!patientId) {
      alert("No patient selected!");
      return;
    }

    // Load Patient Header
    async function loadPatientHeader() {
      try {
        const res = await fetch(
          `http://localhost:5000/api/patients/${patientId}`
        );
        if (!res.ok) throw new Error("Patient not found");
        const p = await res.json();
        const headerH1 = document.querySelector("header h1");
        if (headerH1) {
          headerH1.textContent = `Patient Information - ${p.firstname || ""} ${
            p.lastname || ""
          }`;
        }
      } catch (err) {
        console.error("Error loading patient header:", err);
      }
    }
    loadPatientHeader();

    // Attach patient id to nav links
    document.querySelectorAll("nav-bar a").forEach((link) => {
      const href = link.getAttribute("href");
      if (href && !href.includes("?patientId=")) {
        link.setAttribute("href", `${href}?patientId=${patientId}`);
      }
    });

    // Load medications and services for Medications.html
    loadMedications(patientId);
    loadServicesDropdown();
    
    // Setup Medications.html specific functionality
    setupMedicationsPageFunctionality(patientId);
  }
  
  // ============================================
  // SHARED FUNCTIONALITY FOR PRESCRIPTION PAGE
  // ============================================
  if (isPrescriptionPage) {
    // Medication form variables
  let medCount = 0;
  const medicationsContainer = document.getElementById("medicationsContainer");
  const saveBtn = document.getElementById("saveMedicationsBtn");
  const cancelBtn = document.getElementById("cancelMedicationsBtn");
  const buttonCon = document.getElementById("buttonCon");

  // ============================================
  // SETUP MEDICATION FORM FUNCTIONS
  // ============================================
  
  // Initialize medication form on prescription page
  window.initPrescriptionMedicationForm = async function (patientId) {
    const container = document.getElementById("medicationsContainer");
    if (!container) return;

    window.currentPatientId = patientId;
    await loadServicesDropdown();

    const existingForms = container.querySelectorAll(".medecineCon");
    if (existingForms.length === 0) {
      const currentMedCount = existingForms.length + 1;
      const form = createMedicationForm(currentMedCount);
      container.appendChild(form);

      await activateMedicineSearch(
        `#medicineSelect${currentMedCount}`,
        `#freqSelect${currentMedCount}`,
        `#dosageSelect${currentMedCount}`
      );
      // ✅ FIX: Auto-fill prescriber with logged-in doctor
      await loadDoctorsDropdown(`selectPrescriber${currentMedCount}`, true);

      if (buttonCon) buttonCon.style.display = "flex";
    }
  };

  // Add medication form
  window.addMedicationForm = async function () {
    const container = document.getElementById("medicationsContainer");
    if (!container) return;

    const existingForms = container.querySelectorAll(".medecineCon");
    const currentMedCount = existingForms.length + 1;
    const form = createMedicationForm(currentMedCount);
    container.appendChild(form);

    await activateMedicineSearch(
      `#medicineSelect${currentMedCount}`,
      `#freqSelect${currentMedCount}`,
      `#dosageSelect${currentMedCount}`
    );
    // ✅ FIX: Auto-fill prescriber with logged-in doctor
    await loadDoctorsDropdown(`selectPrescriber${currentMedCount}`, true);

    if (buttonCon) buttonCon.style.display = "flex";
  };

  // Expose functions globally
  window.createMedicationForm = createMedicationForm;
  window.activateMedicineSearch = activateMedicineSearch;
  window.loadDoctorsDropdown = loadDoctorsDropdown;
  window.loadServicesDropdown = loadServicesDropdown;

  // ============================================
  // SETUP OPEN PRESCRIPTION PAGE
  // ============================================
  window.openPrescriptionPage = async function() {
    const { patientId: currentPatientId, appointmentId: currentAppointmentId } = window.currentPrescriptionAppointment;
    if (currentPatientId && currentAppointmentId) {
      sessionStorage.setItem('currentAppointmentId', currentAppointmentId);
      
      const formContainer = document.getElementById("medicationFormContainer");
      if (formContainer) {
        formContainer.style.display = "block";
        
        const medicationsContainer = document.getElementById("medicationsContainer");
        if (medicationsContainer) {
          medicationsContainer.innerHTML = "";
          
          const addMedBtnPrescription = document.createElement("button");
          addMedBtnPrescription.id = "addMedBtnPrescription";
          addMedBtnPrescription.textContent = "Add Medication";
          addMedBtnPrescription.style.cssText = "margin: 15px 0; padding: 10px 20px; background: #358F85; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: 600;";
          addMedBtnPrescription.addEventListener("click", async (e) => {
            e.preventDefault();
            if (window.addMedicationForm) {
              await window.addMedicationForm();
            }
          });
          medicationsContainer.appendChild(addMedBtnPrescription);
          
          if (window.initPrescriptionMedicationForm) {
            await window.initPrescriptionMedicationForm(currentPatientId);
          }
        }
        
        if (buttonCon) buttonCon.style.display = "flex";
        formContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
  };

  // ============================================
  // SETUP CANCEL BUTTON
  // ============================================
  if (cancelBtn) {
    cancelBtn.addEventListener("click", () => {
      const formContainer = document.getElementById("medicationFormContainer");
      if (formContainer) {
        formContainer.style.display = "none";
      }
      if (medicationsContainer) {
        medicationsContainer.innerHTML = "";
      }
      medCount = 0;
      if (buttonCon) buttonCon.style.display = "none";
    });
  }

  // ============================================
  // SETUP SAVE BUTTON - FIXED TO REFRESH LIST
  // ============================================
  if (saveBtn) {
    saveBtn.addEventListener("click", async () => {
      const allForms = [...document.querySelectorAll(".patientForm")];
      const newForms = allForms.filter(
        (form) => !form.querySelector("input")?.disabled
      );

      if (newForms.length === 0) {
        alert("No new medications to save.");
        return;
      }

      // ✅ FIX: Validate that at least one medication is actually selected
      const formsWithMedications = newForms.filter((form) => {
        const medicnameSelect = form.querySelector('select[name="medicname"]');
        const medicnameValue = medicnameSelect?.value || '';
        // Check if a medication is actually selected (not empty)
        return medicnameValue.trim() !== '';
      });

      if (formsWithMedications.length === 0) {
        alert("Please select at least one medication before saving.");
        return;
      }

      const medData = formsWithMedications.map((f) =>
        normalizeFormData(Object.fromEntries(new FormData(f)))
      );

      const tempAppointmentId = sessionStorage.getItem("currentAppointmentId") || appointmentId;
      const followupTime = document.getElementById("singleFollowUpTime")?.value || null;
      const followupDate = document.getElementById("singleFollowUp")?.value || null;

      try {
        const savedMedIds = [];
        for (const med of medData) {
          const medWithAppointment = {
            ...med,
            appointmentId: tempAppointmentId || null,
            followupTime: followupTime,
            followup: followupDate || null,
          };

          const res = await fetch(
            `http://localhost:5000/api/patients/${patientId}/medications`,
            {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(medWithAppointment),
            }
          );

          if (res.ok) {
            const result = await res.json();
            if (result.medication && result.medication.medId) {
              savedMedIds.push(result.medication.medId);
              console.log(`✅ Medication ${result.medication.medId} saved with appointmentId: ${result.medication.appointmentId || 'N/A'}`);
            }
          } else {
            const errorText = await res.text();
            console.error("Failed to save medication:", res.status, errorText);
          }
        }

        // Create follow-up appointment if needed
        const followupValue = document.getElementById("singleFollowUp")?.value;
        const followupTimeValue = document.getElementById("singleFollowUpTime")?.value || "09:00";
        const followupDuration = parseInt(document.getElementById("singleFollowUpDuration")?.value || "30");
        const serviceValue = document.getElementById("singleService")?.value;

        // ✅ FIX: Create follow-up appointment if date and service are provided (even without medications)
        if (followupValue && serviceValue) {
          let doctorId = "";
          let doctorName = "";

          if (window.currentPrescriptionAppointment?.appointmentId) {
            try {
              const appointmentRes = await fetch(
                `http://localhost:5000/api/appointments/${window.currentPrescriptionAppointment.appointmentId}`
              );
              if (appointmentRes.ok) {
                const appointment = await appointmentRes.json();
                doctorId = appointment.doctorId || "";
                doctorName = appointment.doctorName || "";
              }
            } catch (err) {
              console.warn("Could not fetch current appointment:", err);
            }
          }

          if (!doctorId || !doctorName) {
            // ✅ FIX: Use formsWithMedications instead of newForms to ensure we have a valid form
            const prescriberSelect = formsWithMedications.length > 0 
              ? formsWithMedications[0].querySelector('select[name="presby"]')
              : null;
            doctorName = prescriberSelect?.value || "N/A";

            // ✅ CRITICAL FIX: Try to get doctor from logged-in user first
            const loggedInRole = sessionStorage.getItem("role");
            const loggedInUserId = sessionStorage.getItem("userId");
            const loggedInName = sessionStorage.getItem("name");
            
            if (loggedInRole === "Doctor" && loggedInUserId && loggedInName) {
              console.log("✅ Using logged-in doctor for follow-up appointment:", loggedInName);
              doctorId = loggedInUserId;
              doctorName = `Dr. ${loggedInName}`;
            } else {
              // Fallback: Try to find doctor from prescriber select
              try {
                const usersRes = await fetch("http://localhost:5000/api/users");
                if (usersRes.ok) {
                  const users = await usersRes.json();
                  const doctor = users.find((u) => `Dr. ${u.name}` === doctorName);
                  if (doctor) {
                    doctorId = doctor.userId;
                    doctorName = `Dr. ${doctor.name}`;
                    console.log("✅ Found doctor from prescriber select:", doctorName);
                  } else {
                    console.warn("⚠️ Could not find doctor with name:", doctorName);
                  }
                }
              } catch (err) {
                console.warn("Could not fetch doctor ID:", err);
              }
            }
          }

          let patientName = "Unknown";
          try {
            const patientRes = await fetch(`http://localhost:5000/api/patients/${patientId}`);
            if (patientRes.ok) {
              const patient = await patientRes.json();
              patientName = `${patient.firstname || ""} ${patient.lastname || ""}`.trim();
            }
          } catch (err) {
            console.warn("Could not fetch patient name:", err);
          }

          // ✅ CRITICAL FIX: Validate all required fields before creating appointment
          if (!patientId) {
            console.error("❌ Cannot create follow-up: patientId is missing");
            alert("⚠️ Medications saved, but cannot create follow-up appointment: Patient ID is missing.");
            return;
          }

          if (!doctorId || doctorId === "Unknown" || doctorId === "") {
            console.error("❌ Cannot create follow-up: doctorId is invalid", { doctorId, doctorName });
            alert(`⚠️ Medications saved, but cannot create follow-up appointment: Doctor information is missing or invalid.\n\nDoctor ID: ${doctorId || 'N/A'}\nDoctor Name: ${doctorName || 'N/A'}\n\nPlease ensure you are logged in as a doctor or select a prescriber.`);
            return;
          }

          if (!followupValue) {
            console.error("❌ Cannot create follow-up: date is missing");
            alert("⚠️ Medications saved, but cannot create follow-up appointment: Follow-up date is required.");
            return;
          }

          if (!serviceValue) {
            console.error("❌ Cannot create follow-up: service is missing");
            alert("⚠️ Medications saved, but cannot create follow-up appointment: Service/Type is required.");
            return;
          }

          console.log("📋 Creating follow-up appointment with data:", {
            patientId,
            patientName,
            doctorId,
            doctorName,
            date: followupValue,
            time: followupTimeValue,
            duration: followupDuration,
            type: serviceValue
          });

          const appointmentData = {
            patientId,
            patientName: patientName || "Unknown",
            doctorId,
            doctorName,
            date: followupValue,
            time: followupTimeValue,
            duration: followupDuration,
            type: serviceValue,
            service: serviceValue,
            reason: "Follow-up from medication module",
            notes: "Auto-generated from prescription",
            status: "Upcoming",
          };

          try {
            const appRes = await fetch("http://localhost:5000/api/appointments", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(appointmentData),
            });

            const responseText = await appRes.text();
            console.log("📥 Appointment API response status:", appRes.status);
            console.log("📥 Appointment API response body:", responseText);

            if (appRes.ok) {
              try {
                const response = JSON.parse(responseText);
                console.log("✅ Follow-up appointment API response:", response);
                
                // ✅ FIX: API returns { message: "...", appointment: {...} }
                const createdAppointment = response.appointment || response;
                const appointmentId = createdAppointment?.appointmentId || createdAppointment?.id || '';
                
                console.log("✅ Follow-up appointment created with ID:", appointmentId);
                
                if (appointmentId) {
                  // ✅ FIX: Use localStorage with storage event for cross-tab communication
                  const followUpData = {
                    created: true,
                    appointmentId: appointmentId,
                    timestamp: Date.now()
                  };
                  localStorage.setItem('followUpAppointmentCreated', JSON.stringify(followUpData));
                  // Also set in sessionStorage for same-tab navigation
                  sessionStorage.setItem('followUpAppointmentCreated', 'true');
                  sessionStorage.setItem('followUpAppointmentId', appointmentId);
                  
                  // ✅ FIX: Show success message
                  alert(`✅ Medications saved and follow-up appointment created successfully!\n\nAppointment ID: ${appointmentId}\nDate: ${followupValue}\nTime: ${followupTimeValue}\n\nPlease check the Appointments page to see the new appointment.`);
                  
                  // Trigger storage event manually for same-tab
                  window.dispatchEvent(new StorageEvent('storage', {
                    key: 'followUpAppointmentCreated',
                    newValue: JSON.stringify(followUpData)
                  }));
                } else {
                  console.error("⚠️ Follow-up appointment created but no appointmentId found in response");
                  alert("✅ Medications saved and follow-up appointment created, but could not retrieve appointment ID. Please check the Appointments page.");
                }
              } catch (parseError) {
                console.error("❌ Error parsing appointment response:", parseError);
                alert("✅ Medications saved. Follow-up appointment may have been created, but there was an error reading the response. Please check the Appointments page.");
              }
            } else {
              // ✅ CRITICAL FIX: Show actual error message from server
              let errorMessage = "Unknown error";
              try {
                const errorData = JSON.parse(responseText);
                errorMessage = errorData.message || JSON.stringify(errorData);
              } catch (e) {
                errorMessage = responseText || `HTTP ${appRes.status}`;
              }
              
              console.error("❌ Failed to create follow-up appointment:", {
                status: appRes.status,
                statusText: appRes.statusText,
                error: errorMessage
              });
              
              alert(`⚠️ Medications saved, but failed to create follow-up appointment.\n\nError: ${errorMessage}\n\nPlease create the follow-up appointment manually from the Appointments page.`);
            }
          } catch (fetchError) {
            console.error("❌ Network error creating follow-up appointment:", fetchError);
            alert(`⚠️ Medications saved, but failed to create follow-up appointment due to network error.\n\nError: ${fetchError.message}\n\nPlease check your connection and try creating the appointment manually.`);
          }
        }

        // ✅ CRITICAL FIX: Refresh medication list immediately after saving
        await new Promise((resolve) => setTimeout(resolve, 300)); // Small delay to ensure DB is updated
        await loadPrescriptionMedications(patientId, appointmentId);

        // Hide form container
        const formContainer = document.getElementById("medicationFormContainer");
        if (formContainer) {
          formContainer.style.display = "none";
        }

        // Clear form
        if (medicationsContainer) {
          medicationsContainer.innerHTML = "";
        }
        medCount = 0;

        // Clear follow-up fields
        const followUpDate = document.getElementById("singleFollowUp");
        const followUpTime = document.getElementById("singleFollowUpTime");
        const followUpDuration = document.getElementById("singleFollowUpDuration");
        const followUpService = document.getElementById("singleService");

        if (followUpDate) followUpDate.value = "";
        if (followUpTime) followUpTime.value = "";
        if (followUpDuration) followUpDuration.value = "30";
        if (window.jQuery && followUpService && $(followUpService).length) {
          $(followUpService).val(null).trigger("change");
        }

        if (buttonCon) buttonCon.style.display = "none";

        alert("✅ Medications saved successfully! They will appear in the prescribed medications list above.");
      } catch (err) {
        console.error("Error saving medications:", err);
        alert("Error saving medications: " + err.message);
      }
    });
  }

  // ============================================
  // SETUP COMPLETE APPOINTMENT
  // ============================================
  window.completeAppointment = async function() {
    const notesInput = document.getElementById("prescriptionNotes");
    const prescriptionNotes = notesInput ? notesInput.value.trim() : "";

    try {
      const { patientId: currentPatientId } = window.currentPrescriptionAppointment;
      
      // Move medications to history BEFORE completing appointment
      if (currentPatientId) {
        try {
          const medsRes = await fetch(`http://localhost:5000/api/patients/${currentPatientId}/medications`);
          if (medsRes.ok) {
            const allMeds = await medsRes.json();
            const appointmentMeds = allMeds.filter(m => m.appointmentId === appointmentId && !m.isHistory);
            const medIds = appointmentMeds.map(m => m.medId);
            
            if (medIds.length > 0) {
              await fetch(
                `http://localhost:5000/api/patients/${currentPatientId}/medications/move-to-history`,
                {
                  method: "PUT",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ medicationIds: medIds }),
                }
              );
            }
          }
        } catch (err) {
          console.warn("Could not move medications to history:", err);
        }
      }

      // ✅ NEW: Create follow-up appointment if fields are filled (even without medications)
    const followupValue = document.getElementById("singleFollowUp")?.value;
    const followupTimeValue = document.getElementById("singleFollowUpTime")?.value || "09:00";
    const followupDuration = parseInt(document.getElementById("singleFollowUpDuration")?.value || "30");
    const serviceValue = document.getElementById("singleService")?.value;

    if (followupValue && serviceValue) {
      console.log("📋 Creating follow-up appointment from Done button...");
      
      let doctorId = "";
      let doctorName = "";

      // Get doctor info from current appointment
      if (window.currentPrescriptionAppointment?.appointmentId) {
        try {
          const appointmentRes = await fetch(
            `http://localhost:5000/api/appointments/${window.currentPrescriptionAppointment.appointmentId}`
          );
          if (appointmentRes.ok) {
            const appointment = await appointmentRes.json();
            doctorId = appointment.doctorId || "";
            doctorName = appointment.doctorName || "";
          }
        } catch (err) {
          console.warn("Could not fetch current appointment:", err);
        }
      }

      // Fallback: Use logged-in doctor
      if (!doctorId || !doctorName) {
        const loggedInRole = sessionStorage.getItem("role");
        const loggedInUserId = sessionStorage.getItem("userId");
        const loggedInName = sessionStorage.getItem("name");
        
        if (loggedInRole === "Doctor" && loggedInUserId && loggedInName) {
          doctorId = loggedInUserId;
          doctorName = `Dr. ${loggedInName}`;
        }
      }

      // Get patient name
      let patientName = "Unknown";
      try {
        const patientRes = await fetch(`http://localhost:5000/api/patients/${currentPatientId}`);
        if (patientRes.ok) {
          const patient = await patientRes.json();
          patientName = `${patient.firstname || ""} ${patient.lastname || ""}`.trim();
        }
      } catch (err) {
        console.warn("Could not fetch patient name:", err);
      }

      // Validate required fields
      if (!currentPatientId || !doctorId || !followupValue || !serviceValue) {
        console.error("❌ Cannot create follow-up: Missing required fields", {
          patientId: currentPatientId,
          doctorId,
          date: followupValue,
          service: serviceValue
        });
        alert("⚠️ Cannot create follow-up appointment: Missing required information.");
      } else {
        const appointmentData = {
          patientId: currentPatientId,
          patientName: patientName || "Unknown",
          doctorId,
          doctorName,
          date: followupValue,
          time: followupTimeValue,
          duration: followupDuration,
          type: serviceValue,
          service: serviceValue,
          reason: "Follow-up from completed appointment",
          notes: "Auto-generated from prescription completion",
          status: "Upcoming",
        };

        try {
          const appRes = await fetch("http://localhost:5000/api/appointments", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(appointmentData),
          });

          const responseText = await appRes.text();

          if (appRes.ok) {
            try {
              const response = JSON.parse(responseText);
              const createdAppointment = response.appointment || response;
              const appointmentId = createdAppointment?.appointmentId || createdAppointment?.id || '';
              
              if (appointmentId) {
                const followUpData = {
                  created: true,
                  appointmentId: appointmentId,
                  timestamp: Date.now()
                };
                localStorage.setItem('followUpAppointmentCreated', JSON.stringify(followUpData));
                sessionStorage.setItem('followUpAppointmentCreated', 'true');
                sessionStorage.setItem('followUpAppointmentId', appointmentId);
                
                console.log(`✅ Follow-up appointment created: ${appointmentId}`);
                
                window.dispatchEvent(new StorageEvent('storage', {
                  key: 'followUpAppointmentCreated',
                  newValue: JSON.stringify(followUpData)
                }));
              }
            } catch (parseError) {
              console.error("❌ Error parsing appointment response:", parseError);
            }
          } else {
            console.error("❌ Failed to create follow-up appointment:", responseText);
          }
        } catch (fetchError) {
          console.error("❌ Network error creating follow-up appointment:", fetchError);
        }
      }
    }

      const completingFromMonitor = sessionStorage.getItem('completingFromMonitor') === appointmentId;
      
      const updateResponse = await fetch(`http://localhost:5000/api/appointments/${appointmentId}/status`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "Completed" })
      });

      if (!updateResponse.ok) {
        throw new Error("Failed to update appointment status");
      }

      if (prescriptionNotes) {
        try {
          const appointmentRes = await fetch(`http://localhost:5000/api/appointments/${appointmentId}`);
          if (appointmentRes.ok) {
            const appointment = await appointmentRes.json();
            const updatedNotes = appointment.notes 
              ? `${appointment.notes}\n\nPrescription Notes: ${prescriptionNotes}`
              : `Prescription Notes: ${prescriptionNotes}`;
            
            const appointmentDate = appointment.date instanceof Date 
              ? appointment.date.toISOString() 
              : appointment.date;
            
            await fetch(`http://localhost:5000/api/appointments/${appointmentId}`, {
              method: "PUT",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                patientName: appointment.patientName,
                doctorId: appointment.doctorId,
                doctorName: appointment.doctorName,
                date: appointmentDate,
                time: appointment.time,
                type: appointment.type,
                duration: appointment.duration,
                reason: appointment.reason,
                notes: updatedNotes
              })
            });
          }
        } catch (err) {
          console.warn("Could not update appointment notes:", err);
        }
      }

      if (completingFromMonitor && window.shownModals) {
        window.shownModals.delete(appointmentId);
        sessionStorage.removeItem('completingFromMonitor');
      }

      const archiveResponse = await fetch(`http://localhost:5000/api/appointments/${appointmentId}/archive`, {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });

      const result = await archiveResponse.json();

      if (!archiveResponse.ok) {
        throw new Error(result.message || "Failed to archive appointment");
      }

      alert("✅ Appointment completed and archived successfully!");
      window.location.href = "Appointments.html";

    } catch (error) {
      console.error("Error completing appointment:", error);
      alert("❌ " + (error.message || "There was a problem completing the appointment."));
    }
  };
  } // End of isPrescriptionPage block
});

// ============================================
// SETUP MEDICATIONS.HTML PAGE FUNCTIONALITY
// ============================================
function setupMedicationsPageFunctionality(patientId) {
  const medicationsContainer = document.getElementById("medicationsContainer");
  const addBtn = document.getElementById("addMedBtn");
  const saveBtn = document.querySelector(".savebtn");
  const cancelBtn = document.querySelector(".cancelbtn");
  const buttonCon = document.getElementById("buttonCon");
  let medCount = 0;

  // Hide button container initially
  if (buttonCon) {
    buttonCon.style.display = "none";
  }

  // ------------------------------
  // Add / Edit Medication
  // ------------------------------
  if (addBtn) {
    addBtn.addEventListener("click", async (e) => {
      e.preventDefault();
      medCount++;
      const newForm = createMedicationForm(medCount);
      medicationsContainer.appendChild(newForm);
      await loadDoctorsDropdown(`selectPrescriber${medCount}`);
      activateMedicineSearch(
        `#medicineSelect${medCount}`,
        `#freqSelect${medCount}`,
        `#dosageSelect${medCount}`
      );
      if (buttonCon) buttonCon.style.display = "flex";
      addBtn.textContent = "Cancel Add";

      newForm.querySelector(".deleteMed").addEventListener("click", () => {
        newForm.remove();
        if (buttonCon) buttonCon.style.display = "none";
        addBtn.textContent = "Add Medication";
      });

      if (cancelBtn) {
        cancelBtn.addEventListener(
          "click",
          () => {
            newForm.remove();
            if (buttonCon) buttonCon.style.display = "none";
            addBtn.textContent = "Add Medication";
          },
          { once: true }
        );
      }
    });
  }

  // ------------------------------
  // Save Medications & Create Appointment (for Medications.html)
  // ------------------------------
  if (saveBtn) {
    saveBtn.addEventListener("click", async () => {
      // ✅ FIX: Only get forms that are NEW (not disabled)
      const allForms = [...document.querySelectorAll(".patientForm")];
      const newForms = allForms.filter(
        (form) => !form.querySelector("input")?.disabled
      );

      if (newForms.length === 0) {
        alert("No new medications to save.");
        return;
      }

      const medData = newForms.map((f) =>
        normalizeFormData(Object.fromEntries(new FormData(f)))
      );

      const followupTime =
        document.getElementById("singleFollowUpTime")?.value || null;
      const followupDate =
        document.getElementById("singleFollowUp")?.value || null;

      try {
        const savedMedIds = [];
        for (const med of medData) {
          const medWithAppointment = {
            ...med,
            appointmentId: null, // Medications.html doesn't have appointmentId
            followupTime: followupTime,
            followup: followupDate || null,
          };

          const res = await fetch(
            `http://localhost:5000/api/patients/${patientId}/medications`,
            {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(medWithAppointment),
            }
          );

          if (res.ok) {
            const result = await res.json();
            if (result.medication && result.medication.medId) {
              savedMedIds.push(result.medication.medId);
            }
          } else {
            const errorText = await res.text();
            console.error("Failed to save medication:", res.status, errorText);
          }
        }

        // Auto create single follow-up appointment if needed
        const followupValue = document.getElementById("singleFollowUp")?.value;
        const followupTimeValue =
          document.getElementById("singleFollowUpTime")?.value || "09:00";
        const followupDuration = parseInt(
          document.getElementById("singleFollowUpDuration")?.value || "30"
        );
        const serviceValue = document.getElementById("singleService")?.value;

        if (followupValue && serviceValue && newForms.length > 0) {
          // Get doctor info from prescriber select
          let doctorId = "";
          let doctorName = "";
          const prescriberSelect = newForms[0].querySelector(
            'select[name="presby"]'
          );
          doctorName = prescriberSelect?.value || "N/A";

          try {
            const usersRes = await fetch("http://localhost:5000/api/users");
            if (usersRes.ok) {
              const users = await usersRes.json();
              const doctor = users.find((u) => `Dr. ${u.name}` === doctorName);
              if (doctor) {
                doctorId = doctor.userId;
                doctorName = `Dr. ${doctor.name}`;
              }
            }
          } catch (err) {
            console.warn("Could not fetch doctor ID:", err);
          }

          // Get patient name
          let patientName = "Unknown";
          try {
            const patientRes = await fetch(
              `http://localhost:5000/api/patients/${patientId}`
            );
            if (patientRes.ok) {
              const patient = await patientRes.json();
              patientName = `${patient.firstname || ""} ${
                patient.lastname || ""
              }`.trim();
            }
          } catch (err) {
            console.warn("Could not fetch patient name:", err);
          }

          // Only create appointment if we have a valid doctorId
          if (doctorId && doctorId !== "Unknown") {
            const appointmentData = {
              patientId,
              patientName,
              doctorId,
              doctorName,
              date: followupValue,
              time: followupTimeValue,
              duration: followupDuration,
              type: serviceValue,
              reason: "Follow-up from medication module",
              notes: "Auto-generated from prescription",
              status: "Upcoming",
            };

            const appRes = await fetch("http://localhost:5000/api/appointments", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify(appointmentData),
            });

            if (appRes.ok) {
              alert("✅ Medications saved and follow-up appointment created!");
            } else {
              const errorData = await appRes.json().catch(() => ({}));
              console.error("Failed to create follow-up appointment:", errorData);
              alert("✅ Medications saved, but failed to create follow-up appointment: " + (errorData.message || "Unknown error"));
            }
          } else {
            console.warn("Cannot create follow-up appointment: Invalid doctor ID");
            alert("✅ Medications saved, but could not create follow-up appointment (doctor not found).");
          }
        } else {
          alert("✅ Medications saved successfully!");
        }

        // Move saved medications to prescription history
        if (savedMedIds.length > 0) {
          try {
            await fetch(
              `http://localhost:5000/api/patients/${patientId}/medications/move-to-history`,
              {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ medicationIds: savedMedIds }),
              }
            );
          } catch (err) {
            console.warn("Could not move medications to history:", err);
          }
        }

        await loadMedications(patientId);
        if (buttonCon) buttonCon.style.display = "none";
        if (addBtn) {
          addBtn.style.display = "inline-block";
          addBtn.textContent = "Add Medication";
        }

        // Clear the follow-up fields after save
        const followUpDate = document.getElementById("singleFollowUp");
        const followUpTime = document.getElementById("singleFollowUpTime");
        const followUpService = document.getElementById("singleService");
        if (followUpDate) followUpDate.value = "";
        if (followUpTime) followUpTime.value = "";
        if (window.jQuery && followUpService && $(followUpService).length) {
          $(followUpService).val(null).trigger("change");
        }
      } catch (err) {
        console.error("Error saving medications:", err);
        alert("Error saving medications.");
      }
    });
  }

  // ------------------------------
  // Print / Preview Prescriptions + Follow-up (for Medications.html)
  // ------------------------------
  const printBtn = document.getElementById("printBtn");
  const modal = document.getElementById("printModal");
  const confirmBtn = document.getElementById("confirmPrint");
  const cancelPrint = document.getElementById("cancelPrint");
  const prescriptionList = document.getElementById("prescriptionList");

  if (printBtn) {
    printBtn.addEventListener("click", async (e) => {
      e.preventDefault();
      try {
        const medsRes = await fetch(
          `http://localhost:5000/api/patients/${patientId}/medications`
        );
        const meds = await medsRes.json();

        const followupDate =
          document.getElementById("singleFollowUp")?.value || "N/A";
        const followupService =
          document.getElementById("singleService")?.value || "N/A";

        let medsTableHTML = "";
        if (meds.length === 0) {
          medsTableHTML = `<p>No medications prescribed yet.</p>`;
        } else {
          medsTableHTML = `
          <table class="prescription-table">
            <thead>
              <tr>
                <th>Medicine Name</th>
                  <th>Dosage</th>
                  <th>Frequency</th>
                  <th>Quantity</th>
                  <th>Prescription Notes</th>
              </tr>
            </thead>
            <tbody>
              ${meds
                .map(
                  (m) => `
                <tr>
                    <td>${escapeHtml(m.medicname || '')}</td>
                    <td>${escapeHtml(m.dosage || 'N/A')}</td>
                    <td>${escapeHtml(m.frequency || '')}</td>
                    <td>${m.quantity ?? ""}</td>
                    <td>${escapeHtml(m.presNotes || '')}</td>
                </tr>
              `
                )
                .join("")}
            </tbody>
          </table>
        `;
        }

        // Build full modal HTML including follow-up info
        prescriptionList.innerHTML = `
        <div class="followup-info" style="margin-bottom:20px;">
          <p><strong>Follow-up Appointment:</strong></p>
          <p>Date: ${followupDate}</p>
          <p>Service / Type: ${followupService}</p>
        </div>
        ${medsTableHTML}
      `;

        if (modal) modal.style.display = "flex";
      } catch (err) {
        console.error("Error loading medications for print:", err);
        if (prescriptionList) {
          prescriptionList.innerHTML = `<p style="color:red;">Failed to load medications.</p>`;
        }
        if (modal) modal.style.display = "flex";
      }
    });
  }

  if (cancelPrint) {
    cancelPrint.addEventListener("click", () => {
      if (modal) modal.style.display = "none";
    });
  }

  if (confirmBtn) {
    confirmBtn.addEventListener("click", async () => {
      try {
        // Fetch medications for this appointment
        const medsRes = await fetch(`http://localhost:5000/api/patients/${patientId}/medications`);
        const meds = await medsRes.json();
        const appointmentMeds = meds.filter(m => m.appointmentId === appointmentId && !m.isHistory);

        // Get prescriber name from medications or fallback to logged-in doctor
        let prescriberName = "";
        
        if (appointmentMeds.length > 0 && appointmentMeds[0].presby) {
          prescriberName = appointmentMeds[0].presby;
          console.log("✅ Prescriber from medications:", prescriberName);
        } else {
          // Fallback 1: Try to get from appointment details
          try {
            const appointmentRes = await fetch(`http://localhost:5000/api/appointments/${appointmentId}`);
            if (appointmentRes.ok) {
              const appointment = await appointmentRes.json();
              prescriberName = appointment.doctorName || "";
              console.log("✅ Prescriber from appointment:", prescriberName);
            }
          } catch (err) {
            console.warn("Could not fetch appointment details:", err);
          }
          
          // Fallback 2: Use logged-in doctor
          if (!prescriberName) {
            const loggedInName = sessionStorage.getItem("name");
            const loggedInRole = sessionStorage.getItem("role");
            if (loggedInRole === "Doctor" && loggedInName) {
              prescriberName = `Dr. ${loggedInName}`;
              console.log("✅ Prescriber from logged-in user:", prescriberName);
            } else {
              prescriberName = "___________________________";
              console.warn("⚠️ No prescriber found, using blank line");
            }
          }
        }

        // Build medications table HTML
        let medsTableHTML = "";
        if (appointmentMeds.length === 0) {
          medsTableHTML = `<p>No medications prescribed yet.</p>`;
        } else {
          medsTableHTML = `
            <table class="prescription-table">
              <thead>
                <tr>
                  <th>Medicine Name</th>
                  <th>Dosage</th>
                  <th>Frequency</th>
                  <th>Quantity</th>
                  <th>Prescription Notes</th>
                </tr>
              </thead>
              <tbody>
                ${appointmentMeds.map(m => `
                  <tr>
                    <td>${escapeHtml(m.medicname || '')}</td>
                    <td>${escapeHtml(m.dosage || 'N/A')}</td>
                    <td>${escapeHtml(m.frequency || '')}</td>
                    <td>${m.quantity ?? ""}</td>
                    <td>${escapeHtml(m.presNotes || '')}</td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          `;
        }

        const printWindow = window.open("", "", "width=900,height=700");
        printWindow.document.write(`
          <!DOCTYPE html>
          <html>
          <head>
            <title>Prescription</title>
            <style>
              body { 
                font-family: Arial, sans-serif; 
                padding: 20px;
                display: flex;
                flex-direction: column;
                min-height: 90vh;
              }
              .header-section {
                text-align: center;
                margin-bottom: 30px;
              }
              .clinic-name {
                font-size: 24px;
                font-weight: bold;
                margin-bottom: 5px;
              }
              .clinic-address, .clinic-contact {
                font-size: 12px;
                margin: 5px 0;
              }
              .rxtxt {
                font-size: 48px;
                font-weight: bold;
                text-align: left;
                margin: 20px 0;
              }
              .content-section {
                flex-grow: 1;
              }
              .prescription-table { 
                width: 100%; 
                border-collapse: collapse; 
                margin-top: 10px; 
              }
              .prescription-table th, .prescription-table td { 
                border: 1px solid #ddd; 
                padding: 8px; 
                text-align: left; 
              }
              .prescription-table th { 
                background-color: #f2f2f2; 
              }
              .prescriber-section {
                margin-top: 50px;
                padding-top: 20px;
                border-top: 2px solid #000;
                text-align: center;
              }
              .prescriber-name {
                font-size: 16px;
                font-weight: bold;
                margin: 10px 0;
              }
              .signature-line {
                margin-top: 40px;
                border-top: 1px solid #000;
                width: 300px;
                margin-left: auto;
                margin-right: auto;
                padding-top: 5px;
              }
            </style>
          </head>
          <body>
            <div class="header-section">
              <h2 class="clinic-name">MediSys Hospital</h2>
              <p class="clinic-address">123 Health Street, Brgy. San Bartolome, Novaliches QC</p>
              <p class="clinic-contact">Tel: (02) 123-4567 | Email: erm@medisys.com.ph</p>
            </div>
            <div class="content-section">
              <h1 class="rxtxt">Rx</h1>
              ${medsTableHTML}
            </div>
            <div class="prescriber-section">
              <div class="signature-line">
                <p class="prescriber-name">${prescriberName}</p>
                <p style="font-size: 12px; color: #666;">Signature over Printed Name</p>
              </div>
            </div>
          </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
      } catch (err) {
        console.error("Error preparing print:", err);
        alert("Failed to prepare prescription for printing.");
      }
    });
  }

  if (modal) {
    window.addEventListener("click", (event) => {
      if (event.target === modal) modal.style.display = "none";
    });
  }
}

// ============================================
// SETUP PRINT FUNCTIONALITY
// ============================================
function setupPrintFunctionality(patientId, appointmentId) {
  const printBtn = document.getElementById("printPrescriptionBtn");
  const modal = document.getElementById("printModal");
  const confirmBtn = document.getElementById("confirmPrint");
  const cancelPrint = document.getElementById("cancelPrint");
  const prescriptionList = document.getElementById("prescriptionList");

  if (printBtn) {
    printBtn.addEventListener("click", async (e) => {
      e.preventDefault();
      try {
        const medsRes = await fetch(`http://localhost:5000/api/patients/${patientId}/medications`);
        const meds = await medsRes.json();
        const appointmentMeds = meds.filter(m => m.appointmentId === appointmentId && !m.isHistory);

        let medsTableHTML = "";
        if (appointmentMeds.length === 0) {
          medsTableHTML = `<p>No medications prescribed yet.</p>`;
        } else {
          medsTableHTML = `
            <table class="prescription-table">
              <thead>
                <tr>
                  <th>Medicine Name</th>
                  <th>Dosage</th>
                  <th>Frequency</th>
                  <th>Quantity</th>
                  <th>Prescription Notes</th>
                </tr>
              </thead>
              <tbody>
                ${appointmentMeds.map(m => `
                  <tr>






                    <td>${escapeHtml(m.medicname || '')}</td>
                    <td>${escapeHtml(m.dosage || 'N/A')}</td>
                    <td>${escapeHtml(m.frequency || '')}</td>
                    <td>${m.quantity ?? ""}</td>
                    <td>${escapeHtml(m.presNotes || '')}</td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          `;
        }

        let prescriberName = "___________________________";
        if (appointmentMeds.length > 0 && appointmentMeds[0].presby) {
          prescriberName = appointmentMeds[0].presby;
        }

        prescriptionList.innerHTML = medsTableHTML;
        modal.style.display = "flex";
      } catch (err) {
        console.error("Error loading medications for print:", err);
        prescriptionList.innerHTML = `<p style="color:red;">Failed to load medications.</p>`;
        modal.style.display = "flex";
      }
    });
  }

  if (cancelPrint) {
    cancelPrint.addEventListener("click", () => {
      if (modal) modal.style.display = "none";
    });
  }

  if (confirmBtn) {
    confirmBtn.addEventListener("click", async () => {
      try {
        console.log("🖨️ Print button clicked");
        console.log("📋 Patient ID:", patientId);
        console.log("📋 Appointment ID:", appointmentId);
        
        // Fetch medications for this appointment
        const medsRes = await fetch(`http://localhost:5000/api/patients/${patientId}/medications`);
        const meds = await medsRes.json();
        console.log("📦 All medications fetched:", meds);
        
        const appointmentMeds = meds.filter(m => m.appointmentId === appointmentId && !m.isHistory);
        console.log("📦 Filtered appointment medications:", appointmentMeds);

        // Get prescriber name with multiple fallbacks
        let prescriberName = "";
        
        // Priority 1: Get from medications
        if (appointmentMeds.length > 0 && appointmentMeds[0].presby) {
          prescriberName = appointmentMeds[0].presby;
          console.log("✅ Prescriber from medications:", prescriberName);
        } 
        
        // Priority 2: Get from appointment
        if (!prescriberName) {
          try {
            const appointmentRes = await fetch(`http://localhost:5000/api/appointments/${appointmentId}`);
            if (appointmentRes.ok) {
              const appointment = await appointmentRes.json();
              prescriberName = appointment.doctorName || "";
              console.log("✅ Prescriber from appointment:", prescriberName);
            }
          } catch (err) {
            console.warn("Could not fetch appointment details:", err);
          }
        }
        
        // Priority 3: Get from logged-in user
        if (!prescriberName) {
          const loggedInName = sessionStorage.getItem("name");
          const loggedInRole = sessionStorage.getItem("role");
          if (loggedInRole === "Doctor" && loggedInName) {
            prescriberName = `Dr. ${loggedInName}`;
            console.log("✅ Prescriber from logged-in user:", prescriberName);
          } else {
            prescriberName = "___________________________";
            console.warn("⚠️ No prescriber found, using blank line");
          }
        }

        console.log("📝 Final prescriber name:", prescriberName);

        // Build medications table HTML
        let medsTableHTML = "";
        if (appointmentMeds.length === 0) {
          medsTableHTML = `<p>No medications prescribed yet.</p>`;
        } else {
          medsTableHTML = `
            <table class="prescription-table">
              <thead>
                <tr>
                  <th>Medicine Name</th>
                  <th>Dosage</th>
                  <th>Frequency</th>
                  <th>Quantity</th>
                  <th>Prescription Notes</th>
                </tr>
              </thead>
              <tbody>
                ${appointmentMeds.map(m => {
                  console.log("💊 Medication:", m.medicname, "Prescribed by:", m.presby);
                  return `
                    <tr>
                      <td>${escapeHtml(m.medicname || '')}</td>
                      <td>${escapeHtml(m.dosage || 'N/A')}</td>
                      <td>${escapeHtml(m.frequency || '')}</td>
                      <td>${m.quantity ?? ""}</td>
                      <td>${escapeHtml(m.presNotes || '')}</td>
                    </tr>
                  `;
                }).join("")}
              </tbody>
            </table>
          `;
        }

        const printWindow = window.open("", "", "width=900,height=700");
        printWindow.document.write(`
          <!DOCTYPE html>
          <html>
          <head>
            <title>Prescription</title>
            <style>
              body { 
                font-family: Arial, sans-serif; 
                padding: 20px;
                display: flex;
                flex-direction: column;
                min-height: 90vh;
              }
              .header-section {
                text-align: center;
                margin-bottom: 30px;
              }
              .clinic-name {
                font-size: 24px;
                font-weight: bold;
                margin-bottom: 5px;
              }
              .clinic-address, .clinic-contact {
                font-size: 12px;
                margin: 5px 0;
              }
              .rxtxt {
                font-size: 48px;
                font-weight: bold;
                text-align: left;
                margin: 20px 0;
              }
              .content-section {
                flex-grow: 1;
              }
              .prescription-table { 
                width: 100%; 
                border-collapse: collapse; 
                margin-top: 10px; 
              }
              .prescription-table th, .prescription-table td { 
                border: 1px solid #ddd; 
                padding: 8px; 
                text-align: left; 
              }
              .prescription-table th { 
                background-color: #f2f2f2; 
              }
              .prescriber-section {
                margin-top: 50px;
                padding-top: 20px;
                border-top: 2px solid #000;
                text-align: center;
              }
              .prescriber-name {
                font-size: 16px;
                font-weight: bold;
                margin: 10px 0;
              }
              .signature-line {
                margin-top: 40px;
                border-top: 1px solid #000;
                width: 300px;
                margin-left: auto;
                margin-right: auto;
                padding-top: 5px;
              }
            </style>
          </head>
          <body>
            <div class="header-section">
              <h2 class="clinic-name">MediSys Hospital</h2>
              <p class="clinic-address">123 Health Street, Brgy. San Bartolome, Novaliches QC</p>
              <p class="clinic-contact">Tel: (02) 123-4567 | Email: erm@medisys.com.ph</p>
            </div>
            <div class="content-section">
              <h1 class="rxtxt">Rx</h1>
              ${medsTableHTML}
            </div>
            <div class="prescriber-section">
              <div class="signature-line">
                <p class="prescriber-name">Prescribed By: ${prescriberName}</p>
                <p style="font-size: 12px; color: #666;">Signature over Printed Name</p>
              </div>
            </div>
          </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.focus();
        printWindow.print();
      } catch (err) {
        console.error("Error preparing print:", err);
        alert("Failed to prepare prescription for printing.");
      }
    });
  }

  window.addEventListener("click", (event) => {
    if (event.target === modal) modal.style.display = "none";
  });
}

// Refresh medications periodically
setInterval(() => {
  if (window.currentPrescriptionAppointment) {
    const { patientId, appointmentId } = window.currentPrescriptionAppointment;
    loadPrescriptionMedications(patientId, appointmentId);
  }
}, 3000); 
