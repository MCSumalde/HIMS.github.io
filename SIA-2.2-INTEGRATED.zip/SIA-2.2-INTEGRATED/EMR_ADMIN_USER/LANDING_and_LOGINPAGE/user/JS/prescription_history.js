// prescription_history.js - Load prescription history

document.addEventListener("DOMContentLoaded", () => {
  const patientId = new URLSearchParams(window.location.search).get("patientId");
  const historyContainer = document.getElementById("prescriptionHistoryContainer");

  if (!patientId) {
    historyContainer.innerHTML = `<p style="color:red;">No patient selected!</p>`;
    return;
  }

  // Attach patient id to nav links
  document.querySelectorAll("nav-bar a").forEach(link => {
    const href = link.getAttribute("href");
    if (href && !href.includes("?patientId=")) {
      link.setAttribute("href", `${href}?patientId=${patientId}`);
    }
  });

  // Load patient header
  async function loadPatientHeader() {
    try {
      const res = await fetch(`http://localhost:5000/api/patients/${patientId}`);
      if (!res.ok) throw new Error("Patient not found");
      const p = await res.json();
      document.querySelector("header h1").textContent = `Patient Information - ${p.firstname || ''} ${p.lastname || ''}`;
    } catch (err) {
      console.error("Error loading patient header:", err);
    }
  }
  loadPatientHeader();

  // Load prescription history
  async function loadPrescriptionHistory() {
    try {
      const res = await fetch(`http://localhost:5000/api/patients/${patientId}/medications?isHistory=true`);
      if (!res.ok) throw new Error(`Failed to load history (${res.status})`);
      const meds = await res.json();

      if (meds.length === 0) {
        historyContainer.innerHTML = `<p style="color:gray;text-align:center;padding:20px;">No prescription history yet</p>`;
        return;
      }

      // Group medications by appointmentId
      const groupedByAppointment = {};
      meds.forEach(med => {
        const key = med.appointmentId || 'no-appointment';
        if (!groupedByAppointment[key]) {
          groupedByAppointment[key] = [];
        }
        groupedByAppointment[key].push(med);
      });

      // Get sort order (default: latest)
      const sortOrder = document.getElementById("sortPrescriptionHistory")?.value || "latest";
      
      // Convert to array and prepare for async date fetching
      const appointmentEntries = Object.entries(groupedByAppointment);
      
      // Fetch appointment dates for all entries
      const entriesWithDates = await Promise.all(
        appointmentEntries.map(async ([appointmentId, appointmentMeds]) => {
          const firstMed = appointmentMeds[0];
          let appointmentDate = new Date(0);
          
          // Try to get date from followup field first
          if (firstMed.followup) {
            const d = new Date(firstMed.followup);
            if (!isNaN(d.getTime())) {
              appointmentDate = d;
            }
          }
          
          // If no followup date, try to fetch from appointment
          if (appointmentDate.getTime() === 0 && appointmentId && appointmentId !== 'no-appointment') {
            try {
              let appRes = await fetch(`http://localhost:5000/api/appointments/${appointmentId}`);
              let appointment = null;
              
              if (appRes.ok) {
                appointment = await appRes.json();
              } else {
                const archiveRes = await fetch(`http://localhost:5000/api/appointments/archive/list`);
                if (archiveRes.ok) {
                  const archived = await archiveRes.json();
                  appointment = archived.find(a => a.appointmentId === appointmentId);
                }
              }
              
              if (appointment && appointment.date) {
                const d = new Date(appointment.date);
                if (!isNaN(d.getTime())) {
                  appointmentDate = d;
                }
              }
            } catch (err) {
              console.warn("Could not fetch appointment date:", err);
            }
          }
          
          // If still no date, use today as fallback
          if (appointmentDate.getTime() === 0) {
            appointmentDate = new Date();
          }
          
          return { appointmentId, appointmentMeds, date: appointmentDate };
        })
      );
      
      // Sort appointments by date
      entriesWithDates.sort((a, b) => {
        // If dates are equal, use appointmentId as fallback
        if (a.date.getTime() === b.date.getTime()) {
          return a.appointmentId.localeCompare(b.appointmentId);
        }
        
        // Sort based on selected order
        return sortOrder === "latest" 
          ? b.date.getTime() - a.date.getTime()  // Latest first (newest to oldest)
          : a.date.getTime() - b.date.getTime(); // Oldest first (oldest to newest)
      });

      let html = '';
      // Process each appointment group
      for (const { appointmentId, appointmentMeds } of entriesWithDates) {
        const firstMed = appointmentMeds[0];
        
        // Try to get date from followup field
        let appointmentDate = 'N/A';
        let appointmentTime = firstMed.followupTime || 'N/A';
        
        if (firstMed.followup) {
          try {
            const followupDate = new Date(firstMed.followup);
            if (!isNaN(followupDate.getTime())) {
              appointmentDate = followupDate.toLocaleDateString();
            }
          } catch (e) {
            console.warn("Error parsing followup date:", e);
          }
        }
        
        // If no followup date, try to fetch from appointment (async)
        if (appointmentDate === 'N/A' && appointmentId && appointmentId !== 'no-appointment') {
          try {
            // Try active appointments first
            let appRes = await fetch(`http://localhost:5000/api/appointments/${appointmentId}`);
            let appointment = null;
            
            if (appRes.ok) {
              appointment = await appRes.json();
            } else {
              // If not found in active, try to find in archived appointments
              const archiveRes = await fetch(`http://localhost:5000/api/appointments/archive/list`);
              if (archiveRes.ok) {
                const archived = await archiveRes.json();
                appointment = archived.find(a => a.appointmentId === appointmentId);
              }
            }
            
            if (appointment && appointment.date) {
              const appDate = new Date(appointment.date);
              if (!isNaN(appDate.getTime())) {
                appointmentDate = appDate.toLocaleDateString();
              }
              if (!appointmentTime || appointmentTime === 'N/A') {
                appointmentTime = appointment.time || 'N/A';
              }
            } else {
              // If appointment not found, use today's date as fallback
              appointmentDate = new Date().toLocaleDateString();
              if (appointmentTime === 'N/A') {
                appointmentTime = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
              }
            }
          } catch (err) {
            console.warn("Could not fetch appointment date:", err);
            // Use today's date as fallback
            appointmentDate = new Date().toLocaleDateString();
            if (appointmentTime === 'N/A') {
              appointmentTime = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
            }
          }
        } else if (appointmentDate === 'N/A') {
          // If no appointmentId, use today's date
          appointmentDate = new Date().toLocaleDateString();
          if (appointmentTime === 'N/A') {
            appointmentTime = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
          }
        }
        
        const prescriber = firstMed.presby || 'N/A';

        html += `
          <div class="prescription-history-item" style="border: 1px solid #ddd; border-radius: 8px; padding: 15px; margin-bottom: 15px;">
            <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
              <div>
                <h3 style="margin: 0; color: #358F85;">Prescription</h3>
                <p style="margin: 5px 0; color: #666; font-size: 14px;">
                  Date: ${appointmentDate} | Time: ${appointmentTime} | Prescribed by: ${prescriber}
                </p>
              </div>
            </div>
            <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
              <thead>
                <tr style="background: #f5f5f5;">
                  <th style="padding: 8px; border: 1px solid #ddd; text-align: left;">Medicine</th>
                  <th style="padding: 8px; border: 1px solid #ddd; text-align: left;">Dosage</th>
                  <th style="padding: 8px; border: 1px solid #ddd; text-align: left;">Frequency</th>
                  <th style="padding: 8px; border: 1px solid #ddd; text-align: left;">Quantity</th>
                  <th style="padding: 8px; border: 1px solid #ddd; text-align: left;">Notes</th>
                </tr>
              </thead>
              <tbody>
                ${appointmentMeds.map(m => `
                  <tr>
                    <td style="padding: 8px; border: 1px solid #ddd;">${m.medicname || 'N/A'}</td>
                    <td style="padding: 8px; border: 1px solid #ddd;">${m.dosage || 'N/A'}</td>
                    <td style="padding: 8px; border: 1px solid #ddd;">${m.frequency || 'N/A'}</td>
                    <td style="padding: 8px; border: 1px solid #ddd;">${m.quantity || 0}</td>
                    <td style="padding: 8px; border: 1px solid #ddd;">${m.presNotes || 'N/A'}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        `;
      }

      historyContainer.innerHTML = html;
    } catch (err) {
      console.error("Error loading prescription history:", err);
      historyContainer.innerHTML = `<p style="color:red;">Failed to load prescription history.</p>`;
    }
  }

  loadPrescriptionHistory();
  
  // Add event listener for sort filter
  const sortSelect = document.getElementById("sortPrescriptionHistory");
  if (sortSelect) {
    sortSelect.addEventListener("change", () => {
      loadPrescriptionHistory();
    });
  }
});

