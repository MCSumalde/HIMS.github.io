let allPatients = [];
let allAppointments = [];
let allArchivedAppointments = [];

async function loadReportStats() {
  try {
    // Fetch data from backend
    const [patientsRes, appointmentsRes] = await Promise.all([
      fetch("http://localhost:5000/api/patients"),
      fetch("http://localhost:5000/api/appointments")
    ]);

   allPatients = await patientsRes.json();
allAppointments = await appointmentsRes.json();

    // === PATIENT STATS ===
    const totalPatients = allPatients.length;
const activePatients = allPatients.filter(p => p.status?.toLowerCase() === "active").length;
const inactivePatients = allPatients.filter(p => p.status?.toLowerCase() === "inactive").length;

    // === APPOINTMENT STATS (Include Archive) ===
const archiveRes = await fetch("http://localhost:5000/api/appointments/archive/list");
allArchivedAppointments = await archiveRes.json();

// Combine active and archived appointments for total count
const combinedAppointments = [...allAppointments, ...allArchivedAppointments];

const totalAppointments = combinedAppointments.length;
const completedAppointments = allArchivedAppointments.filter(a => a.status === "Completed").length;
const upcomingAppointments = allAppointments.filter(a => a.status === "Upcoming").length;
const canceledAppointments = allArchivedAppointments.filter(a => a.status === "Canceled").length;

    // === UPDATE TEXT CARDS ===
    document.querySelector('.statusDisplay:nth-child(1) h1').textContent = totalPatients;
    document.querySelector('.statusDisplay:nth-child(2) h1').textContent = activePatients;
    document.querySelector('.statusDisplay:nth-child(3) h1').textContent = totalAppointments;
    document.querySelector('.statusDisplay:nth-child(4) h1').textContent = completedAppointments;

    // === UPDATE CHARTS ===
   updateCharts(allPatients, activePatients, inactivePatients, upcomingAppointments, completedAppointments, canceledAppointments);
  } catch (err) {
    console.error("Error loading report stats:", err);
  }
}

function updateCharts(patients, active, inactive, up, done, cancel) {
  // === BAR CHART (Appointments) ===
  const bars = document.querySelectorAll('.barChart .bar');
  const maxYValue = 8;
  const chartPixelHeight = 180;
  const pixelPerUnit = chartPixelHeight / maxYValue;

  if (bars.length >= 3) {
    const values = [up, done, cancel];
    bars.forEach((bar, i) => {
      const cappedValue = Math.min(values[i], maxYValue);
      const newHeight = cappedValue * pixelPerUnit;
      bar.style.transition = "height 0.5s ease";
      bar.style.height = `${newHeight}px`;
    });
  }

  // === PIE CHART 1: Active vs Inactive ===
  const totalPatients = active + inactive;
  const activePercent = totalPatients ? (active / totalPatients * 100).toFixed(1) : 0;
  const inactivePercent = totalPatients ? (inactive / totalPatients * 100).toFixed(1) : 0;

  const pie1 = document.querySelector(".pieChart1");
  pie1.style.background = `
    conic-gradient(
      #289b3b 0% ${activePercent}%,
      #696969 ${activePercent}% 100%
    )`;

  document.querySelectorAll('.activeText')[0].textContent = `Active: ${active} (${activePercent}%)`;
  document.querySelectorAll('.activeText')[1].textContent = `Inactive: ${inactive} (${inactivePercent}%)`;

  // === PIE CHART 2: Gender Distribution ===
  const maleCount = patients.filter(p => p.gender?.toLowerCase() === "male").length;
  const femaleCount = patients.filter(p => p.gender?.toLowerCase() === "female").length;
  const otherCount = patients.length - maleCount - femaleCount;
  const totalGender = maleCount + femaleCount + otherCount;

  const malePercent = totalGender ? (maleCount / totalGender * 100).toFixed(1) : 0;
  const femalePercent = totalGender ? (femaleCount / totalGender * 100).toFixed(1) : 0;
  const otherPercent = totalGender ? (otherCount / totalGender * 100).toFixed(1) : 0;

  const pie2 = document.querySelector(".pieChart2");
  pie2.style.background = `
    conic-gradient(
      #289b3b 0% ${malePercent}%,
      #007bff ${malePercent}% ${Number(malePercent) + Number(femalePercent)}%,
      #696969 ${Number(malePercent) + Number(femalePercent)}% 100%
    )`;

  const genderTexts = document.querySelectorAll('.pieChartCon:nth-of-type(3) .activeText');
  if (genderTexts.length >= 3) {
    genderTexts[0].textContent = `Male: ${maleCount} (${malePercent}%)`;
    genderTexts[1].textContent = `Female: ${femaleCount} (${femalePercent}%)`;
    genderTexts[2].textContent = `Others: ${otherCount} (${otherPercent}%)`;
  }

  // === 🧒 AGE DEMOGRAPHICS BAR CHART ===
const ageBars = document.querySelectorAll('.barChart .bars');

// 🔹 Convert each patient's DOB into age
function calculateAge(dob) {
  if (!dob) return 0;
  const birthDate = new Date(dob);
  const diff = Date.now() - birthDate.getTime();
  const ageDate = new Date(diff);
  return Math.abs(ageDate.getUTCFullYear() - 1970);
}

const ageGroups = [
  patients.filter(p => calculateAge(p.dob) >= 0 && calculateAge(p.dob) <= 18).length,
  patients.filter(p => calculateAge(p.dob) >= 19 && calculateAge(p.dob) <= 30).length,
  patients.filter(p => calculateAge(p.dob) >= 31 && calculateAge(p.dob) <= 50).length,
  patients.filter(p => calculateAge(p.dob) >= 51 && calculateAge(p.dob) <= 70).length,
  patients.filter(p => calculateAge(p.dob) > 70).length
];

const ageMaxYValue = Math.max(...ageGroups, 10); // make chart auto-scale to highest group
const ageChartPixelHeight = 180;
const agePixelPerUnit = ageChartPixelHeight / ageMaxYValue;

if (ageBars.length >= 5) {
  ageBars.forEach((bar, i) => {
    const cappedAgeValue = Math.min(ageGroups[i], ageMaxYValue);
    const newHeight = cappedAgeValue * agePixelPerUnit;
    bar.style.transition = "height 0.5s ease";
    bar.style.height = `${newHeight}px`;
  });
}
}

// ✅ Load doctors into filter dropdown
async function loadDoctorFilter() {
  try {
    const res = await fetch("http://localhost:5000/api/users");
    const users = await res.json();
    const doctors = users.filter(u => u.role === "Doctor" && u.status === "Active");
    
    const select = document.getElementById("doctorFilter");
    doctors.forEach(doc => {
      const option = document.createElement("option");
      option.value = doc.userId;
      option.textContent = doc.name;
      select.appendChild(option);
    });
  } catch (err) {
    console.error("Error loading doctors:", err);
  }
}

// Call on page load
document.addEventListener("DOMContentLoaded", () => {
  loadDoctorFilter();
  
  // Add event listeners for filters
  document.getElementById("dateRangeFilter").addEventListener("change", applyFilters);
  document.getElementById("doctorFilter").addEventListener("change", applyFilters);
});

// ✅ Filter appointments by date range and doctor
function applyFilters() {
  const dateRange = parseInt(document.getElementById("dateRangeFilter").value);
  const selectedDoctor = document.getElementById("doctorFilter").value;
  
  const now = new Date();
  let startDate = new Date();
  
  // Calculate date range
  if (dateRange === 30) {
    startDate.setDate(now.getDate() - 30);
  } else if (dateRange === 90) {
    startDate.setDate(now.getDate() - 90);
  } else if (dateRange === 365) {
    startDate.setDate(now.getDate() - 365);
  } else {
    startDate = new Date(0); // All time
  }
  
  // Filter appointments by date
  const filteredAppointments = allAppointments.filter(app => {
    const appDate = new Date(app.date);
    return appDate >= startDate;
  });
  
  const filteredArchived = allArchivedAppointments.filter(app => {
    const appDate = new Date(app.date);
    return appDate >= startDate;
  });
  
  // Filter by doctor if selected
  let finalAppointments = filteredAppointments;
  let finalArchived = filteredArchived;
  
  if (selectedDoctor !== "all") {
    finalAppointments = filteredAppointments.filter(app => app.doctorId === selectedDoctor);
    finalArchived = filteredArchived.filter(app => app.doctorId === selectedDoctor);
  }
  
  // Recalculate stats with filtered data
  const totalAppointments = [...finalAppointments, ...finalArchived].length;
  const completedAppointments = finalArchived.filter(a => a.status === "Completed").length;
  const upcomingAppointments = finalAppointments.filter(a => a.status === "Upcoming").length;
  const canceledAppointments = finalArchived.filter(a => a.status === "Canceled").length;
  
  // Update display
  document.querySelector('.statusDisplay:nth-child(3) h1').textContent = totalAppointments;
  document.querySelector('.statusDisplay:nth-child(4) h1').textContent = completedAppointments;
  
  // Update charts with filtered data
  updateCharts(allPatients, 
        allPatients.filter(p => p.status?.toLowerCase() === "active").length,
        allPatients.filter(p => p.status?.toLowerCase() === "inactive").length,
    upcomingAppointments, 
    completedAppointments, 
    canceledAppointments
  );
}

// ✅ Run when page loads
window.onload = loadReportStats;

// ✅ Auto-refresh every 10 seconds while preserving filters
setInterval(async () => {
  await loadReportStats();
  
  // Re-apply filters after data refresh
  const dateRangeFilter = document.getElementById("dateRangeFilter");
  const doctorFilter = document.getElementById("doctorFilter");
  
  // Only apply filters if they're not at default values
  if (dateRangeFilter.value !== "30" || doctorFilter.value !== "all") {
    applyFilters();
  }
}, 10000);