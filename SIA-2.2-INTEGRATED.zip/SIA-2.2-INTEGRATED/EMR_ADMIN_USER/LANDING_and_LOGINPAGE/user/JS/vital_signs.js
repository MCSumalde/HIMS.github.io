document.addEventListener("DOMContentLoaded", async () => {
  const saveBtn = document.querySelector(".savebtn");
  const cancelBtn = document.querySelector(".cancelbtn");
  const buttonCon = document.getElementById("buttonCon");
  const medContainer = document.querySelector(".medecineWrap");
  const patientId = new URLSearchParams(window.location.search).get("patientId");

    // 🧠 Load patient name and display in header
  async function loadPatientHeader() {
    try {
      const res = await fetch(`http://localhost:5000/api/patients/${patientId}`);
      if (!res.ok) throw new Error("Patient not found");

      const p = await res.json();
      document.querySelector("header h1").textContent = `Patient Information - ${p.firstname} ${p.lastname}`;
    } catch (err) {
      console.error("Error loading patient header:", err);
    }
  }

  loadPatientHeader();


  if (!patientId) return alert("No patient selected!");
  buttonCon.style.display = "none";

  // ✅ Update nav-bar links with patientId
  document.querySelectorAll("nav-bar a").forEach(link => {
    const href = link.getAttribute("href");
    if (href && !href.includes("?patientId=")) {
      link.setAttribute("href", `${href}?patientId=${patientId}`);
    }
  });

  // 🔹 Load existing vital sign records
  async function loadVitals() {
    try {
      const res = await fetch(`http://localhost:5000/api/patients/${patientId}/vitalsigns`);
      const vitals = await res.json();

      medContainer.innerHTML = `
        <section class="topSec">
          <h2>Vital Signs</h2>
          <a id="addVitalBtn" href="#">Add Vital Sign Record</a>
        </section>
      `;

      if (vitals.length === 0) {
        medContainer.innerHTML += `<p></p>`;
      }

      vitals.forEach((v, index) => {
  medContainer.innerHTML += `
    <div class="medecineCon">
      <div class="medecineHeader">
        <h3>Vital Sign Record ${index + 1}</h3>
              <i class="fa-solid fa-trash" data-id="${v.vitalId}"></i>
            </div>
            <form>
              <section class="topSec">
                <div class="topLeftForm">
                  <div class="form-group">
                    <label>Date</label>
                    <input type="date" value="${v.date ? v.date.split("T")[0] : ""}" disabled />
                  </div>
                  <div class="form-group">
                    <label>Heart Rate</label>
                    <input type="text" value="${v.heartrate || ""}" disabled />
                  </div>
                </div>

                <div class="topMidForm">
                  <div class="form-group">
                    <label>Temperature</label>
                    <input type="text" value="${v.temp || ""}" disabled />
                  </div>
                  <div class="form-group">
                    <label>Weight</label>
                    <input type="text" value="${v.weight || ""}" disabled />
                  </div>
                </div>

                <div class="topRightForm">
                  <div class="form-group">
                    <label>Blood Pressure</label>
                    <input type="text" value="${v.pressure || ""}" disabled />
                  </div>
                  <div class="form-group">
                    <label>Height</label>
                    <input type="text" value="${v.height || ""}" disabled />
                  </div>
                </div>
              </section>

              <section class="bottomSec">
                <div class="form-group">
                  <label>BMI</label>
                  <input type="text" value="${v.bmi || ""}" disabled />
                </div>
              </section>
            </form>
          </div>
        `;
      });

      // 🔹 Delete logic
      document.querySelectorAll(".fa-trash").forEach(icon => {
        icon.addEventListener("click", async () => {
          const vitalId = icon.dataset.id;
          if (!confirm("Delete this record?")) return;
          const res = await fetch(`http://localhost:5000/api/vitalsigns/${vitalId}`, {
            method: "DELETE",
          });
          if (res.ok) {
            alert("🗑️ Vital sign record deleted!");
            loadVitals();
          } else {
            alert("❌ Failed to delete record.");
          }
        });
      });

      // 🔹 Add new record logic
      const addBtn = document.getElementById("addVitalBtn");
      addBtn.addEventListener("click", (e) => {
        e.preventDefault();
        if (document.querySelector(".newRecord")) return;

        medContainer.insertAdjacentHTML("beforeend", `
          <div class="medecineCon newRecord">
            <div class="medecineHeader">
              <h3>New Vital Sign Record</h3>
            </div>
            <form id="vitalForm">
              <section class="topSec">
                <div class="topLeftForm">
                  <div class="form-group">
                    <label>Date</label>
                    <input type="date" name="date" required />
                  </div>
                  <div class="form-group">
                    <label>Heart Rate</label>
                    <input type="text" name="heartrate" required />
                  </div>
                </div>
                <div class="topMidForm">
                  <div class="form-group">
                    <label>Temperature</label>
                    <input type="text" name="temp" required />
                  </div>
                  <div class="form-group">
                    <label>Weight</label>
                    <input type="text" name="weight" required />
                  </div>
                </div>
                <div class="topRightForm">
                  <div class="form-group">
                    <label>Blood Pressure</label>
                    <input type="text" name="pressure" required />
                  </div>
                  <div class="form-group">
                    <label>Height</label>
                    <input type="text" name="height" required />
                  </div>
                </div>
              </section>
              <section class="bottomSec">
                <div class="form-group">
                  <label>BMI</label>
                  <input type="text" name="bmi" required />
                </div>
              </section>
            </form>
          </div>
        `);

        buttonCon.style.display = "flex";
        addBtn.style.display = "none";
      });

    } catch (err) {
      console.error("❌ Error loading vitals:", err);
    }
  }

  // Initial load
  await loadVitals();

  // Cancel button
  cancelBtn.addEventListener("click", (e) => {
    e.preventDefault();
    document.querySelector(".newRecord")?.remove();
    buttonCon.style.display = "none";
    const addBtn = document.getElementById("addVitalBtn");
    if (addBtn) addBtn.style.display = "inline-block";
  });

  // Save button
// ✅ Save button (with required field validation)
saveBtn.addEventListener("click", async (e) => {
  e.preventDefault();

  const form = document.querySelector("#vitalForm");
  if (!form) return alert("No form to save!");

  // 🧠 Validate all required fields before saving
  if (!form.checkValidity()) {
    form.reportValidity(); // show built-in browser error popup
    return; // stop execution if invalid
  }

  // ✅ Gather all field data
  const data = Object.fromEntries(new FormData(form).entries());

  try {
    const res = await fetch(`http://localhost:5000/api/patients/${patientId}/vitalsigns`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });

    if (!res.ok) throw new Error("Failed to save record.");

    alert("✅ Vital sign record added!");
    await loadVitals();
    buttonCon.style.display = "none";
  } catch (err) {
    console.error(err);
    alert("❌ Error saving vital sign record.");
  }
});

});