// models/PrescribeModel.js
import mongoose from "mongoose";

const prescribeSchema = new mongoose.Schema({
  medId: { type: String, unique: true },
  patientId: { type: String, required: true },
  medicname: String,
  dosage: String,
  frequency: String,
  quantity: { type: Number, default: 0 },
  presby: String,
  presNotes: String,
  followup: Date,
});

const Prescribe =
  mongoose.models.Prescribe || mongoose.model("Prescribe", prescribeSchema);

export default Prescribe;