// =========================
// SERVER.JS (ES MODULE VERSION)
// =========================
import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import bcrypt from "bcrypt";
import dotenv from "dotenv";
import fetch from "node-fetch";

// Load environment variables
dotenv.config();

// Helper: build and validate Billing URL
function buildBillingUrl(path) {
  const base = process.env.BILLING_URL;
  if (!base) return null;
  try {
    // new URL allows relative path with base
    return new URL(path, base).toString();
  } catch (err) {
    console.warn("Invalid BILLING_URL provided:", base);
    return null;
  }
}

const app = express();
app.use(cors());
app.use(express.json());

// =========================
// SAFE MODEL IMPORTS 
// =========================
import AppointmentModel from "./models/AppointmentModel.js";
import PatientModel from "./models/PatientModel.js";
import UserModel from "./models/UserModel.js";
import MedicineModel from "./models/MedicineModel.js";
import PrescribeModel from "./models/PrescribeModel.js";

export {
  PatientModel,
  UserModel,
  MedicineModel,
  AppointmentModel,
  PrescribeModel
};


// --- ROUTES ---
import pharmacyRoutes from "./routes/pharmacyRoutes.js";
app.use("/api/pharmacydb", pharmacyRoutes);

import integrationRoutes from "./routes/integrationRoutes.js";
app.use("/api/integration", integrationRoutes);

import pharmacyIntegrationTest from "./routes/pharmacyIntegrationTest.js";
app.use("/api/settings", pharmacyIntegrationTest);

import billingRoutes from "./routes/billingIntegration.js";
app.use("/api/integrations", billingRoutes);

import medicationIntegrationRoutes from "./routes/medicationIntegration.js";
app.use("/api/medication-integration", medicationIntegrationRoutes);



// ====== CONNECT TO MONGODB ======
mongoose
  .connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  .then(() => console.log("✅ MongoDB Connected"))
  .catch(err => console.error("❌ MongoDB Error:", err));

// Remove old duplicate index (optional)
mongoose.connection.once("open", async () => {
  try {
    await mongoose.connection.db.collection("patients").dropIndex("patientid_1");
    console.log("✅ Dropped old patientid_1 index");
  } catch (err) {
    console.log("ℹ No old index to drop");
  }
});

// ====== LIVE TOGGLES ======
// Store integration toggle status in memory (replace with DB if needed)
let integrationStatus = {
  emr: process.env.ENABLE_EMR_API === "true",
  billing: process.env.ENABLE_BILLING_API === "true",
  pharmacy: process.env.ENABLE_PHARMACY_API === "true"
};

// API to get current integration status
app.get("/api/integration/status", (req, res) => {
  res.json(integrationStatus);
});

// API to update integration status dynamically
app.post("/api/integration/status", (req, res) => {
  const { emr, billing, pharmacy } = req.body;
  integrationStatus.emr = !!emr;
  integrationStatus.billing = !!billing;
  integrationStatus.pharmacy = !!pharmacy;

  console.log("Updated integration status:", integrationStatus);
  res.json({ success: true, integrationStatus });
});

// ====== EMR PRESCRIPTION SAVE ======
app.post("/api/prescriptions", async (req, res) => {
  const prescription = req.body;

  // Save prescription to EMR DB (example, replace with actual model)
  // await Prescription.create(prescription);

  // Push to Pharmacy if enabled
  if (integrationStatus.pharmacy) {
    try {
      await fetch(process.env.PHARMACY_URL + "/api/prescriptions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": process.env.PHARMACY_API_KEY
        },
        body: JSON.stringify(prescription)
      });
      console.log("✅ Prescription sent to Pharmacy");
    } catch (err) {
      console.error("❌ Failed to send to Pharmacy:", err.message);
    }
  }

  // Push to Billing if enabled
  if (integrationStatus.billing) {
    const billingUrl = buildBillingUrl('/api/billing');
    if (!billingUrl) {
      console.warn('⚠️ BILLING_URL not set or invalid — skipping billing send for prescription');
    } else {
      try {
        await fetch(billingUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": process.env.BILLING_API_KEY
          },
          body: JSON.stringify(prescription)
        });
        console.log("✅ Billing info sent to Billing System");
      } catch (err) {
        console.error("❌ Failed to send to Billing:", err.message);
      }
    }
  }

  res.json({ success: true });
});

// ====== CONNECT TO LOCAL MONGODB ======
mongoose
  .connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
  })
  .then(() => console.log("✅ MongoDB Connected"))
  .catch((err) => console.error("❌ MongoDB Error:", err));

mongoose.connection.once("open", async () => {
  try {
    // Drop old index if exists
    await mongoose.connection.db
      .collection("patients")
      .dropIndex("patientid_1");
    console.log("✅ Dropped old patientid_1 index");
  } catch (err) {
    console.log("No old index to drop (this is fine)");
  }

  // ✅ MIGRATE OLD DATA - converts patientid to patientId
  try {
    const oldPatients = await mongoose.connection.db
      .collection("patients")
      .find({})
      .toArray();

    for (const patient of oldPatients) {
      if (patient.patientid && !patient.patientId) {
        // Rename field from patientid to patientId
        await mongoose.connection.db.collection("patients").updateOne(
          { _id: patient._id },
          {
            $set: { patientId: patient.patientid },
            $unset: { patientid: "" },
          }
        );
      }
    }
    if (oldPatients.length > 0) {
      console.log(`✅ Migrated ${oldPatients.length} patients to camelCase`);
    }
  } catch (err) {
    console.log("Migration error:", err.message);
  }

  // ✅ SET DEFAULT STATUS FOR PATIENTS WITHOUT ONE OR WITH LOWERCASE
  try {
    const result = await mongoose.connection.db
      .collection("patients")
      .updateMany(
        {
          $or: [
            { status: { $exists: false } },
            { status: null },
            { status: "" },
            { status: "active" }, // ✅ Also fix lowercase "active"
          ],
        },
        { $set: { status: "Active" } }
      );
    if (result.modifiedCount > 0) {
      console.log(`✅ Set default status for ${result.modifiedCount} patients`);
    }
  } catch (err) {
    console.log("Status update error:", err.message);
  }
});

// ✅ TEMPORARY: Force update all patient statuses to Active
app.get("/api/patients/fix-status", async (req, res) => {
  try {
    const result = await Patient.updateMany(
      {
        $or: [{ status: { $exists: false } }, { status: null }, { status: "" }],
      },
      { $set: { status: "Active" } }
    );

    res.json({
      message: `✅ Updated ${result.modifiedCount} patients to Active status`,
      modifiedCount: result.modifiedCount,
    });
  } catch (err) {
    console.error("Error updating statuses:", err);
    res.status(500).json({ message: "Error updating statuses" });
  }
});

// ✅ DEBUG: Check all patient statuses
app.get("/api/patients/check-all", async (req, res) => {
  try {
    const allPatients = await Patient.find({});
    const report = allPatients.map((p) => ({
      patientId: p.patientId,
      name: `${p.firstname} ${p.lastname}`,
      status: p.status,
      statusValue: JSON.stringify(p.status),
    }));

    res.json({
      total: allPatients.length,
      patients: report,
    });
  } catch (err) {
    res.status(500).json({ message: "Error" });
  }
});


app.get("/api/patients/fix-lowercase-status", async (req, res) => {
  try {
    const result = await Patient.updateMany(
      { status: "active" }, 
      { $set: { status: "Active" } } 
    );

    res.json({
      message: `✅ Updated ${result.modifiedCount} patients from "active" to "Active"`,
      modifiedCount: result.modifiedCount,
    });
  } catch (err) {
    res.status(500).json({ message: "Error updating statuses" });
  }
});

// ====== USER SCHEMA ======
const userSchema = new mongoose.Schema({
  userId: String,
  name: String,
  email: { type: String, unique: true, lowercase: true, trim: true },
  password: String,
  role: { type: String, enum: ["Admin", "Doctor", "Nurse"] },
  status: { type: String, enum: ["Active", "Inactive"], default: "Active" },
  lastLogin: { type: Date, default: null },
});

const User = mongoose.model("User", userSchema);

const normalizeEmail = (email = "") => email.trim().toLowerCase();

// ====== ARCHIVE SCHEMA ======
const archiveSchema = new mongoose.Schema({
  userId: String,
  name: String,
  email: String,
  role: String,
  status: String,
  lastLogin: Date,
  archivedOn: { type: Date, default: Date.now },
});

const Archive = mongoose.model("Archive", archiveSchema);

// ====== HELPER: Generate UserId ======
async function generateUserId(role) {
  let prefix = "";
  if (role === "Admin") prefix = "A";
  else if (role === "Doctor") prefix = "D";
  else if (role === "Nurse") prefix = "N";

  const count = await User.countDocuments({ role });
  const number = String(count + 1).padStart(3, "0");
  return `${prefix}${number}`;
}

// ====== LOGIN (Auto-detect role) ======
app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;
  const normalizedEmail = normalizeEmail(email);

  const user = await User.findOne({ email: normalizedEmail });
  if (!user) return res.status(400).json({ message: "Invalid credentials" });

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch)
    return res.status(400).json({ message: "Invalid email and password." });

  // ✅ Check if using temporary password
  const isTempPassword = await bcrypt.compare("Temp@123", user.password);

  // Update last login time
  user.lastLogin = new Date();
  await user.save();

  // ✅ LOG LOGIN ACTIVITY
  try {
    const logId = await generateActivityLogId();
    const loginTime = new Date(); // ✅ NEW: Capture login time

    const activityLog = new ActivityLog({
      logId,
      userId: user.userId,
      userName: user.name,
      userRole: user.role,
      action: "Login",
      details: `User logged in successfully`,
      ipAddress: req.ip || req.connection.remoteAddress || "Unknown",
      loginTime: loginTime, // ✅ NEW: Store login time
      timestamp: loginTime,
    });
    await activityLog.save();

    // ✅ NEW: Store login session ID in response for logout tracking
    console.log(`✅ Login activity logged for ${user.name} with ID: ${logId}`);

    res.json({
      message: "Login success",
      role: user.role,
      name: user.name,
      email: user.email,
      userId: user.userId,
      sessionLogId: logId,
      requiresReset: isTempPassword,
    });
    return;
  } catch (err) {
    console.error("❌ Error logging login activity:", err);
  }
});

// ✅ NEW ENDPOINT: Reset Password
app.post("/api/reset-password", async (req, res) => {
  try {
    const { email, newPassword } = req.body;
    const normalizedEmail = normalizeEmail(email);

    if (!email || !newPassword) {
      return res
        .status(400)
        .json({ message: "Email and new password are required" });
    }

    if (newPassword.length < 6) {
      return res
        .status(400)
        .json({ message: "Password must be at least 6 characters" });
    }

    const user = await User.findOne({ email: normalizedEmail });
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Hash new password and update
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;
    await user.save();

    res.json({ message: "✅ Password reset successfully" });
  } catch (err) {
    console.error("Error resetting password:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// ✅ NEW ENDPOINT: Verify Admin Password ← ADD THIS HERE
app.post("/api/users/verify-password", async (req, res) => {
  try {
    const { email, password } = req.body;
    const normalizedEmail = normalizeEmail(email);

    if (!email || !password) {
      return res
        .status(400)
        .json({ valid: false, message: "Email and password are required" });
    }

    // Find user by email
    const user = await User.findOne({ email: normalizedEmail });

    if (!user) {
      return res.status(404).json({ valid: false, message: "User not found" });
    }

    // Compare password with hashed password
    const isMatch = await bcrypt.compare(password, user.password);

    if (isMatch && user.role === "Admin") {
      res.json({ valid: true, message: "Password verified" });
    } else {
      res
        .status(401)
        .json({ valid: false, message: "Invalid credentials or not an admin" });
    }
  } catch (error) {
    console.error("Password verification error:", error);
    res.status(500).json({ valid: false, message: "Server error" });
  }
});

// ====== ADD NEW USER (Doctor/Nurse) and ADMIN VERIFICATION (FIXED) ======
app.post("/api/users", async (req, res) => {
  try {
    const { userId, password, action } = req.body; // 1. 🛑 HANDLE ADMIN VERIFICATION ACTION FIRST 🛑

    if (action === "verify") {
      if (!userId || !password) {
        return res
          .status(400)
          .json({ message: "Missing Admin ID or password for verification." });
      }

      const adminUser = await User.findOne({ userId }); // Check 1: User existence and Admin role

      if (!adminUser || adminUser.role !== "Admin") {
        // Using 401 Unauthorized for security purposes
        return res
          .status(401)
          .json({ message: "Unauthorized: Invalid credentials or role." });
      } // Check 2: Password comparison

      const isMatch = await bcrypt.compare(password, adminUser.password);

      if (isMatch) {
        // Verification successful
        return res
          .status(200)
          .json({ message: "✅ Admin verified successfully" });
      } else {
        // Password incorrect
        return res.status(401).json({ message: "Incorrect Admin Password." });
      }
    }

     

    const { name, email, role: userRole, password: userPassword } = req.body; // Ensure fields are present for creation
    const normalizedEmail = normalizeEmail(email);

    if (!userRole || !name || !email || !userPassword) {
      return res
        .status(400)
        .json({ message: "Missing required fields for new user creation." });
    }
    if (!["Doctor", "Nurse"].includes(userRole))
      return res
        .status(400)
        .json({ message: "Only Doctor or Nurse accounts can be added" });

    const existing = await User.findOne({ email: normalizedEmail });
    if (existing)
      return res.status(400).json({ message: "Email already exists" });

    const hashedPassword = await bcrypt.hash(userPassword, 10);
    const newUserId = await generateUserId(userRole);

    const newUser = new User({
      userId: newUserId,
      name,
      email: normalizedEmail,
      password: hashedPassword,
      role: userRole,
      status: "Active",
      lastLogin: null,
    });

    await newUser.save();
    res.json({ message: "✅ User added successfully", user: newUser });
  } catch (err) {
    console.error("Error processing user API request:", err);
    res
      .status(500)
      .json({ message: "Server error or Database connection failure." });
  }
});

// Logout and update activity log
    app.post("/api/logout", async (req, res) => {
      try {
        const { sessionLogId } = req.body;

        if (!sessionLogId) {
          return res.status(400).json({ message: "Session log ID required" });
        }

        const activityLog = await ActivityLog.findOne({ logId: sessionLogId });

        if (!activityLog) {
          return res.status(404).json({ message: "Activity log not found" });
        }

        const logoutTime = new Date();
        const loginTime = activityLog.loginTime || activityLog.timestamp;

        // Calculate duration
        const durationMs = logoutTime - loginTime;
        const hours = Math.floor(durationMs / (1000 * 60 * 60));
        const minutes = Math.floor(
          (durationMs % (1000 * 60 * 60)) / (1000 * 60)
        );
        const seconds = Math.floor((durationMs % (1000 * 60)) / 1000);

        const durationStr =
          hours > 0
            ? `${hours}h ${minutes}m ${seconds}s`
            : `${minutes}m ${seconds}s`;

        // Update activity log with logout info
        activityLog.action = "Logout";
        activityLog.logoutTime = logoutTime;
        activityLog.duration = durationStr;
        activityLog.details = `User logged out after ${durationStr}`;

        await activityLog.save();

        console.log(
          `✅ Logout logged for ${activityLog.userName} - Duration: ${durationStr}`
        );

        res.json({
          message: "✅ Logout successful",
          duration: durationStr,
        });
      } catch (err) {
        console.error("❌ Error logging logout:", err);
        res.status(500).json({ message: "Error logging logout" });
      }
    });

// ====== FETCH ALL USERS ======
app.get("/api/users", async (req, res) => {
  try {
    const users = await User.find({}, "-password");
    res.json(users);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

// ====== DELETE USER (Archive) ======
app.delete("/api/users/:id", async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: "User not found" });

    // Move to Archive
    const archivedUser = new Archive({
      userId: user.userId,
      name: user.name,
      email: user.email,
      role: user.role,
      status: user.status,
      lastLogin: user.lastLogin,
    });

    await archivedUser.save();
    await user.deleteOne();

    res.json({ message: "🗑️ User archived successfully" });
  } catch (err) {
    res
      .status(400)
      .json({ message: "Error archiving user", error: err.message });
  }
});

// ====== UPDATE USER ======
app.put("/api/users/:id", async (req, res) => {
  try {
    const { name, email, status, password } = req.body;

    // Prepare update data (removed 'role' since it shouldn't be updatable)
    const updateData = { name, email, status };

    // If password is provided, hash it and include it
    if (password && password.trim() !== "") {
      const hashedPassword = await bcrypt.hash(password, 10);
      updateData.password = hashedPassword;
    }

    const user = await User.findByIdAndUpdate(req.params.id, updateData, {
      new: true,
      runValidators: true,
      fields: "-password",
    });

    if (!user) return res.status(404).json({ message: "User not found" });

    res.json({ message: "✅ User updated successfully", user });
  } catch (err) {
    console.error("Error updating user:", err);
    res.status(500).json({ message: "Server error" });
  }
});



// ====== FETCH ARCHIVED USERS ======
app.get("/api/archive", async (req, res) => {
  try {
    const archivedUsers = await Archive.find({});
    res.json(archivedUsers);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
});

// ====== RESTORE USER FROM ARCHIVE ======
app.post("/api/archive/restore/:id", async (req, res) => {
  try {
    const archivedUser = await Archive.findById(req.params.id);
    if (!archivedUser)
      return res.status(404).json({ message: "Archived user not found" });

    // ✅ CHECK 1: Check if email already exists in active users
    const existingUser = await User.findOne({ email: archivedUser.email });
    if (existingUser) {
      return res.status(400).json({ 
        message: `Cannot restore: A user with email ${archivedUser.email} already exists in the system.` 
      });
    }

    // ✅ CHECK 2: Check if userId already exists (in case of ID conflicts)
    const existingUserId = await User.findOne({ userId: archivedUser.userId });
    if (existingUserId) {
      // Generate a new userId if there's a conflict
      const newUserId = await generateUserId(archivedUser.role);
      console.log(`⚠️ UserID conflict detected. Generating new ID: ${newUserId}`);
      archivedUser.userId = newUserId;
    }

    // Restore with temporary password (force reset later)
    const tempPassword = await bcrypt.hash("Temp@123", 10);

    const restoredUser = new User({
      userId: archivedUser.userId,
      name: archivedUser.name,
      email: archivedUser.email,
      password: tempPassword,
      role: archivedUser.role,
      status: archivedUser.status,
      lastLogin: archivedUser.lastLogin,
    });

    await restoredUser.save();
    await archivedUser.deleteOne();

    res.json({
      message: "✅ User restored successfully. Password reset required (Temp@123).",
      user: {
        userId: restoredUser.userId,
        name: restoredUser.name,
        email: restoredUser.email,
        role: restoredUser.role
      },
    });
  } catch (err) {
    console.error("❌ Error restoring user:", err);
    
    // ✅ CHECK 3: Handle MongoDB duplicate key errors specifically
    if (err.code === 11000) {
      const field = Object.keys(err.keyPattern)[0];
      return res.status(400).json({ 
        message: `Cannot restore: ${field} already exists in the system.` 
      });
    }
    
    res.status(500).json({ 
      message: "Error restoring user", 
      error: err.message 
    });
  }
});

// ====== PERMANENTLY DELETE FROM ARCHIVE ======
app.delete("/api/archive/:id", async (req, res) => {
  try {
    await Archive.findByIdAndDelete(req.params.id);
    res.json({ message: "❌ User permanently deleted" });
  } catch (err) {
    res
      .status(400)
      .json({ message: "Error deleting archived user", error: err.message });
  }
});

// ====== PATIENT SCHEMA ======

// ✅ Patient Schema
const patientSchema = new mongoose.Schema({
  patientId: { type: String, unique: true },
  firstname: String,
  lastname: String,
  dob: Date,
  gender: String,
  address: String,
  city: String,
  barangay: String,
  zipcode: String,
  email: String,
  phone: String,
  insurance: String,
  status: { type: String, default: "Active" },
  em_fullname: String,
  em_phone: String,
  relationship: String,
  em_email: String,
});

const Patient = mongoose.model("Patient", patientSchema);

// ✅ Helper: Generate PatientID (P001, P002…)
async function generatePatientId() {
  const lastPatient = await Patient.findOne().sort({ _id: -1 }); // newest record
  if (!lastPatient) return "P001";

  // ✅ Handle both old (patientid) and new (patientId) field names
  const lastId = lastPatient.patientId || lastPatient.patientid;

  if (!lastId) return "P001"; // Safety check

  const lastIdNum = parseInt(lastId.replace("P", ""));
  const newIdNum = lastIdNum + 1;

  return "P" + newIdNum.toString().padStart(3, "0");
}

// ✅ Add new patient (auto ID)
app.post("/api/patients", async (req, res) => {
  try {
    const newId = await generatePatientId();
    const patient = new Patient({ ...req.body, patientId: newId });

    await patient.save();
    res
      .status(201)
      .json({ message: "Patient registered successfully", patient });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error registering patient" });
  }
});

// ✅ Fetch all patients
app.get("/api/patients", async (req, res) => {
  try {
    const patients = await Patient.find();
    res.json(patients);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error fetching patients" });
  }
});

// ✅ Fetch single patient by patientId
app.get("/api/patients/:patientId", async (req, res) => {
  try {
    const patient = await Patient.findOne({ patientId: req.params.patientId });

    if (!patient) {
      return res.status(404).json({ message: "Patient not found" });
    }

    res.json(patient);
  } catch (err) {
    console.error("Error fetching patient:", err);
    res.status(500).json({ message: "Error fetching patient" });
  }
});

// ✅ Update patient info
app.put("/api/patients/:patientId", async (req, res) => {
  try {
    const updatedPatient = await Patient.findOneAndUpdate(
      { patientId: req.params.patientId },
      req.body,
      { new: true }
    );

    if (!updatedPatient)
      return res.status(404).json({ message: "Patient not found" });

    res.json({
      message: "✅ Patient information updated successfully",
      patient: updatedPatient,
    });
  } catch (err) {
    console.error("Error updating patient:", err);
    res.status(500).json({ message: "Error updating patient" });
  }
});

// ====== MEDICATION SCHEMA ======
const medicationSchema = new mongoose.Schema({
  medId: { type: String, unique: true },
  patientId: { type: String, required: true },
  appointmentId: { type: String }, // Link medication to appointment
  medicname: String,
  dosage: String,
  frequency: String,
  quantity: { type: Number, default: 0 },
  presby: String,
  presNotes: String,
  followup: Date,
  followupTime: String, // Add follow-up time
  isHistory: { type: Boolean, default: false }, // Flag for prescription history
});

const Medication = mongoose.model("Medication", medicationSchema);

// 🔹 Helper to generate unique medId (M001, M002…)
async function generateMedId() {
  const last = await Medication.findOne().sort({ _id: -1 });
  if (!last) return "M001";
  const num = parseInt(last.medId.replace("M", "")) + 1;
  return "M" + num.toString().padStart(3, "0");
}

// 🔹 Add new medication for a patient
app.post("/api/patients/:patientId/medications", async (req, res) => {
  try {
    const { patientId } = req.params;
    const newId = await generateMedId();

    const medication = new Medication({
      medId: newId,
      patientId,
      appointmentId: req.body.appointmentId || null,
      medicname: req.body.medicname,
      dosage: req.body.dosage,
      frequency: req.body.frequency,
      quantity: req.body.quantity,
      presby: req.body.presby,
      presNotes: req.body.presNotes,
      followup: req.body.followup ? new Date(req.body.followup) : null,
      followupTime: req.body.followupTime || null,
      isHistory: req.body.isHistory || false,
    });

    await medication.save();
    res
      .status(201)
      .json({ message: "✅ Medication saved successfully", medication });
  } catch (err) {
    console.error("❌ Error saving medication:", err);
    res.status(500).json({ message: "Error saving medication" });
  }
});

// 🔹 Fetch all medications for a patient
app.get("/api/patients/:patientId/medications", async (req, res) => {
  try {
    const { isHistory } = req.query;
    let query = { patientId: req.params.patientId };
    
    // Filter by history status if provided
    if (isHistory !== undefined) {
      query.isHistory = isHistory === 'true';
    }
    
    const meds = await Medication.find(query);
    res.json(meds);
  } catch (err) {
    console.error("❌ Error fetching medications:", err);
    res.status(500).json({ message: "Error fetching medications" });
  }
});

// 🔹 Move medications to prescription history
app.put("/api/patients/:patientId/medications/move-to-history", async (req, res) => {
  try {
    const { medicationIds } = req.body;
    
    if (!medicationIds || !Array.isArray(medicationIds)) {
      return res.status(400).json({ message: "medicationIds array is required" });
    }
    
    const result = await Medication.updateMany(
      { medId: { $in: medicationIds }, patientId: req.params.patientId },
      { $set: { isHistory: true } }
    );
    
    res.json({ 
      message: "✅ Medications moved to history", 
      modifiedCount: result.modifiedCount 
    });
  } catch (err) {
    console.error("❌ Error moving medications to history:", err);
    res.status(500).json({ message: "Error moving medications to history" });
  }
});

// 🔹 Delete specific medication
app.delete("/api/medications/:medId", async (req, res) => {
  try {
    await Medication.findOneAndDelete({ medId: req.params.medId });
    res.json({ message: "🗑️ Medication deleted successfully" });
  } catch (err) {
    console.error("❌ Error deleting medication:", err);
    res.status(500).json({ message: "Error deleting medication" });
  }
});

// 🔹 Update existing medication
app.put("/api/medications/:medId", async (req, res) => {
  try {
    const { medId } = req.params;

    const updatedMedication = await Medication.findOneAndUpdate(
      { medId },
      {
        medicname: req.body.medicname,
        dosage: req.body.dosage,
        frequency: req.body.frequency,
        quantity: req.body.quantity,
        presby: req.body.presby,
        presNotes: req.body.presNotes,
        followup: req.body.followup ? new Date(req.body.followup) : null,
      },
      { new: true }
    );

    if (!updatedMedication) {
      return res.status(404).json({ message: "Medication not found" });
    }

    res.json({
      message: "✅ Medication updated successfully",
      medication: updatedMedication,
    });
  } catch (err) {
    console.error("❌ Error updating medication:", err);
    res.status(500).json({ message: "Error updating medication" });
  }
});

// ====== ALLERGIES SCHEMA ======
const allergySchema = new mongoose.Schema({
  allergyId: { type: String, unique: true },
  patientId: { type: String, required: true },
  allergen: String,
  severity: String,
  reaction: String,
  diadate: Date,
});

const Allergy = mongoose.model("Allergy", allergySchema);

async function generateAllergyId() {
  const last = await Allergy.findOne().sort({ _id: -1 });
  if (!last) return "A001";
  const num = parseInt(last.allergyId.replace("A", "")) + 1;
  return "A" + num.toString().padStart(3, "0");
}

// Add new allergy
app.post("/api/patients/:patientId/allergies", async (req, res) => {
  try {
    const { patientId } = req.params;
    const newId = await generateAllergyId();

    const allergy = new Allergy({
      allergyId: newId,
      patientId,
      allergen: req.body.allergen,
      severity: req.body.severity,
      reaction: req.body.reaction,
      diadate: req.body.diadate,
    });

    await allergy.save();
    res.status(201).json({ message: "✅ Allergy saved successfully", allergy });
  } catch (err) {
    console.error("❌ Error saving allergy:", err);
    res.status(500).json({ message: "Error saving allergy" });
  }
});

// Get allergies
app.get("/api/patients/:patientId/allergies", async (req, res) => {
  try {
    const allergies = await Allergy.find({ patientId: req.params.patientId });
    res.json(allergies);
  } catch (err) {
    res.status(500).json({ message: "Error fetching allergies" });
  }
});

// Delete allergy
app.delete("/api/allergies/:allergyId", async (req, res) => {
  try {
    await Allergy.findOneAndDelete({ allergyId: req.params.allergyId });
    res.json({ message: "🗑️ Allergy deleted successfully" });
  } catch (err) {
    res.status(500).json({ message: "Error deleting allergy" });
  }
});



// ====== VITAL SIGNS SCHEMA ======
const vitalSignSchema = new mongoose.Schema({
  vitalId: { type: String, unique: true },
  patientId: { type: String, required: true },
  date: Date,
  heartrate: String,
  temp: String,
  weight: String,
  pressure: String,
  height: String,
  bmi: String,
});

const VitalSign = mongoose.model("VitalSign", vitalSignSchema);

// Helper: Generate unique vitalId (V001, V002…)
async function generateVitalId() {
  const last = await VitalSign.findOne().sort({ _id: -1 });
  if (!last) return "V001";
  const num = parseInt(last.vitalId.replace("V", "")) + 1;
  return "V" + num.toString().padStart(3, "0");
}

// ✅ Add new vital sign record
app.post("/api/patients/:patientId/vitalsigns", async (req, res) => {
  try {
    const { patientId } = req.params;
    const newId = await generateVitalId();

    const vital = new VitalSign({
      vitalId: newId,
      patientId,
      date: req.body.date,
      heartrate: req.body.heartrate,
      temp: req.body.temp,
      weight: req.body.weight,
      pressure: req.body.pressure,
      height: req.body.height,
      bmi: req.body.bmi,
    });

    await vital.save();
    res
      .status(201)
      .json({ message: "✅ Vital sign record added successfully", vital });
  } catch (err) {
    console.error("❌ Error saving vital sign:", err);
    res.status(500).json({ message: "Error saving vital sign" });
  }
});

// ✅ Fetch all vital signs for a patient
app.get("/api/patients/:patientId/vitalsigns", async (req, res) => {
  try {
    const vitals = await VitalSign.find({ patientId: req.params.patientId });
    res.json(vitals);
  } catch (err) {
    console.error("❌ Error fetching vitals:", err);
    res.status(500).json({ message: "Error fetching vitals" });
  }
});

// ✅ Delete a vital sign record
app.delete("/api/vitalsigns/:vitalId", async (req, res) => {
  try {
    await VitalSign.findOneAndDelete({ vitalId: req.params.vitalId });
    res.json({ message: "🗑️ Vital sign record deleted successfully" });
  } catch (err) {
    console.error("❌ Error deleting vital sign:", err);
    res.status(500).json({ message: "Error deleting vital sign" });
  }
});

// ====== APPOINTMENT SCHEMA ======
const appointmentSchema = new mongoose.Schema({
  appointmentId: { type: String, unique: true },
  patientId: String,
  patientName: String,
  doctorId: String,
  doctorName: String,
  date: Date,
  time: String,
  duration: { type: Number, default: 30 },
  type: String,
  reason: String,
  notes: String,
  status: {
    type: String,
    enum: ["Upcoming", "Ongoing", "Completed", "Canceled"],
    default: "Upcoming",
  },
  startedAt: Date,
  extendedMinutes: { type: Number, default: 0 },
});

const Appointment = mongoose.model("Appointment", appointmentSchema);

// ====== ARCHIVE APPOINTMENT SCHEMA ======
const archiveAppointmentSchema = new mongoose.Schema({
  archiveId: { type: String, unique: true },
  appointmentId: String,
  patientId: String,
  patientName: String,
  doctorId: String,
  doctorName: String,
  date: Date,
  time: String,
  duration: Number,
  type: String,
  reason: String,
  notes: String,
  status: String,
  startedAt: Date,
  completedAt: { type: Date, default: Date.now },
  extendedMinutes: Number,
});

const ArchiveAppointment = mongoose.model(
  "ArchiveAppointment",
  archiveAppointmentSchema
);

// Helper: Generate Appointment ID (A001, A002…) - Based on active appointments only
async function generateAppointmentId() {
  try {
    // Only check active appointments, not archived ones
    const activeCount = await Appointment.countDocuments();
    
    // If no active appointments exist, start with A001
    if (activeCount === 0) {
      console.log("📊 Appointment ID generation: No active appointments, starting with A001");
      return "A001";
    }
    
    // Get all active appointment IDs to find the highest
    const allActiveIds = await Appointment.find({}, { appointmentId: 1 });
    
    let maxNum = 0;
    
    // Check all active appointment IDs
    for (const apt of allActiveIds) {
      if (apt.appointmentId && typeof apt.appointmentId === 'string') {
        // Remove "A" prefix (case-insensitive) and parse the number
        const numStr = apt.appointmentId.replace(/^A/i, "");
        const num = parseInt(numStr, 10);
        if (!isNaN(num) && num > 0) {
          maxNum = Math.max(maxNum, num);
        }
      }
    }
    
    console.log(`📊 Appointment ID generation: Found max ID = ${maxNum} from ${activeCount} active appointments`);
    
    // Generate next ID based on the highest found
    const newNum = maxNum + 1;
    return "A" + newNum.toString().padStart(3, "0");
  } catch (err) {
    console.error("Error generating appointment ID:", err);
    // Fallback: use active count
    try {
      const activeCount = await Appointment.countDocuments();
      return "A" + (activeCount + 1).toString().padStart(3, "0");
    } catch (e) {
      return "A001";
    }
  }
}

// Helper: Generate Archive ID (AR001, AR002...)
async function generateArchiveId() {
  const last = await ArchiveAppointment.findOne().sort({ _id: -1 });
  if (!last) return "AR001";
  const num = parseInt(last.archiveId.replace("AR", "")) + 1;
  return "AR" + num.toString().padStart(3, "0");
}

// ====== Add Appointment ======
app.post("/api/appointments", async (req, res) => {
  try {
    const {
      patientId,
      patientName,
      doctorId,
      doctorName,
      date,
      time,
      duration,
      type,
      reason,
      notes,
    } = req.body;

    // ✅ CHECK 1: Verify patient exists and is active
    const patient = await Patient.findOne({ patientId: patientId });
    if (!patient) {
      return res.status(404).json({ message: "Patient not found" });
    }
    if (patient.status === "Inactive") {
      return res.status(400).json({
        message: "Cannot schedule appointment. Patient account is inactive.",
      });
    }

    // ✅ CHECK 2: Verify doctor exists and is active
    const doctor = await User.findOne({ userId: doctorId });
    if (!doctor) {
      return res.status(404).json({ message: "Doctor not found" });
    }
    if (doctor.status === "Inactive") {
      return res.status(400).json({
        message: "Cannot schedule appointment. Doctor account is inactive.",
      });
    }

    const newId = await generateAppointmentId();

    const appointment = new Appointment({
      appointmentId: newId,
      patientId,
      patientName,
      doctorId,
      doctorName,
      date: new Date(date),
      time: time || "09:00",
      duration: duration || 30,
      type,
      reason,
      notes,
      status: "Upcoming",
    });

    await appointment.save();
    res
      .status(201)
      .json({ message: "Appointment scheduled successfully", appointment });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Error scheduling appointment" });
  }
});

// ====== Auto-Update Status + Fetch All Appointments ======
app.get("/api/appointments", async (req, res) => {
  try {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    // Get current time in minutes since midnight for accurate comparison
    const currentMinutes = now.getHours() * 60 + now.getMinutes();

    // Delete past completed/canceled appointments (before today)
    const expiredByDate = await Appointment.deleteMany({
      date: { $lt: today },
      status: { $in: ["Completed", "Canceled"] },
    });

    if (expiredByDate.deletedCount > 0) {
      console.log(
        `🗑️ Auto-deleted ${expiredByDate.deletedCount} past appointments`
      );
    }

    // Get all appointments
    const appointments = await Appointment.find();

    // Auto-update status from Upcoming to Ongoing
    for (const apt of appointments) {
      const aptDate = new Date(apt.date);
      const aptDateStr = aptDate.toISOString().split("T")[0];
      const todayStr = today.toISOString().split("T")[0];

      // Only process appointments that are today and currently Upcoming
      if (aptDateStr === todayStr && apt.status === "Upcoming") {
        // Convert appointment time to minutes since midnight
        const [hours, minutes] = apt.time.split(":").map(Number);
        const aptMinutes = hours * 60 + minutes;

        // If current time has passed appointment time, set to Ongoing
        if (currentMinutes >= aptMinutes) {
          apt.status = "Ongoing";
          apt.startedAt = new Date();
          await apt.save();
          console.log(
            `✅ Appointment ${
              apt.appointmentId
            } set to Ongoing at ${now.toTimeString()}`
          );
        }
      }
    }

    const updatedAppointments = await Appointment.find();
    res.json(updatedAppointments);
  } catch (err) {
    console.error("Error fetching appointments:", err);
    res.status(500).json({ message: "Error fetching appointments" });
  }
});

// ====== Fetch Single Appointment by ID ======
app.get("/api/appointments/:appointmentId", async (req, res) => {
  try {
    const appointment = await Appointment.findOne({
      appointmentId: req.params.appointmentId,
    });

    if (!appointment) {
      return res.status(404).json({ message: "Appointment not found" });
    }

    res.json(appointment);
  } catch (err) {
    console.error("Error fetching appointment:", err);
    res.status(500).json({ message: "Error fetching appointment" });
  }
});

// ====== Update Appointment Details (CORRECTED) ======
app.put("/api/appointments/:appointmentId", async (req, res) => {
  try {
    const { appointmentId } = req.params;
    const {
      patientName,
      doctorId, // <--- ADD THIS LINE
      doctorName,
      date,
      time,
      type,
      duration,
      reason,
      notes,
    } = req.body;

    const updated = await Appointment.findOneAndUpdate(
      { appointmentId },
      {
        patientName,
        doctorId, // <--- INCLUDE doctorId IN THE UPDATE
        doctorName,
        date: new Date(date),
        time,
        type,
        duration,
        reason,
        notes,
      },
      { new: true }
    );

    if (!updated) {
      return res.status(404).json({ message: "Appointment not found" });
    }

    // Finish response handling
    res.json({
      message: "✅ Appointment updated successfully",
      appointment: updated,
    });
  } catch (err) {
    console.error("Error updating appointment:", err);
    res.status(500).json({ message: "Error updating appointment" });
  }
});

// ====== Daily Cleanup of Expired Appointments at Midnight ======
setInterval(async () => {
  try {
    const now = new Date();
    const startOfToday = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate()
    );
    const endOfToday = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate() + 1
    );
    const currentTime = now.toTimeString().slice(0, 5);

    const expiredByDate = await Appointment.deleteMany({
      date: { $lt: startOfToday },
    });

    const expiredByTime = await Appointment.deleteMany({
      date: { $gte: startOfToday, $lt: endOfToday },
      time: { $lt: currentTime },
    });

    const total = expiredByDate.deletedCount + expiredByTime.deletedCount;
    if (total > 0) {
      console.log(`🧹 Daily Cleanup: Removed ${total} expired appointments`);
    }
  } catch (err) {
    console.error("Error during daily cleanup:", err);
  }
}, 24 * 60 * 60 * 1000);

// ====== Update Appointment Status (with Billing Sync) ======
app.put("/api/appointments/:appointmentId/status", async (req, res) => {
  try {
    const { appointmentId } = req.params;
    const { status } = req.body;

    // validate status input
    if (!["Upcoming", "Completed", "Canceled"].includes(status)) {
      return res.status(400).json({ message: "Invalid status value" });
    }

    // find appointment
    const appointment = await Appointment.findOne({ appointmentId });
    if (!appointment)
      return res.status(404).json({ message: "Appointment not found" });

    // update status
    appointment.status = status;
    await appointment.save();

    // ================================================
    // SEND TO BILLING ONLY IF STATUS === COMPLETED
    // ================================================
    if (status === "Completed") {
      console.log("📩 Sending completed appointment to Billing System...");

      try {
        const billingAddUrl = buildBillingUrl('/api/billing/add');
        if (!billingAddUrl) {
          console.warn('⚠️ BILLING_URL not set or invalid — skipping billing send for appointment');
        } else {
          await fetch(billingAddUrl, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${process.env.BILLING_API_KEY}`
            },
            body: JSON.stringify({
              appointmentId: appointment.appointmentId,
              patientId: appointment.patientId,
              patientName: appointment.patientName,
              doctorId: appointment.doctorId,
              doctorName: appointment.doctorName,
              service: appointment.type,
              date: appointment.date,
              price: appointment.price || 0
            })
          });

          console.log("✅ Billing updated successfully!");
        }
      } catch (billingErr) {
        console.error("❌ Failed to send to Billing:", billingErr);
      }

    } else {
      console.log("⛔ Appointment NOT completed — Billing NOT updated");
    }

    res.json({
      message: "✅ Appointment status updated successfully",
      appointment
    });

  } catch (err) {
    console.error("❌ Error updating appointment:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// ====== Extend Appointment Duration ======
app.put("/api/appointments/:appointmentId/extend", async (req, res) => {
  try {
    const { appointmentId } = req.params;
    const { additionalMinutes } = req.body;

    if (!additionalMinutes || additionalMinutes <= 0) {
      return res.status(400).json({ message: "Invalid extension time" });
    }

    const appointment = await Appointment.findOne({ appointmentId });
    if (!appointment) {
      return res.status(404).json({ message: "Appointment not found" });
    }

    appointment.extendedMinutes += Number(additionalMinutes);
    await appointment.save();

    res.json({
      message: `✅ Appointment extended by ${additionalMinutes} minutes`,
      appointment,
    });
  } catch (err) {
    console.error("❌ Error extending appointment:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// ====== Start Appointment (Set to Ongoing) ======
app.put("/api/appointments/:appointmentId/start", async (req, res) => {
  try {
    const { appointmentId } = req.params;

    const appointment = await Appointment.findOneAndUpdate(
      { appointmentId },
      {
        status: "Ongoing",
        startedAt: new Date(),
      },
      { new: true }
    );

    if (!appointment) {
      return res.status(404).json({ message: "Appointment not found" });
    }

    res.json({
      message: "✅ Appointment started",
      appointment,
    });
  } catch (err) {
    console.error("❌ Error starting appointment:", err);
    res.status(500).json({ message: "Server error" });
  }
});

app.post("/api/appointments/:appointmentId/archive", async (req, res) => {
  try {
    const { appointmentId } = req.params;

    const appointment = await Appointment.findOne({ appointmentId });
    if (!appointment) {
      return res.status(404).json({ message: "Appointment not found" });
    }

    // Save to archive with new Archive ID
    const newArchiveId = await generateArchiveId();

    const archived = new ArchiveAppointment({
      archiveId: newArchiveId,
      appointmentId: appointment.appointmentId,
      patientId: appointment.patientId,
      patientName: appointment.patientName,
      doctorId: appointment.doctorId,
      doctorName: appointment.doctorName,
      date: appointment.date,
      time: appointment.time,
      duration: appointment.duration,
      type: appointment.type,
      reason: appointment.reason,
      notes: appointment.notes,
      status: appointment.status,
      startedAt: appointment.startedAt,
      extendedMinutes: appointment.extendedMinutes,
    });
    await archived.save();
    await appointment.deleteOne();

    res.json({
      message: "✅ Appointment completed and archived",
      archived,
    });
  } catch (err) {
    console.error("❌ Error archiving appointment:", err);
    res.status(500).json({ message: "Server error" });
  }
});

// ====== FETCH ARCHIVED APPOINTMENTS ======
app.get("/api/appointments/archive/list", async (req, res) => {
  try {
    const archived = await ArchiveAppointment.find().sort({ completedAt: -1 });
    res.json(archived);
  } catch (err) {
    console.error("Error fetching archived appointments:", err);
    res.status(500).json({ message: "Error fetching archived appointments" });
  }
});

// ====== BACKUP LOG SCHEMA ======
const backupLogSchema = new mongoose.Schema({
  backupId: { type: String, unique: true },
  type: { type: String, enum: ["Manual", "Automatic"] },
  category: String,
  scope: String,
  status: { type: String, enum: ["success", "failed"], default: "success" },
  records: Number,
  activeCount: Number,
  archivedCount: Number,
  size: String,
  duration: String,
  details: String,
  timestamp: { type: Date, default: Date.now },
  data: {
    users: [Object],
    patients: [Object],
    activeAppointments: [Object],
    archivedAppointments: [Object],
    activityLogs: [Object],
  },
});

const BackupLog = mongoose.model("BackupLog", backupLogSchema);

// Helper: Generate Backup ID (B001, B002...)
async function generateBackupId() {
  const last = await BackupLog.findOne().sort({ _id: -1 });
  if (!last) return "B001";
  const num = parseInt(last.backupId.replace("B", "")) + 1;
  return "B" + num.toString().padStart(3, "0");
}

// ====== ACTIVITY LOG SCHEMA ======
const activityLogSchema = new mongoose.Schema({
  logId: { type: String, unique: true },
  userId: String,
  userName: String,
  userRole: String,
  action: String,
  details: String,
  ipAddress: String,
  loginTime: Date,
  logoutTime: Date,
  duration: String,
  timestamp: { type: Date, default: Date.now },
});

const ActivityLog = mongoose.model("ActivityLog", activityLogSchema);

// Helper: Generate Activity Log ID (AL001, AL002...)
async function generateActivityLogId() {
  const last = await ActivityLog.findOne().sort({ _id: -1 });
  if (!last) return "AL001";
  const num = parseInt(last.logId.replace("AL", "")) + 1;
  return "AL" + num.toString().padStart(3, "0");
}

// ====== BACKUP ENDPOINTS ======

// ====== FORMAT FILE SIZE HELPER ======
function formatFileSize(bytes) {
  if (bytes === 0) return "0 Bytes";

  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB", "TB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));

  const size = parseFloat((bytes / Math.pow(k, i)).toFixed(2));
  return `${size} ${sizes[i]}`;
}

// ====== BACKUP ROUTES (CORRECT ORDER) ======
// Get backup statistics
app.get("/api/backup/accounts/stats", async (req, res) => {
  try {
    const users = await User.find({});
    const patients = await Patient.find({});
    
    // ✅ Get the actual latest backup timestamp
    const latestBackup = await BackupLog.findOne({
      category: 'Users & Patients'
    }).sort({ timestamp: -1 });
    
    res.json({
      totalUsers: users.length,
      totalPatients: patients.length,
      totalRecords: users.length + patients.length,
      lastBackup: latestBackup ? latestBackup.timestamp : null 
    });
  } catch (err) {
    res.status(500).json({ message: "Error fetching stats" });
  }
});


// Get all backup logs for accounts (MUST BE BEFORE :id route)
app.get("/api/backup/logs/accounts", async (req, res) => {
  try {
    console.log("📤 Fetching all account backup logs...");

    const logs = await BackupLog.find({
      category: "Users & Patients",
    }).sort({ timestamp: -1 });

    const formattedLogs = logs.map((log) => ({
      id: log._id.toString(),
      status: log.status,
      date: log.timestamp,
      type: log.type,
      category: log.category,
      records: log.records,
      size: log.size,
      duration: log.duration,
      details: log.details,
    }));

    console.log(`✅ Sending ${formattedLogs.length} backup logs to frontend`);
    res.json(formattedLogs);
  } catch (err) {
    console.error("❌ Error fetching backup logs:", err);
    res.status(500).json({ message: "Error fetching logs" });
  }
});

// Get all appointment backup logs
app.get("/api/backup/logs/appointments", async (req, res) => {
  try {
    console.log("📤 Fetching all appointment backup logs...");

    const logs = await BackupLog.find({
      category: { $regex: /Appointment/i },
    }).sort({ timestamp: -1 });

    const formattedLogs = logs.map((log) => ({
      id: log._id.toString(),
      status: log.status,
      date: log.timestamp,
      type: log.type,
      category: log.category,
      scope: log.scope || "Full", // New field
      records: log.records,
      activeCount: log.activeCount || 0,
      archivedCount: log.archivedCount || 0,
      size: log.size,
      duration: log.duration,
      details: log.details,
    }));

    console.log(
      `✅ Sending ${formattedLogs.length} appointment backup logs to frontend`
    );
    res.json(formattedLogs);
  } catch (err) {
    console.error("❌ Error fetching appointment backup logs:", err);
    res.status(500).json({ message: "Error fetching logs" });
  }
});

// Get all activity backup logs
app.get("/api/backup/logs/activity", async (req, res) => {
  try {
    console.log("📤 Fetching all activity backup logs...");

    const logs = await BackupLog.find({
      category: { $regex: /Activity/i },
    }).sort({ timestamp: -1 });

    const formattedLogs = logs.map((log) => ({
      id: log._id.toString(),
      status: log.status,
      date: log.timestamp,
      type: log.type,
      category: log.category || "Activity Logs",
      records: log.records,
      size: log.size,
      duration: log.duration,
      details: log.details,
    }));

    console.log(
      `✅ Sending ${formattedLogs.length} activity backup logs to frontend`
    );
    res.json(formattedLogs);
  } catch (err) {
    console.error("❌ Error fetching activity backup logs:", err);
    res.status(500).json({ message: "Error fetching logs" });
  }
});

// ✅ DEBUG ROUTE (add here, before :id route)
app.get("/api/backup/logs/debug", async (req, res) => {
  try {
    const allLogs = await BackupLog.find({}).sort({ timestamp: -1 });

    const summary = allLogs.map((log) => ({
      id: log._id.toString(),
      backupId: log.backupId,
      category: log.category,
      type: log.type,
      timestamp: log.timestamp,
      scope: log.scope || "N/A",
      records: log.records,
    }));

    res.json({
      total: allLogs.length,
      accountLogs: summary.filter(
        (l) => l.category?.includes("User") || l.category?.includes("Patient")
      ),
      appointmentLogs: summary.filter((l) =>
        l.category?.includes("Appointment")
      ),
      allLogs: summary,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get specific backup details (MUST BE AFTER /accounts route)
app.get("/api/backup/logs/:id", async (req, res) => {
  try {
    const requestedId = req.params.id;

    console.log("📥 Backup details requested for ID:", requestedId);

    // Validate MongoDB ObjectId format
    if (!/^[0-9a-fA-F]{24}$/.test(requestedId)) {
      console.error("❌ Invalid ObjectId format:", requestedId);
      return res.status(400).json({
        message: "Invalid backup ID format",
        receivedId: requestedId,
      });
    }

    const log = await BackupLog.findById(requestedId);

    if (!log) {
      console.error("❌ Backup not found with ID:", requestedId);
      return res.status(404).json({ message: "Backup not found" });
    }

    console.log("✅ Backup found:", log.backupId, "Category:", log.category);

    // Build response based on category
    let response = {
      id: log._id.toString(),
      backupId: log.backupId,
      type: log.type,
      category: log.category,
      status: log.status,
      records: log.records,
      size: log.size,
      duration: log.duration,
      details: log.details,
      timestamp: log.timestamp,
      data: log.data, // Include full data for downloads
    };

    // Add scope and counts for appointments
    if (log.category && log.category.includes("Appointment")) {
      response.scope = log.scope;
      response.activeCount = log.activeCount;
      response.archivedCount = log.archivedCount;
    }

    // Add preview for accounts
    if (log.category === "Users & Patients") {
      response.preview = {
        users: log.data.users.slice(0, 5),
        patients: log.data.patients.slice(0, 5),
        totalUsers: log.data.users.length,
        totalPatients: log.data.patients.length,
      };
    }

    res.json(response);
  } catch (err) {
    console.error("❌ Error fetching backup details:", err);
    res.status(500).json({ message: "Error fetching backup details" });
  }
});

// Download backup
app.get("/api/backup/download/:id", async (req, res) => {
  try {
    const log = await BackupLog.findById(req.params.id);

    if (!log) {
      return res.status(404).json({ message: "Backup not found" });
    }

    res.setHeader("Content-Type", "application/json");
    res.setHeader(
      "Content-Disposition",
      `attachment; filename=backup_${log.backupId}_${
        log.timestamp.toISOString().split("T")[0]
      }.json`
    );

    // ✅ Format activity logs for better readability in download
    let formattedData = log.data;

    if (log.category && log.category.includes("Activity")) {
      formattedData = {
        ...log.data,
        activityLogs:
          log.data.activityLogs?.map((actLog) => ({
            logId: actLog.logId,
            userId: actLog.userId,
            userName: actLog.userName,
            userRole: actLog.userRole,
            action: actLog.action,
            loginTime: actLog.loginTime
              ? new Date(actLog.loginTime).toLocaleString()
              : "N/A",
            logoutTime: actLog.logoutTime
              ? new Date(actLog.logoutTime).toLocaleString()
              : "N/A",
            duration: actLog.duration || "N/A",
            ipAddress: actLog.ipAddress,
            details: actLog.details,
            timestamp: new Date(actLog.timestamp).toLocaleString(),
          })) || [],
      };
    }

    res.json({
      backupId: log.backupId,
      timestamp: log.timestamp,
      category: log.category,
      type: log.type,
      records: log.records,
      data: formattedData, // ✅ Use formatted data
    });
  } catch (err) {
    console.error("Error downloading backup:", err);
    res.status(500).json({ message: "Error downloading backup" });
  }
});

// Manual backup trigger
app.post("/api/backup/accounts/manual", async (req, res) => {
  try {
    const timestamp = new Date();

    const users = await User.find({}, "-password").lean();
    const patients = await Patient.find({}).lean();

    const totalRecords = users.length + patients.length;

    // ✅ Calculate size in bytes and format
    const sizeInBytes = Buffer.byteLength(
      JSON.stringify({ users, patients }),
      "utf8"
    );
    const formattedSize = formatFileSize(sizeInBytes);

    console.log(`📊 Backup size: ${sizeInBytes} bytes = ${formattedSize}`);

    await new Promise((resolve) => setTimeout(resolve, 2000));

    const backupId = await generateBackupId();

    const backupLog = new BackupLog({
      backupId,
      type: "Manual",
      category: "Users & Patients",
      status: "success",
      records: totalRecords,
      size: formattedSize,
      duration: "2m 15s",
      details: `Backed up ${users.length} users and ${patients.length} patients successfully.`,
      timestamp,
      data: { users, patients },
    });

    await backupLog.save();

    const backup = {
      id: backupLog._id.toString(),
      status: backupLog.status,
      date: backupLog.timestamp,
      type: backupLog.type,
      category: backupLog.category,
      records: backupLog.records,
      size: backupLog.size,
      duration: backupLog.duration,
      details: backupLog.details,
    };

    console.log("✅ Manual backup saved:", backupId, "-", formattedSize);

    res.json({
      message: "✅ Manual backup completed successfully",
      backup,
    });
  } catch (err) {
    console.error("❌ Backup error:", err);
    res.status(500).json({
      message: "Backup failed",
      error: err.message,
    });
  }
});

// Get backup settings
app.get("/api/backup/settings", async (req, res) => {
  try {
    const settings = {
      appointment: { frequency: 1, unit: "days" },
      account: { frequency: 1, unit: "days" },
      activity: { frequency: 7, unit: "days" },
      enableNotifications: true,
      enableFailureAlerts: true,
      enableRetention: true,
    };

    res.json(settings);
  } catch (err) {
    res.status(500).json({ message: "Error fetching settings" });
  }
});

// Save backup settings
app.post("/api/backup/settings", async (req, res) => {
  try {
    const settings = req.body;
    console.log("💾 Backup settings saved:", settings);
    scheduleBackups(settings);

    res.json({
      message: "✅ Backup settings saved and scheduler updated",
      settings,
    });
  } catch (err) {
    console.error("❌ Error saving settings:", err);
    res.status(500).json({ message: "Error saving settings" });
  }
});

// Get appointment backup statistics
app.get("/api/backup/appointments/stats", async (req, res) => {
  try {
    const activeAppointments = await Appointment.find({});
    const archivedAppointments = await ArchiveAppointment.find({});
    
    // ✅ Get the actual latest backup timestamp
    const latestBackup = await BackupLog.findOne({
      category: { $regex: /Appointment/i }
    }).sort({ timestamp: -1 });
    
    res.json({
      totalActive: activeAppointments.length,
      totalArchived: archivedAppointments.length,
      totalRecords: activeAppointments.length + archivedAppointments.length,
      breakdown: {
        upcoming: activeAppointments.filter(a => a.status === "Upcoming").length,
        ongoing: activeAppointments.filter(a => a.status === "Ongoing").length,
        completed: archivedAppointments.filter(a => a.status === "Completed").length,
        canceled: archivedAppointments.filter(a => a.status === "Canceled").length
      },
      lastBackup: latestBackup ? latestBackup.timestamp : null  // ✅ Use actual backup time
    });
  } catch (err) {
    res.status(500).json({ message: "Error fetching stats" });
  }
});

// Manual appointment backup trigger
app.post("/api/backup/appointments/manual", async (req, res) => {
  try {
    const timestamp = new Date();
    const { scope } = req.body; // 'full', 'active', or 'archived'

    let activeAppointments = [];
    let archivedAppointments = [];
    let scopeLabel = "Full";

    // Determine what to backup based on scope
    if (!scope || scope === "full") {
      activeAppointments = await Appointment.find({}).lean();
      archivedAppointments = await ArchiveAppointment.find({}).lean();
      scopeLabel = "Full";
    } else if (scope === "active") {
      activeAppointments = await Appointment.find({}).lean();
      scopeLabel = "Active Only";
    } else if (scope === "archived") {
      archivedAppointments = await ArchiveAppointment.find({}).lean();
      scopeLabel = "Archived Only";
    }

    const totalRecords =
      activeAppointments.length + archivedAppointments.length;

    // Calculate size in bytes and format
    const dataToBackup = { activeAppointments, archivedAppointments };
    const sizeInBytes = Buffer.byteLength(JSON.stringify(dataToBackup), "utf8");
    const formattedSize = formatFileSize(sizeInBytes);

    console.log(`📊 Appointment Backup - Scope: ${scopeLabel}`);
    console.log(
      `   Active: ${activeAppointments.length}, Archived: ${archivedAppointments.length}`
    );
    console.log(`   Size: ${sizeInBytes} bytes = ${formattedSize}`);

    await new Promise((resolve) => setTimeout(resolve, 2000));

    const backupId = await generateBackupId();

    const backupLog = new BackupLog({
      backupId,
      type: "Manual",
      category: `Appointments (${scopeLabel})`,
      scope: scopeLabel,
      status: "success",
      records: totalRecords,
      activeCount: activeAppointments.length,
      archivedCount: archivedAppointments.length,
      size: formattedSize,
      duration: "2m 10s",
      details: `Backed up ${activeAppointments.length} active and ${archivedAppointments.length} archived appointments.`,
      timestamp,
      data: dataToBackup,
    });

    await backupLog.save();

    const backup = {
      id: backupLog._id.toString(),
      status: backupLog.status,
      date: backupLog.timestamp,
      type: backupLog.type,
      category: backupLog.category,
      scope: backupLog.scope,
      records: backupLog.records,
      activeCount: backupLog.activeCount,
      archivedCount: backupLog.archivedCount,
      size: backupLog.size,
      duration: backupLog.duration,
      details: backupLog.details,
    };

    console.log("✅ Appointment backup saved:", backupId, "-", formattedSize);

    res.json({
      message: "✅ Appointment backup completed successfully",
      backup,
    });
  } catch (err) {
    console.error("❌ Appointment backup error:", err);
    res.status(500).json({
      message: "Appointment backup failed",
      error: err.message,
    });
  }
});

// Get activity backup statistics
app.get("/api/backup/activity/stats", async (req, res) => {
  try {
    const activityLogs = await ActivityLog.find({});
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const todayLogs = activityLogs.filter(
      (log) => new Date(log.timestamp) >= today
    );

    res.json({
      totalLogs: activityLogs.length,
      todayLogs: todayLogs.length,
      lastBackup: new Date(),
    });
  } catch (err) {
    res.status(500).json({ message: "Error fetching activity stats" });
  }
});

// Manual activity log backup trigger
app.post("/api/backup/activity/manual", async (req, res) => {
  try {
    const timestamp = new Date();

    const activityLogs = await ActivityLog.find({}).lean();

    const totalRecords = activityLogs.length;

    // Calculate size in bytes and format
    const dataToBackup = { activityLogs };
    const sizeInBytes = Buffer.byteLength(JSON.stringify(dataToBackup), "utf8");
    const formattedSize = formatFileSize(sizeInBytes);

    console.log(`📊 Activity Log Backup`);
    console.log(`   Total Logs: ${activityLogs.length}`);
    console.log(`   Size: ${sizeInBytes} bytes = ${formattedSize}`);

    await new Promise((resolve) => setTimeout(resolve, 2000));

    const backupId = await generateBackupId();

    const backupLog = new BackupLog({
      backupId,
      type: "Manual",
      category: "Activity Logs",
      scope: "Full",
      status: "success",
      records: totalRecords,
      activeCount: 0,
      archivedCount: 0,
      size: formattedSize,
      duration: "1m 45s",
      details: `Backed up ${activityLogs.length} activity log entries successfully.`,
      timestamp,
      data: {
        users: [],
        patients: [],
        activeAppointments: [],
        archivedAppointments: [],
        activityLogs: activityLogs,
      },
    });

    await backupLog.save();

    const backup = {
      id: backupLog._id.toString(),
      status: backupLog.status,
      date: backupLog.timestamp,
      type: backupLog.type,
      category: backupLog.category,
      records: backupLog.records,
      size: backupLog.size,
      duration: backupLog.duration,
      details: backupLog.details,
    };

    console.log("✅ Activity log backup saved:", backupId, "-", formattedSize);

    res.json({
      message: "✅ Activity log backup completed successfully",
      backup,
    });
  } catch (err) {
    console.error("❌ Activity log backup error:", err);
    res.status(500).json({
      message: "Activity log backup failed",
      error: err.message,
    });
  }
});

// Create activity log entry
app.post("/api/activity/log", async (req, res) => {
  try {
    const { userId, userName, userRole, action, details, ipAddress } = req.body;

    const logId = await generateActivityLogId();

    const activityLog = new ActivityLog({
      logId,
      userId,
      userName,
      userRole,
      action,
      details,
      ipAddress,
    });

    await activityLog.save();

    res.json({
      message: "✅ Activity logged successfully",
      log: activityLog,
    });
  } catch (err) {
    console.error("❌ Error logging activity:", err);
    res.status(500).json({ message: "Error logging activity" });
  }
});

// Get all activity logs
app.get("/api/activity/logs", async (req, res) => {
  try {
    const logs = await ActivityLog.find({}).sort({ timestamp: -1 });
    res.json(logs);
  } catch (err) {
    console.error("❌ Error fetching activity logs:", err);
    res.status(500).json({ message: "Error fetching activity logs" });
  }
});

// ====== BACKUP SCHEDULER ======
let backupIntervals = {
  appointment: null,
  account: null,
  activity: null,
};

async function scheduleBackups(settings) {
  console.log("📅 Scheduling backups with settings:", settings);

  Object.values(backupIntervals).forEach((interval) => {
    if (interval) clearInterval(interval);
  });

  if (settings.appointment) {
    const appointmentMs = convertToMilliseconds(
      settings.appointment.frequency,
      settings.appointment.unit
    );
    console.log(
      `⏰ Appointment backup scheduled every ${settings.appointment.frequency} ${settings.appointment.unit}`
    );

    backupIntervals.appointment = setInterval(async () => {
      console.log("🔄 Running automatic appointment backup...");

      try {
        const activeAppointments = await Appointment.find({}).lean();
        const archivedAppointments = await ArchiveAppointment.find({}).lean();

        const totalRecords =
          activeAppointments.length + archivedAppointments.length;

        const dataToBackup = { activeAppointments, archivedAppointments };
        const sizeInBytes = Buffer.byteLength(
          JSON.stringify(dataToBackup),
          "utf8"
        );
        const formattedSize = formatFileSize(sizeInBytes);

        const backupId = await generateBackupId();
        const backupLog = new BackupLog({
          backupId,
          type: "Automatic",
          category: "Appointments (Full)",
          scope: "Full",
          status: "success",
          records: totalRecords,
          activeCount: activeAppointments.length,
          archivedCount: archivedAppointments.length,
          size: formattedSize,
          duration: "2m 5s",
          details: `Automatic backup: ${activeAppointments.length} active and ${archivedAppointments.length} archived appointments.`,
          timestamp: new Date(),
          data: dataToBackup,
        });

        await backupLog.save();

        console.log(
          `✅ Automatic appointment backup saved: ${backupId} - ${totalRecords} records, ${formattedSize}`
        );
      } catch (err) {
        console.error("❌ Automatic appointment backup failed:", err);
      }
    }, appointmentMs);
  }

  // ✅ FIXED: Automatic Account Backup Scheduler
  if (settings.account) {
    const accountMs = convertToMilliseconds(
      settings.account.frequency,
      settings.account.unit
    );
    console.log(
      `⏰ Account backup scheduled every ${settings.account.frequency} ${settings.account.unit}`
    );

    // ADD 2-second delay to prevent ID collision
    setTimeout(() => {
      backupIntervals.account = setInterval(async () => {
        console.log("🔄 Running automatic account backup...");

        try {
          const users = await User.find({}, "-password").lean();
          const patients = await Patient.find({}).lean();

          console.log(
            `📊 Found ${users.length} users and ${patients.length} patients`
          );

          const totalRecords = users.length + patients.length;

          // ✅ FIX: Ensure data structure matches schema
          const dataToBackup = {
            users: users || [],
            patients: patients || [],
            activeAppointments: [], // ✅ Add empty arrays for appointment fields
            archivedAppointments: [],
          };

          const sizeInBytes = Buffer.byteLength(
            JSON.stringify(dataToBackup),
            "utf8"
          );
          const formattedSize = formatFileSize(sizeInBytes);

          const backupId = await generateBackupId();

          console.log(`💾 Creating backup ${backupId}...`);

          const backupLog = new BackupLog({
            backupId,
            type: "Automatic",
            category: "Users & Patients",
            scope: "N/A", // ✅ Add scope field
            status: "success",
            records: totalRecords,
            activeCount: 0, // ✅ Add counts for consistency
            archivedCount: 0,
            size: formattedSize,
            duration: "2m 5s",
            details: `Automatic backup: ${users.length} users and ${patients.length} patients.`,
            timestamp: new Date(),
            data: dataToBackup,
          });

          const savedBackup = await backupLog.save();

          console.log(`✅ Automatic account backup saved successfully!`);
          console.log(`   Backup ID: ${backupId}`);
          console.log(`   MongoDB _id: ${savedBackup._id}`);
          console.log(`   Records: ${totalRecords}`);
          console.log(`   Size: ${formattedSize}`);
        } catch (err) {
          console.error("❌ Automatic account backup failed!");
          console.error("   Error name:", err.name);
          console.error("   Error message:", err.message);
          console.error("   Full error:", err);
        }
      }, accountMs);
    }, 1000);
  }

  if (settings.activity) {
  const activityMs = convertToMilliseconds(settings.activity.frequency, settings.activity.unit);
  console.log(`⏰ Activity log backup scheduled every ${settings.activity.frequency} ${settings.activity.unit}`);
  
  // ✅ ADD 3-second delay to prevent ID collision
  setTimeout(() => {
    backupIntervals.activity = setInterval(async () => {
      console.log('🔄 Running automatic activity log backup...');
      
      try {
        // ✅ FIX: Actually fetch activity logs, not users
        const activityLogs = await ActivityLog.find({}).lean();
        
        console.log(`📊 Found ${activityLogs.length} activity logs to backup`);
        
        const totalRecords = activityLogs.length;
        
        const dataToBackup = { 
          users: [],
          patients: [],
          activeAppointments: [],
          archivedAppointments: [],
          activityLogs: activityLogs  // ✅ Include actual activity logs
        };
        
        const sizeInBytes = Buffer.byteLength(JSON.stringify(dataToBackup), 'utf8');
        const formattedSize = formatFileSize(sizeInBytes);
        
        const backupId = await generateBackupId();
        
        console.log(`💾 Creating activity backup ${backupId}...`);
        
        const backupLog = new BackupLog({
          backupId,
          type: 'Automatic',
          category: 'Activity Logs',
          scope: 'Full',
          status: 'success',
          records: totalRecords,
          activeCount: 0,
          archivedCount: 0,
          size: formattedSize,
          duration: '1m 40s',
          details: `Automatic backup: ${activityLogs.length} activity log entries.`,
          timestamp: new Date(),
          data: dataToBackup
        });
        
        const savedBackup = await backupLog.save();
        
        console.log(`✅ Automatic activity log backup saved successfully!`);
        console.log(`   Backup ID: ${backupId}`);
        console.log(`   MongoDB _id: ${savedBackup._id}`);
        console.log(`   Records: ${totalRecords}`);
        console.log(`   Size: ${formattedSize}`);
        
      } catch (err) {
        console.error('❌ Automatic activity log backup failed!');
        console.error('   Error:', err.message);
      }
    }, activityMs);
  }, 2000); // ✅ 2-second delay
}
}

function convertToMilliseconds(frequency, unit) {
  const multipliers = {
    seconds: 1000,
    minutes: 60 * 1000,
    hours: 60 * 60 * 1000,
    days: 24 * 60 * 60 * 1000,
    months: 30 * 24 * 60 * 60 * 1000,
    years: 365 * 24 * 60 * 60 * 1000,
  };

  return frequency * (multipliers[unit] || multipliers.days);
}

// Load backup settings on server start and schedule
mongoose.connection.once("open", async () => {
  // ... (keep existing migration code)

  // Load and apply backup schedule
  try {
    // In production, load from database
    // For now, use default settings
    const defaultSettings = {
      appointment: { frequency: 1, unit: "days" },
      account: { frequency: 1, unit: "days" },
      activity: { frequency: 7, unit: "days" },
    };

    scheduleBackups(defaultSettings);
    console.log("✅ Backup scheduler initialized");
  } catch (err) {
    console.error("❌ Failed to initialize backup scheduler:", err);
  }
});

// ====== SYSTEM STATUS (Integration) ======
app.get("/api/emr/status", (req, res) => res.json({ connected: true }));
app.get("/api/pharmacy/status", (req, res) => res.json({ connected: false }));
app.get("/api/billing/status", (req, res) => res.json({ connected: false }));

// ====== START SERVER ======
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 EMR Server running on port ${PORT}`);
});